# Additional analyses for the pre-submission revision

These analyses use existing sealed predictions. They add no model inference and
do not replace or rerun any previously reported estimate or confidence interval.

`frozen_rules.json` records the outcome-independent baseline-margin cutpoints,
new bootstrap seeds, definitions and source hashes. `freeze_receipt.json` binds
the rules and executable analysis code before the new analyses. The historical
06:03:26 margin record concerns the planning/equivalence threshold and BCa
sensitivity; those values are copied unchanged in `revision_results.json`.

The main outputs are `margin_results.csv`, `capture_identity.csv`,
`question_level_revision.csv` and `revision_results.json` (including the SLAKE
question-only label/class counts). `verification.json` records independent
checks with a different bootstrap implementation and separate seeds.

To reproduce in a clean directory, extract S2 through S10 into the same parent
directory. Use Python 3.12 with NumPy, then run:

```
python revision_2026_analyses/portable_reproduce.py
```

The wrapper copies existing S3 records to the relative source bindings recorded
in the freeze if those original paths are absent. It verifies frozen source
hashes and runs only the new analyses and their checks. Keep an original copy of
the released outputs before rerunning, because rerun output timestamps change.
Bootstrap intervals condition on the frozen quartile boundaries and questions.
The identity checks use exact rational arithmetic on each question.

The optional alternative encoder was not run. The original frozen SigLIP ranking
and all earlier model answers are retained. Author contributions and the public
repository DOI remain explicit author-input fields in the draft.
