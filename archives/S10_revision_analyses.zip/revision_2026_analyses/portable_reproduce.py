"""Reproduce NEW analyses after extracting S2-S10 into one clean directory."""
from pathlib import Path
import json,shutil,runpy,hashlib
A=Path(__file__).resolve().parent;R=A.parent
rules=json.loads((A/'frozen_rules.json').read_text())
mapping={'Primary/2B':'controlled_replication','Primary/4B':'controlled_replication_4b','Curated/2B':'curated_replication_2b','Curated/4B':'curated_replication_4b'}
for label,folder in mapping.items():
    target=R/rules['sources'][label]['raw_directory']
    if not target.exists():
        source=R/'reproducibility_bundle/raw_predictions'/(folder+'__main')
        assert source.is_dir(),source
        # A fresh extracted release reconstructs the original relative binding.
        shutil.copytree(source,target)
for name,expected in rules['sources'].items():
    if isinstance(expected,str):assert hashlib.sha256((R/name).read_bytes()).hexdigest()==expected,name
runpy.run_path(str(A/'run_analyses.py'),run_name='__main__')
runpy.run_path(str(A/'verify_new_analyses.py'),run_name='__main__')
