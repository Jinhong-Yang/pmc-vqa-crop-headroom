"""Freeze new revision rules and outcome-independent quartiles before analysis."""
from pathlib import Path
import json,csv,hashlib,datetime,sys
A=Path(__file__).resolve().parent;R=A.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
mapping={'Primary/2B':'controlled_replication','Primary/4B':'controlled_replication_4b','Curated/2B':'curated_replication_2b','Curated/4B':'curated_replication_4b'}
def raw_dir(folder):
    p=R/folder/'main/predictions'
    return p if p.exists() else R/'reproducibility_bundle/raw_predictions'/(folder+'__main')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=R/'window_audit_20261019/window_outcomes.csv'
flat=list(csv.DictReader(source.open(encoding='utf-8-sig')))
rules={'status':'FROZEN_BEFORE_NEW_ANALYSES','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'margin':'Top-1 minus top-2 of baseline E normalized four-label probabilities.',
 'strata':'Within each model/cohort, numpy.quantile at .25,.50,.75 (method=linear). Q1 includes margin<=q25; Q2 q25<margin<=q50; Q3 q50<margin<=q75; Q4 margin>q75. Tied boundaries stay together.',
 'bootstrap':{'draws':20000,'unit':'Paired question within fixed stratum','seed_by_run':{k:2026102001+i for i,k in enumerate(mapping)},'implementation':'Ordinary case-index bootstrap in batches of 500; same sampled index retains baseline, guided, mean control and duplicate.'},
 'identity':'Check every row with exact Fraction arithmetic. K0/K9 baseline errors have zero selected-minus-uniform contribution; conditional gap = full gap*n/n_sub; all-eight = full gap*9/8.',
 'SLAKE':'Question-only predictions mapped from permuted A-D labels to per-question four anatomical classes. Raw counts and image-weighted proportions shown separately.',
 'alternative_encoder':'Not executed; original SigLIP fixed. No new VLM inference.',
 'sources':{},'quartiles':{},'analysis_code_sha256':sha(A/'run_analyses.py')}
for label,folder in mapping.items():
    cohort,model=label.lower().split('/');rows=[x for x in flat if x['cohort']==cohort and x['model']==model]
    vals=[];h=hashlib.sha256()
    for row in rows:
        p=raw_dir(folder)/(row['sample_id']+'.json');blob=p.read_bytes();h.update(row['sample_id'].encode()+hashlib.sha256(blob).digest())
        probs=sorted(json.loads(blob)['scores']['E']['option_probs'],reverse=True)
        vals.append(probs[0]-probs[1])
    rules['quartiles'][label]=np.quantile(vals,[.25,.5,.75],method='linear').tolist()
    rules['sources'][label]={'n':len(rows),'raw_directory':str(raw_dir(folder).relative_to(R)),'raw_digest':h.hexdigest()}
for p in [source,R/'additional_controls_20261018/question_level_results.csv',R/'presubmission_20261018/additional_results.json',R/'additional_controls_20261018/positive_control/main/inputs.jsonl',R/'additional_controls_20261018/positive_control/main/references.jsonl']:
    rules['sources'][str(p.relative_to(R))]=sha(p)
target=A/'frozen_rules.json'
assert not target.exists(),'Existing freeze must never be overwritten'
target.write_text(json.dumps(rules,indent=2),encoding='utf-8')
(A/'freeze_receipt.json').write_text(json.dumps({'at':rules['at'],'rules_sha256':sha(target),'code_sha256':rules['analysis_code_sha256']},indent=2),encoding='utf-8')
print(json.dumps({'status':'FROZEN','at':rules['at'],'quartiles':rules['quartiles']},indent=2))
