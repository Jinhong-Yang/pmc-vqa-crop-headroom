"""New revision-only analyses. Prior estimates and archives remain unchanged."""
from pathlib import Path
from fractions import Fraction
import csv,json,sys,hashlib,collections,datetime
A=Path(__file__).resolve().parent;R=A.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rules=json.loads((A/'frozen_rules.json').read_text());seal=json.loads((A/'freeze_receipt.json').read_text())
assert sha(A/'frozen_rules.json')==seal['rules_sha256']
assert sha(Path(__file__))==seal['code_sha256']
flat=list(csv.DictReader((R/'window_audit_20261019/window_outcomes.csv').open(encoding='utf-8-sig')))
out={'status':'COMPLETE','analysis_status':'Post hoc (revision)','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freeze_sha256':seal['rules_sha256'],'draws':20000,'runs':{},'identities':[]}
margin_rows=[];question_rows=[]
for label in rules['quartiles']:
    cohort,model=label.lower().split('/');rows=[x for x in flat if x['cohort']==cohort and x['model']==model];n=len(rows)
    raw=[json.loads((R/rules['sources'][label]['raw_directory']/(x['sample_id']+'.json')).read_text()) for x in rows]
    b=np.array([int(x['baseline']) for x in rows]);g=np.array([int(p['scores']['ROI_HIGH']['answer']==x['reference']) for p,x in zip(raw,rows)])
    c=np.array([[int(p['scores']['ROI_RANDOM_'+str(s)]['answer']==x['reference']) for s in [1,7,42]] for p,x in zip(raw,rows)])
    du=np.array([int(p['scores']['ROI_DUPLICATE']['answer']==x['reference']) for p,x in zip(raw,rows)])
    margin=np.array([sorted(p['scores']['E']['option_probs'],reverse=True)[0]-sorted(p['scores']['E']['option_probs'],reverse=True)[1] for p in raw])
    q=np.searchsorted(rules['quartiles'][label],margin,side='left')+1
    gh=(1-b)*g;ch=(1-b)*c.mean(1);dh=(1-b)*du;diff=gh-ch
    rng=np.random.default_rng(rules['bootstrap']['seed_by_run'][label]);run=[]
    for quartile in range(1,5):
        take=q==quartile;nn=int(take.sum());values=diff[take];boot=[]
        for start in range(0,20000,500):boot.extend(values[rng.integers(0,nn,(500,nn))].mean(1))
        lo,hi=np.quantile(boot,[.025,.975])
        rescue=int(gh[take].sum());harm=int((b*(1-g))[take].sum());changes=sum(p['scores']['E']['answer']!=p['scores']['ROI_HIGH']['answer'] for p,t in zip(raw,take) if t)
        record={'run':label,'quartile':quartile,'n':nn,'minimum_margin':float(margin[take].min()),'maximum_margin':float(margin[take].max()),'baseline_accuracy':float(b[take].mean()),'guided_headroom':float(gh[take].mean()),'control_mean_headroom':float(ch[take].mean()),'duplicate_headroom':float(dh[take].mean()),'guided_minus_control':float(values.mean()),'ci_low':float(lo),'ci_high':float(hi),'guided_rescues':rescue,'guided_harms':harm,'guided_answer_changes':changes}
        margin_rows.append(record);run.append(record)
    # Exact arithmetic verifies the four identities on all sealed questions.
    contributions=[];sub=[];all8=[];zero_extreme=True
    for i,x in enumerate(rows):
        k=sum(int(x['window_'+str(j)]) for j in range(9));selected=g[i]
        val=Fraction((1-int(b[i]))*(9*int(selected)-k),9)
        contributions.append(val);active=(b[i]==0 and 1<=k<=8)
        if active:sub.append(val)
        if b[i]==0 and k in [0,9]:zero_extreme=zero_extreme and val==0
        nonselected=Fraction(k-int(selected),8)
        all8.append((1-int(b[i]))*(Fraction(int(selected))-nonselected))
        question_rows.append({'run':label,'sample_id':x['sample_id'],'margin':float(margin[i]),'quartile':int(q[i]),'baseline_correct':int(b[i]),'guided_correct':int(g[i]),'control_correct_count':int(c[i].sum()),'duplicate_correct':int(du[i]),'K':k,'selected_minus_uniform_fraction':str(val)})
    full=sum(contributions,Fraction(0))/n;cap=sum(sub,Fraction(0))/len(sub);eight=sum(all8,Fraction(0))/n
    assert zero_extreme and cap==full*Fraction(n,len(sub)) and eight==full*Fraction(9,8)
    identity={'run':label,'n':n,'n_sub':len(sub),'full_gap_fraction':str(full),'full_gap_pp':float(full*100),'multiplier':n/len(sub),'capture_gap_pp':float(cap*100),'all8_gap_pp':float(eight*100),'zero_K0_K9':zero_extreme,'exact_capture_identity':True,'exact_all8_identity':True}
    out['identities'].append(identity)
    out['runs'][label]={'quartiles':rules['quartiles'][label],'strata':run,'low_half_guided_rescue_fraction':float(gh[q<=2].sum()/gh.sum()),'low_half_control_rescue_fraction':float(ch[q<=2].sum()/ch.sum()),'low_half_duplicate_rescue_fraction':float(dh[q<=2].sum()/dh.sum())}
old=json.loads((R/'presubmission_20261018/additional_results.json').read_text())
def find_margin(x,path=''):
    found=[]
    if isinstance(x,dict):
        for k,v in x.items():
            if 'margin' in k.lower():found.append({'path':path+'/'+k,'value':v})
            else:found.extend(find_margin(v,path+'/'+k))
    elif isinstance(x,list):
        for i,v in enumerate(x):found.extend(find_margin(v,path+'/'+str(i)))
    return found
out['historical_margin_record']={'source':'presubmission_20261018/additional_results.json','sha256':sha(R/'presubmission_20261018/additional_results.json'),'definition':'Planning/equivalence-margin containment and BCa sensitivity, distinct from baseline top-1 minus top-2 confidence. Prior values copied unchanged.','values':find_margin(old)}
refs={x['sample_id']:x for x in map(json.loads,(R/'additional_controls_20261018/positive_control/main/references.jsonl').read_text().splitlines())}
rows=[x for x in csv.DictReader((R/'additional_controls_20261018/question_level_results.csv').open(encoding='utf-8-sig')) if x['experiment']=='positive_control']
out['SLAKE_question_only']={}
for model in ['2b','4b']:
    rr=[x for x in rows if x['model']==model];assert len(rr)==114
    labels=collections.Counter();classes=collections.Counter();truth=collections.Counter();correct=collections.Counter();confusion=collections.defaultdict(collections.Counter);byimage=collections.defaultdict(list)
    for x in rr:
        p=R/'additional_controls_20261018/positive_control/main/inputs'/(x['sample_id']+'.json')
        # Input files are located in the frozen input JSONL; load the per-question mapping below.
        candidates=list((R/'additional_controls_20261018/positive_control/main').glob('*input*.jsonl'))
        if not candidates:candidates=list((R/'additional_controls_20261018/positive_control').glob('*input*.jsonl'))
        if p.exists():meta=json.loads(p.read_text())
        else:
            assert candidates,'Need original permuted choice mapping'
            if 'inputmap' not in locals():inputmap={z['sample_id']:z for z in map(json.loads,candidates[0].read_text(encoding='utf-8').splitlines())}
            meta=inputmap[x['sample_id']]
        options=meta.get('options',meta.get('choices'))
        assert options is not None,meta.keys()
        if isinstance(options,dict):predclass=options[x['Q_MATCHED_answer']]
        else:predclass=options['ABCD'.index(x['Q_MATCHED_answer'])]
        answer=refs[x['sample_id']]['answer_text'];labels[x['Q_MATCHED_answer']]+=1;classes[predclass]+=1;truth[answer]+=1
        ok=int(x['Q_MATCHED_answer']==x['reference']);correct[answer]+=ok;confusion[answer][predclass]+=1;byimage[x['image_id']].append(ok)
    out['SLAKE_question_only'][model.upper()]={'n':114,'images':len(byimage),'answer_labels':dict(labels),'predicted_classes':dict(classes),'reference_classes':dict(truth),'correct_by_class':dict(correct),'confusion':{k:dict(v) for k,v in confusion.items()},'question_accuracy':sum(correct.values())/114,'image_weighted_accuracy':float(np.mean([np.mean(v) for v in byimage.values()]))}
for name,data in [('margin_results.csv',margin_rows),('question_level_revision.csv',question_rows),('capture_identity.csv',out['identities'])]:
    with (A/name).open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
(A/'revision_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({'status':'COMPLETE','margin':{k:v['strata'] for k,v in out['runs'].items()},'identity':out['identities'],'SLAKE':out['SLAKE_question_only']},indent=2))
