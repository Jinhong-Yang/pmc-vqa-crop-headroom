"""Independent check of NEW results only; prior published estimates stay fixed."""
from pathlib import Path
from fractions import Fraction
import json,csv,hashlib,sys,collections
A=Path(__file__).resolve().parent;R=A.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
rules=json.loads((A/'frozen_rules.json').read_text());results=json.loads((A/'revision_results.json').read_text())
frozen=json.loads((A/'freeze_receipt.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(A/'frozen_rules.json')==frozen['rules_sha256'] and sha(A/'run_analyses.py')==frozen['code_sha256']
flat=list(csv.DictReader((R/'window_audit_20261019/window_outcomes.csv').open(encoding='utf-8-sig')))
checks=[]
for ix,label in enumerate(rules['quartiles']):
    cohort,model=label.lower().split('/');rows=[x for x in flat if x['cohort']==cohort and x['model']==model]
    scores=[];h=hashlib.sha256();differences=[]
    for x in rows:
        p=R/rules['sources'][label]['raw_directory']/(x['sample_id']+'.json');blob=p.read_bytes();h.update(x['sample_id'].encode()+hashlib.sha256(blob).digest());v=json.loads(blob)['scores']
        probs=v['E']['option_probs'];largest=max(probs);second=sorted(probs)[-2];b=int(v['E']['answer']==x['reference']);g=int(v['ROI_HIGH']['answer']==x['reference']);cc=[int(v['ROI_RANDOM_'+str(s)]['answer']==x['reference']) for s in [1,7,42]];du=int(v['ROI_DUPLICATE']['answer']==x['reference'])
        assert int(x['baseline'])==b
        scores.append((largest-second,b,g,sum(cc),du,v['E']['answer']!=v['ROI_HIGH']['answer']))
        k=sum(int(x['window_'+str(j)]) for j in range(9));differences.append(Fraction((1-b)*(9*g-k),9))
    assert h.hexdigest()==rules['sources'][label]['raw_digest']
    arr=np.array(scores);bounds=np.quantile(arr[:,0],[.25,.5,.75]);assert np.array_equal(bounds,rules['quartiles'][label])
    # Explicit inequalities independently reproduce membership and point statistics.
    limits=[-float('inf'),*bounds,float('inf')];rng=np.random.default_rng(2026102011+ix);maxdev=0.
    for j,row in enumerate(results['runs'][label]['strata']):
        z=arr[(arr[:,0]>limits[j])&(arr[:,0]<=limits[j+1])];b,g,c,du=z[:,1],z[:,2],z[:,3]/3,z[:,4]
        assert len(z)==row['n'];d=(1-b)*(g-c);values,counts=np.unique(d,return_counts=True);draws=rng.multinomial(len(z),counts/len(z),20000)@values/len(z)
        ci=np.quantile(draws,[.025,.975]);maxdev=max(maxdev,*abs(ci-np.array([row['ci_low'],row['ci_high']])))
        for key,value in [('baseline_accuracy',b.mean()),('guided_headroom',((1-b)*g).mean()),('control_mean_headroom',((1-b)*c).mean()),('duplicate_headroom',((1-b)*du).mean()),('guided_minus_control',d.mean()),('guided_rescues',((1-b)*g).sum()),('guided_harms',(b*(1-g)).sum()),('guided_answer_changes',z[:,5].sum())]:assert abs(value-row[key])<1e-12,(label,j,key)
    assert maxdev<.005,(label,maxdev)
    identity=next(z for z in results['identities'] if z['run']==label);assert str(sum(differences)/len(rows))==identity['full_gap_fraction']
    checks.append({'run':label,'all_raw_records_and_quartile_statistics':'PASS','independent_multinomial_CI_max_deviation_pp':maxdev*100,'exact_fraction_identity':'PASS'})
meta={v['sample_id']:v for v in map(json.loads,(R/'additional_controls_20261018/positive_control/main/inputs.jsonl').read_text().splitlines())}
rr=list(csv.DictReader((R/'additional_controls_20261018/question_level_results.csv').open(encoding='utf-8-sig')))
for model in ['2B','4B']:
    rows=[v for v in rr if v['experiment']=='positive_control' and v['model']==model.lower()];expected=results['SLAKE_question_only'][model]
    pred=collections.Counter(meta[x['sample_id']]['options'][ord(x['Q_MATCHED_answer'])-65] for x in rows)
    assert dict(pred)==expected['predicted_classes'] and dict(collections.Counter(x['Q_MATCHED_answer'] for x in rows))==expected['answer_labels']
    assert sum(expected['correct_by_class'].values())==sum(x['Q_MATCHED_answer']==x['reference'] for x in rows)
report={'status':'PASS','scope':'New revision margin quartiles, paired differences, confidence intervals, exact identities and SLAKE question-only distributions. Existing reported estimates were not rerun or replaced.','draws':20000,'independent_seeds':[2026102011,2026102012,2026102013,2026102014],'checks':checks,'SLAKE_label_and_class_mapping':'PASS'}
(A/'verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))
