S12 File: post hoc presentation controls and selector diagnostics, 24 October 2026.

Primary 2B choice-order perturbation: 128 excluded technical pilot questions, 2048 main questions. Quarter-window sensitivity uses the pilot only. Existing-data calibration/position analyses cover all four model/cohort evaluations. The protocol was fixed before this extension, after original outcomes; it is not public preregistration.

CPU reproduction (Python + NumPy):
  python reproduce_release.py
This verifies released row-level data and regenerates 20,000-draw paired bootstrap intervals; it does not access original images or model weights.

Raw inference records and technical gates are in predictions/, runtime.json and seal files. run.py and prepare.py record the historical local inference procedure and original paths; full inference requires the previously archived source inputs/images and local pinned Qwen weights. analyze_existing.py and score_new.py record source-archive joins; the portable reproduction uses included numerical records. No source image pixels, question/option text, or model weights are redistributed.

Existing_records contain reference option IDs, baseline probabilities, guided/control/duplicate answers, nine window correctness values, selected indices and source hashes. New_records contain identity-mapped answers, display-to-identity permutations, source hashes and quarter boxes. Original mappings and source metadata are in S2-S7.

Current figure sources are included. create_figure1.py runs locally; build_figures.py records the historical workspace build. figure_S2_source_values.json makes every S2 estimate inspectable without the original workspace. No equivalence band is used. Figures 2,3 and S1 are unchanged.

Data: CC BY 4.0. Code: MIT, consistent with the repository license. OpenAI Codex assisted implementation, verification, plotting and documentation; the recorded model outputs are actual inference results.
