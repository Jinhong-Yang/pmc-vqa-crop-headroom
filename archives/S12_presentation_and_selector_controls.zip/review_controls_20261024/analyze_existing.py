from pathlib import Path
import json,csv,hashlib,datetime
import numpy as np
E=Path(__file__).resolve().parent;R=E.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def ci(x,seed,alpha=.05):
 x=np.asarray(x,float);v,c=np.unique(x,return_counts=True);rng=np.random.default_rng(seed)
 draws=rng.multinomial(len(x),c/c.sum(),size=20000)@v/len(x)
 return [float(q) for q in np.quantile(draws,[alpha/2,1-alpha/2])]
def ece(prob,correct,k):
 conf=prob.max(1);bins=np.minimum((conf*k).astype(int),k-1);rows=[]
 for b in range(k):
  m=bins==b
  rows.append({'bin':b,'lower':b/k,'upper':(b+1)/k,'n':int(m.sum()),'accuracy':float(correct[m].mean()) if m.any() else None,'confidence':float(conf[m].mean()) if m.any() else None})
 val=sum(q['n']/len(prob)*abs(q['accuracy']-q['confidence']) for q in rows if q['n'])
 return float(val),rows
grid=list(csv.DictReader((R/'window_audit_20261019/window_outcomes.csv').open(encoding='utf-8-sig')))
result={'status':'POST_HOC_EXISTING_DATA_REANALYSIS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'grid_sha256':sha(R/'window_audit_20261019/window_outcomes.csv'),'evaluations':[]}
records=[];position=[]
for z,(cohort,model,folder) in enumerate([('primary','2b','controlled_replication'),('primary','4b','controlled_replication_4b'),('curated','2b','curated_replication_2b'),('curated','4b','curated_replication_4b')]):
 rows=[q for q in grid if q['cohort']==cohort and q['model']==model];n=len(rows);assert n==(2048 if cohort=='primary' else 825)
 assert len({r['sample_id'] for r in rows})==n
 B=np.array([int(q['baseline']) for q in rows]);W=np.array([[int(q[f'window_{j}']) for j in range(9)] for q in rows]);sel=np.array([int(q['selected_window']) for q in rows]);G=W[np.arange(n),sel]
 probs=[];refs=[];detailed=[]
 seal=json.loads((R/folder/'main/prediction_seal.json').read_text());hashes={Path(f['path']).name:f['sha256'] for f in seal['files']}
 for i,q in enumerate(rows):
  p=R/folder/'main/predictions'/(q['sample_id']+'.json');assert sha(p)==hashes[p.name];pred=json.loads(p.read_text(encoding='utf-8'))
  scores=pred['scores'];ref='ABCD'.index(q['reference']);base=scores['E'];prob=np.asarray(base['option_probs']);assert prob.shape==(4,) and np.isclose(prob.sum(),1)
  assert int('ABCD'.index(base['answer'])==ref)==B[i]
  assert int(scores['ROI_HIGH']['answer']==q['reference'])==G[i]
  probs.append(prob);refs.append(ref)
  row={'cohort':cohort,'model':model,'sample_id':q['sample_id'],'reference':q['reference'],'baseline_answer':base['answer'],'baseline_probs':base['option_probs'],'guided_answer':scores['ROI_HIGH']['answer'],'control_answers':[scores['ROI_RANDOM_'+str(s)]['answer'] for s in [1,7,42]],'duplicate_answer':scores['ROI_DUPLICATE']['answer'],'window_correct':W[i].tolist(),'selected_window':int(sel[i]),'source_sha256':sha(p)}
  records.append(row);detailed.append(row)
 probs=np.asarray(probs);refs=np.asarray(refs);predid=probs.argmax(1);assert np.array_equal((predid==refs).astype(int),B)
 top2=np.argsort(-probs,axis=1,kind='stable')[:,1];alternative_ref=probs[np.arange(n),refs]/np.maximum(1-probs.max(1),1e-12)
 correction=[]
 for condition in ['guided','control']:
  targets=np.array([['ABCD'.index(q['guided_answer'])] if condition=='guided' else ['ABCD'.index(a) for a in q['control_answers']] for q in detailed])
  mask=(B[:,None]==0)&(targets!=predid[:,None]);count=int(mask.sum())
  correction.append({'condition':condition,'changed_baseline_errors':count,'observed_corrected':int(((targets==refs[:,None])&mask).sum()),'observed_correction_rate':float(((targets==refs[:,None])&mask).sum()/count),'second_choice_correct_rate':float(np.broadcast_to((top2==refs)[:,None],mask.shape)[mask].mean()),'conditional_probability_reference':float(np.broadcast_to(alternative_ref[:,None],mask.shape)[mask].mean())})
 val,bins=ece(probs,B,10);v15,_=ece(probs,B,15)
 cal={'n':n,'baseline_accuracy':float(B.mean()),'mean_confidence':float(probs.max(1).mean()),'ECE10':val,'ECE15':v15,'brier_multiclass_sum':float(np.square(probs-np.eye(4)[refs]).sum(1).mean()),'NLL':float(-np.log(np.maximum(probs[np.arange(n),refs],1e-12)).mean()),'bins10':bins}
 positions=[]
 for j in range(9):
  oracle=(1-B)*(G-W[:,j]);direct=G-W[:,j]
  r={'cohort':cohort,'model':model,'window':j,'x_offset':[0,.25,.5][j%3],'y_offset':[0,.25,.5][j//3],'n':n,'position_direct_accuracy':float(W[:,j].mean()),'position_oracle_accuracy':float(np.maximum(B,W[:,j]).mean()),'selected_minus_position_oracle':float(oracle.mean()),'oracle_ci95':ci(oracle,2026102410+z*9+j),'oracle_ci_simultaneous9':ci(oracle,2026102410+z*9+j,.05/9),'selected_minus_position_direct':float(direct.mean()),'direct_ci95':ci(direct,2026102450+z*9+j)}
  positions.append(r);position.append(r)
 result['evaluations'].append({'cohort':cohort,'model':model,'calibration':cal,'correction_references':correction,'positions':positions})
(E/'existing_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
(E/'existing_records.jsonl').write_text(''.join(json.dumps(q)+'\n' for q in records),encoding='utf-8')
with (E/'position_comparisons.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=position[0].keys());w.writeheader();w.writerows(position)
print(json.dumps([{'cohort':x['cohort'],'model':x['model'],'ece':x['calibration']['ECE10'],'center_oracle':x['positions'][4]['selected_minus_position_oracle'],'center_ci':x['positions'][4]['oracle_ci95'],'correction':x['correction_references']} for x in result['evaluations']],indent=2))
