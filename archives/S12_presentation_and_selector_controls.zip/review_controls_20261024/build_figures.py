from pathlib import Path
import json,shutil,runpy,sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'dependencies'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
V=Path(__file__).resolve().parent;R=V.parent;O=V/'output/figures'
src=(R/'plos_alignment_revision_20261020/public_repository/final_resources/create_figure1.py').read_text(encoding='utf-8')
src=src.replace("O=V/'figures'","O=V/'output/figures'")
src=src.replace('Frozen models and protocols; linkage excludes verified prior-cohort and cross-cohort reuse.','Frozen models; local protocol freezes and linkage exclusions (not external registration).')
src=src.replace('Prespecified primary: 2B, primary cohort','Locally prespecified primary: 2B, primary cohort')
(V/'create_figure1.py').write_text(src,encoding='utf-8');runpy.run_path(str(V/'create_figure1.py'))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'ps.fonttype':42,'pdf.fonttype':42,'savefig.facecolor':'white'})
labels=['Primary/2B','Primary/4B','Curated/2B','Curated/4B'];folders=['controlled_replication','controlled_replication_4b','curated_replication_2b','curated_replication_4b']
old=json.loads((R/'presubmission_20261018/additional_results.json').read_text())
fig,ax=plt.subplots(figsize=(7,3.8));ax.axvline(0,color='#555555',lw=.8);ys=np.arange(4)[::-1];data=[]
for i,(label,folder) in enumerate(zip(labels,folders)):
 a=json.loads((R/'reproducibility_bundle/reported_results'/(folder+'__main.json')).read_text());v=next(v for v in a['oracle_contrasts'] if v['comparison']=='roi');b=old['runs'][label]['crop_overlap']['nonoverlap_oracle_contrast']
 for shift,t,c,nm,marker in [(.11,{'estimate':v['difference'],'ci95':v['ci'],'n':v['n']},'#007F89','All controls','o'),(-.11,b,'#C56321','Zero overlap','s')]:
  m=t['estimate']*100;lo,hi=np.array(t['ci95'])*100
  ax.errorbar(m,ys[i]+shift,xerr=[[m-lo],[hi-m]],fmt=marker,color=c,capsize=3,label=nm if i==0 else None)
  ax.text(2.7,ys[i]+shift,f"n = {t['n']:,}",va='center',size=8);data.append({'cohort_model':label,'condition':nm,**t})
ax.set_yticks(ys,labels);ax.set_xlim(-2.8,4);ax.set_xlabel('Guided minus mean control oracle (percentage points)');ax.legend(frameon=False,ncol=2,loc='upper center',bbox_to_anchor=(.5,1.18));fig.tight_layout()
for ext in ['png','eps']:fig.savefig(O/f'FigS2.{ext}',dpi=400,bbox_inches='tight')
with Image.open(O/'FigS2.png') as im:im.convert('RGB').save(O/'FigS2.tif',compression='tiff_lzw',dpi=(400,400))
(V/'figure_S2_source_values.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
plt.close(fig)
for p in O.glob('Fig4.*'):p.unlink()
shutil.copytree(O,V/'figures',dirs_exist_ok=True)
print('Updated Figure 1 local-status wording; former Figure 4 moved to S2 without an equivalence band.')
