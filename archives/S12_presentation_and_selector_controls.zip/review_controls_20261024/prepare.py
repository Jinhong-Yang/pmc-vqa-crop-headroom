from pathlib import Path
import json,hashlib,datetime,itertools,shutil
E=Path(__file__).resolve().parent;R=E.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (E/'protocol.json').exists()
shutil.copy2(R/'additional_controls_20261018/inference_common.py',E/'inference_common.py')
perms=[list(p) for p in itertools.permutations(range(4)) if all(p[j]!=j for j in range(4))]
assert len(perms)==9
assign=[]
for split in ['pilot','main']:
 xs=[json.loads(s) for s in (R/'controlled_replication'/split/'inputs.jsonl').read_text(encoding='utf-8').splitlines()]
 for x in xs:
  index=int(hashlib.sha256(('2026102401|'+x['sample_id']).encode()).hexdigest(),16)%len(perms)
  assign.append({'split':split,'sample_id':x['sample_id'],'new_position_to_old_position':perms[index]})
(E/'permutations.json').write_text(json.dumps(assign,indent=2),encoding='utf-8')
protocol={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'POST_HOC_EXTENSION_FIXED_BEFORE_NEW_INFERENCE','scope':'Primary Qwen3-VL-2B, existing disjoint 128 pilot and 2048 main questions; no new confirmatory claim.',
'order_control':'Single deterministic SHA256-assigned derangement of all four choice positions. Original question, instruction, image pixels and model settings retained. Responses and probabilities mapped back to original option identities before scoring. No new visual information. This is a presentation perturbation, not stochastic repeated sampling.',
'quarter_window':'Pilot only: quarter width/height crop centered at the original SigLIP-selected half-window center, clipped to image bounds and resized to the original crop rendered size. Global-plus-crop prompt and tokens retained. This tests tighter spatial extent at a fixed selected center, not a newly trained/re-ranked selector; no main expansion based on pilot efficacy.',
'pilot_conditions':['E_REPEAT','ORDER_PERMUTED','QUARTER_SELECTED_CENTER'], 'main_conditions':['ORDER_PERMUTED'],
'pilot_gate':'128/128 records; E_REPEAT >=99% original answer agreement and max probability discrepancy <=0.02; official scoring logprob error <1e-4 on first two pilot items for original and permuted input; all finite normalized four-label probabilities; order-control image-token count unchanged; quarter-window pair tokens equal ROI_HIGH. Gate uses no reference labels or efficacy.',
'main_stop':'No optional stopping; all 2048 questions, preserve completed records, abort on failure and investigate.',
'statistics':{'draws':20000,'seed':2026102401,'unit':'question; one per original linked group','intervals':'exploratory paired percentile 95%; no confirmatory significance claim','order_endpoints':['accuracy, baseline-error rescues, baseline-correct harms, semantic answer changes','oracle headroom versus guided crop and duplicate-global','overlap of rescues with crop and duplicate-global, descriptive only'], 'quarter_endpoints':['paired quarter-minus-half selected direct and oracle contrasts on pilot only']},
'existing_data_analyses':{'position':'All nine fixed-window rules reported. Primary descriptive center rule (j=4) is not chosen by observed accuracy; selected-minus-position oracle and direct paired intervals; Bonferroni simultaneous 9-window intervals within each model/cohort. Uniform-window comparison retained.', 'calibration':'Baseline top-label ECE, 10 fixed equal-width confidence bins; sensitivity with 15 bins; multiclass Brier and NLL. Descriptive, no calibration fitting.','correction_reference':'Baseline second-choice correctness among changed answers; baseline probability of reference conditional on alternatives to baseline argmax. Descriptive model-dependent diagnostics, not chance/null tests.'},
'bindings':{str(R/'controlled_replication'/split/name):sha(R/'controlled_replication'/split/name) for split in ['pilot','main'] for name in ['inputs.jsonl','prediction_seal.json']},
'code_bindings':{name:sha(E/name) for name in ['run.py','inference_common.py','permutations.json']}}
(E/'protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
print(json.dumps({'status':protocol['status'],'protocol_sha256':sha(E/'protocol.json'),'assignments':len(assign)}))
