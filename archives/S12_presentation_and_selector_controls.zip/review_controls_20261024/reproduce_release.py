"""Recompute the released extension using only NumPy and the adjacent records."""
from pathlib import Path
import json,math,hashlib
from collections import Counter
import numpy as np
E=Path(__file__).resolve().parent
def read(name):return [json.loads(line) for line in (E/name).read_text(encoding='utf-8').splitlines()]
def check(a,b):assert np.allclose(a,b,rtol=0,atol=1e-11),(a,b)
def bootstrap(values,seed,alpha=.05):
 counts=Counter(values);keys=sorted(counts);n=len(values)
 draws=np.random.default_rng(seed).multinomial(n,[counts[k]/n for k in keys],20000)
 means=np.sum(draws*np.asarray(keys)[None,:],axis=1)/n
 return np.quantile(means,[alpha/2,1-alpha/2])
records=read('existing_records.jsonl');expected=json.loads((E/'existing_results.json').read_text());nchecks=0
for z,e in enumerate(expected['evaluations']):
 rs=[r for r in records if r['model']==e['model'] and r['cohort']==e['cohort']];n=len(rs);assert len({r['sample_id'] for r in rs})==n
 correct=[r['reference']==r['baseline_answer'] for r in rs];conf=[max(r['baseline_probs']) for r in rs]
 def calc_ece(k):
  sums={b:[0,0.,0.] for b in range(k)}
  for r,c,p in zip(rs,correct,conf):
   b=min(math.floor(p*k),k-1);sums[b][0]+=1;sums[b][1]+=c;sums[b][2]+=p
  return sum(abs(a-c)/n for count,a,c in sums.values() if count)
 cal=e['calibration'];check(sum(correct)/n,cal['baseline_accuracy']);check(sum(conf)/n,cal['mean_confidence']);check(calc_ece(10),cal['ECE10']);check(calc_ece(15),cal['ECE15'])
 check(sum(sum((p-(j=='ABCD'.index(r['reference'])))**2 for j,p in enumerate(r['baseline_probs'])) for r in rs)/n,cal['brier_multiclass_sum'])
 check(-sum(math.log(max(r['baseline_probs']['ABCD'.index(r['reference'])],1e-12)) for r in rs)/n,cal['NLL'])
 for j,t in enumerate(e['positions']):
  oracle=[int(not b)*(r['window_correct'][r['selected_window']]-r['window_correct'][j]) for b,r in zip(correct,rs)]
  direct=[r['window_correct'][r['selected_window']]-r['window_correct'][j] for r in rs]
  check(sum(oracle)/n,t['selected_minus_position_oracle']);check(sum(direct)/n,t['selected_minus_position_direct'])
  check(bootstrap(oracle,2026102410+z*9+j),t['oracle_ci95']);check(bootstrap(oracle,2026102410+z*9+j,.05/9),t['oracle_ci_simultaneous9']);check(bootstrap(direct,2026102450+z*9+j),t['direct_ci95']);nchecks+=5
 for c in e['correction_references']:
  samples=[]
  for r in rs:
   answers=[r['guided_answer']] if c['condition']=='guided' else r['control_answers']
   for a in answers:
    if r['baseline_answer']!=r['reference'] and a!=r['baseline_answer']:samples.append((r,a))
  check(len(samples),c['changed_baseline_errors']);check(sum(a==r['reference'] for r,a in samples)/len(samples),c['observed_correction_rate'])
  check(sum('ABCD'[sorted(range(4),key=lambda j:-r['baseline_probs'][j])[1]]==r['reference'] for r,a in samples)/len(samples),c['second_choice_correct_rate'])
  check(sum(r['baseline_probs']['ABCD'.index(r['reference'])]/max(1-max(r['baseline_probs']),1e-12) for r,a in samples)/len(samples),c['conditional_probability_reference']);nchecks+=4
new=read('new_records.jsonl');reported=json.loads((E/'new_results.json').read_text())
for split,out in reported['splits'].items():
 rs=[r for r in new if r['split']==split];n=len(rs);assert n==out['n'];b=[int(r['reference']==r['baseline_answer']) for r in rs]
 for j,key in enumerate(['permuted','guided','duplicate']+(['quarter'] if split=='pilot' else [])):
  c=[int(r['reference']==r[key+'_answer']) for r in rs];t=out['conditions'][key];rescues=[int(not bb)*cc for bb,cc in zip(b,c)];direct=[cc-bb for bb,cc in zip(b,c)];oracle=[max(bb,cc) for bb,cc in zip(b,c)]
  check(sum(rescues),t['rescues']);check(sum(bb*(1-cc) for bb,cc in zip(b,c)),t['harms']);check(sum(r[key+'_answer']!=r['baseline_answer'] for r in rs),t['semantic_changes'])
  for offset,name,vals in [(0,'accuracy',c),(1,'oracle_accuracy',oracle),(2,'headroom',rescues),(3,'direct_minus_baseline',direct)]:
   check(sum(vals)/n,t[name]['estimate']);check(bootstrap(vals,2026102401+j*10+offset),t[name]['ci95']);nchecks+=2
 for j,control in enumerate(['guided','duplicate']):
  d=[int(r['permuted_answer']==r['reference'])-int(r[control+'_answer']==r['reference']) for r in rs];a=[(1-bb)*dd for bb,dd in zip(b,d)]
  for suffix,vals,seed in [('oracle',a,2026102470+j),('direct',d,2026102472+j)]:
   t=out['contrasts']['permuted_minus_'+control+'_'+suffix];check(sum(vals)/n,t['estimate']);check(bootstrap(vals,seed),t['ci95']);nchecks+=2
  intersection=sum(not bb and r['permuted_answer']==r['reference'] and r[control+'_answer']==r['reference'] for bb,r in zip(b,rs));check(intersection,out['rescue_overlaps'][control]['intersection'])
 if split=='pilot':
  direct=[int(r['quarter_answer']==r['reference'])-int(r['guided_answer']==r['reference']) for r in rs]
  for suffix,vals,seed in [('oracle',[(1-bb)*d for bb,d in zip(b,direct)],2026102480),('direct',direct,2026102481)]:
   t=out['contrasts']['quarter_minus_half_'+suffix];check(sum(vals)/n,t['estimate']);check(bootstrap(vals,seed),t['ci95']);nchecks+=2
 for r in rs:
  perm=r['permutation'];assert sorted(perm)==list(range(4));assert all(j!=k for j,k in enumerate(perm))
  assert r['permuted_answer']=='ABCD'[perm['ABCD'.index(r['permuted_display_answer'])]]
receipt={'status':'PASS','existing_records':len(records),'new_records':len(new),'numeric_checks':nchecks,'method':'Independent scalar counts/calibration and regenerated multinomial paired bootstrap distributions; no model inference.', 'files':{name:hashlib.sha256((E/name).read_bytes()).hexdigest() for name in ['existing_records.jsonl','new_records.jsonl','existing_results.json','new_results.json']}}
(E/'portable_reproduction_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt,indent=2))
