from inference_common import *

PAIR='The first image is the global view. The second image is an additional view of the same figure; it may or may not contain useful detail.\n'
def main():
 protocol=json.loads((E/'protocol.json').read_text());ph=sha(E/'protocol.json')
 for name,h in protocol['code_bindings'].items():assert sha(E/name)==h,name
 for p,h in protocol['bindings'].items():assert sha(Path(p))==h,p
 assignments={(x['split'],x['sample_id']):x['new_position_to_old_position'] for x in json.loads((E/'permutations.json').read_text())}
 O=E/'predictions';O.mkdir(exist_ok=True)
 lock=E/'gpu.lock'
 with lock.open('x') as f:json.dump({'pid':os.getpid(),'at':now()},f)
 started=time.perf_counter()
 try:
  scorer=Scorer('2b');dump(E/'runtime.json',scorer.meta)
  for split in ['pilot','main']:
   if split=='main':assert json.loads((E/'pilot_gate.json').read_text())['pass']
   xs=read(R/'controlled_replication'/split/'inputs.jsonl');files=[];checks=[]
   source_seal=json.loads((R/'controlled_replication'/split/'prediction_seal.json').read_text())
   source_hashes={Path(f['path']).name:f['sha256'] for f in source_seal['files']}
   for i,x in enumerate(xs):
    target=O/split/(x['sample_id']+'.json');source=R/'controlled_replication'/split/'predictions'/(x['sample_id']+'.json')
    assert sha(source)==source_hashes[source.name]
    old=json.loads(source.read_text(encoding='utf-8'));perm=assignments[(split,x['sample_id'])]
    if target.exists():
     rec=json.loads(target.read_text(encoding='utf-8'));assert rec['protocol_sha256']==ph
    else:
     tick=time.perf_counter();base=image(x['image_path']);xp={**x,'options':[x['options'][j] for j in perm]};scores={}
     scores['ORDER_PERMUTED']=scorer.score(base,prompt(xp));s=scores['ORDER_PERMUTED']
     assert s['image_tokens']==old['scores']['E']['image_tokens']
     s['answer_original_identity']='ABCD'[perm['ABCD'.index(s['answer'])]]
     s['option_probs_original_identity']=[s['option_probs'][perm.index(j)] for j in range(4)]
     technical=[];quarter_box=None
     if split=='pilot':
      repeat=scorer.score(base,prompt(x));scores['E_REPEAT']=repeat
      technical.append({'condition':'E_REPEAT','answer_match':repeat['answer']==old['scores']['E']['answer'],'max_probability_error':max(abs(a-b) for a,b in zip(repeat['option_probs'],old['scores']['E']['option_probs']))})
      with Image.open(x['image_path']) as im:full=ImageOps.exif_transpose(im).convert('RGB')
      geom=old['observations']['roi'];box=geom['boxes'][geom['chosen']];cx=(box[0]+box[2])/2;cy=(box[1]+box[3])/2
      qw=max(1,round(full.width/4));qh=max(1,round(full.height/4));left=max(0,min(full.width-qw,round(cx-qw/2)));top=max(0,min(full.height-qh,round(cy-qh/2)))
      quarter_box=[left,top,left+qw,top+qh];crop=full.crop(quarter_box).resize(tuple(geom['rendered_size']),Image.Resampling.LANCZOS)
      scores['QUARTER_SELECTED_CENTER']=scorer.score([base,crop],PAIR+prompt(x))
      assert scores['QUARTER_SELECTED_CENTER']['image_tokens']==old['scores']['ROI_HIGH']['image_tokens']
      if i<2:
       for condition,xx in [('E_REPEAT',x),('ORDER_PERMUTED',xp)]:
        official=scorer.score(base,prompt(xx),official=True);err=max(abs(a-b) for a,b in zip(official['option_log_probs'],scores[condition]['option_log_probs']))
        assert err<1e-4;technical.append({'condition':condition,'official_logprob_error':err})
     rec={'sample_id':x['sample_id'],'split':split,'protocol_sha256':ph,'source_sha256':sha(source),'image_sha256':sha(Path(x['image_path'])),'new_position_to_old_position':perm,'quarter_box':quarter_box,'scores':scores,'technical_checks':technical,'wall_s':time.perf_counter()-tick,'at':now()}
     dump(target,rec)
    files.append({'path':str(target.relative_to(E)),'sha256':sha(target)});checks.extend(rec['technical_checks'])
    if (i+1)%32==0 or i==len(xs)-1:
     progress={'split':split,'done':i+1,'total':len(xs),'wall_s':time.perf_counter()-started,'at':now()};dump(E/'progress.json',progress);print(json.dumps(progress),flush=True)
   dump(E/(split+'_seal.json'),{'status':'SEALED_BEFORE_NEW_REFERENCE_SCORING','protocol_sha256':ph,'files':files,'at':now()})
   if split=='pilot':
    repeats=[c for c in checks if 'answer_match' in c];rate=sum(c['answer_match'] for c in repeats)/len(repeats);err=max(c['max_probability_error'] for c in repeats)
    gate={'pass':len(repeats)==128 and rate>=.99 and err<=.02,'n':len(repeats),'answer_agreement':rate,'max_probability_difference':err,'official_checks':[c for c in checks if 'official_logprob_error' in c],'at':now()};dump(E/'pilot_gate.json',gate);assert gate['pass'],gate
  print('COMPLETE',flush=True)
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':main()
