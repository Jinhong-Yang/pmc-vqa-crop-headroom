from pathlib import Path
import json,hashlib,datetime
import numpy as np
E=Path(__file__).resolve().parent;R=E.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def stat(x,seed):
 x=np.asarray(x,float);v,c=np.unique(x,return_counts=True);draws=np.random.default_rng(seed).multinomial(len(x),c/c.sum(),size=20000)@v/len(x)
 return {'estimate':float(x.mean()),'ci95':[float(t) for t in np.quantile(draws,[.025,.975])]}
def describe(B,C,answer,baseanswer,seed):
 rescue=(1-B)*C;harm=B*(1-C)
 return {'n':len(B),'accuracy':stat(C,seed),'oracle_accuracy':stat(np.maximum(B,C),seed+1),'headroom':stat(rescue,seed+2),'direct_minus_baseline':stat(C-B,seed+3),'rescues':int(rescue.sum()),'harms':int(harm.sum()),'semantic_changes':int(np.sum(answer!=baseanswer))}
result={'status':'COMPLETE','analysis_role':'post hoc extension','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'protocol_sha256':sha(E/'protocol.json'),'splits':{}}
merged=[]
for split in ['pilot','main']:
 seal=json.loads((E/(split+'_seal.json')).read_text());assert seal['status']=='SEALED_BEFORE_NEW_REFERENCE_SCORING'
 refs={q['sample_id']:q['reference'] for q in [json.loads(s) for s in (R/'controlled_replication'/split/'references.jsonl').read_text(encoding='utf-8').splitlines()]}
 for f in seal['files']:
  p=E/f['path'];assert sha(p)==f['sha256'];rec=json.loads(p.read_text(encoding='utf-8'));sid=rec['sample_id'];src=R/'controlled_replication'/split/'predictions'/(sid+'.json');assert sha(src)==rec['source_sha256'];old=json.loads(src.read_text(encoding='utf-8'))
  s=rec['scores']['ORDER_PERMUTED'];perm=rec['new_position_to_old_position'];assert len(set(perm))==4 and all(j!=k for j,k in enumerate(perm))
  assert s['answer_original_identity']=='ABCD'[perm['ABCD'.index(s['answer'])]]
  r={'sample_id':sid,'split':split,'reference':refs[sid],'baseline_answer':old['scores']['E']['answer'],'guided_answer':old['scores']['ROI_HIGH']['answer'],'duplicate_answer':old['scores']['ROI_DUPLICATE']['answer'],'permuted_answer':s['answer_original_identity'],'permuted_display_answer':s['answer'],'permutation':perm,'permuted_probs_original_identity':s['option_probs_original_identity'],'quarter_answer':rec['scores'].get('QUARTER_SELECTED_CENTER',{}).get('answer'),'quarter_box':rec['quarter_box'],'source_prediction_sha256':rec['source_sha256'],'new_prediction_sha256':sha(p)}
  merged.append(r)
 rows=[q for q in merged if q['split']==split];n=len(rows);assert n==(128 if split=='pilot' else 2048)
 ref=np.array([r['reference'] for r in rows]);base=np.array([r['baseline_answer'] for r in rows]);B=(base==ref).astype(int)
 out={'n':n,'baseline_accuracy':float(B.mean()),'conditions':{},'contrasts':{},'rescue_overlaps':{}}
 Cs={}
 for j,condition in enumerate(['permuted','guided','duplicate']+(['quarter'] if split=='pilot' else [])):
  ans=np.array([r[condition+'_answer'] for r in rows]);C=(ans==ref).astype(int);Cs[condition]=C
  out['conditions'][condition]=describe(B,C,ans,base,2026102401+j*10)
 for j,control in enumerate(['guided','duplicate']):
  out['contrasts']['permuted_minus_'+control+'_oracle']=stat((1-B)*(Cs['permuted']-Cs[control]),2026102470+j)
  out['contrasts']['permuted_minus_'+control+'_direct']=stat(Cs['permuted']-Cs[control],2026102472+j)
  out['rescue_overlaps'][control]={'intersection':int(((B==0)&(Cs['permuted']==1)&(Cs[control]==1)).sum()),'permuted_only':int(((B==0)&(Cs['permuted']==1)&(Cs[control]==0)).sum()),'control_only':int(((B==0)&(Cs['permuted']==0)&(Cs[control]==1)).sum())}
 if split=='pilot':
  out['contrasts']['quarter_minus_half_oracle']=stat((1-B)*(Cs['quarter']-Cs['guided']),2026102480)
  out['contrasts']['quarter_minus_half_direct']=stat(Cs['quarter']-Cs['guided'],2026102481)
 result['splits'][split]=out
(E/'new_records.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in merged),encoding='utf-8')
(E/'new_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
