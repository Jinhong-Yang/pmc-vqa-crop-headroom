S13 File: four-order probability averaging and answer-position diagnostics
24 October 2026, post hoc extension

This archive contains all 128 excluded technical-pilot and 2,048 primary 2B main records for four cyclic option orders under E, ROI_HIGH and the three original ROI_RANDOM conditions. Main shift zero reuses sealed original probabilities; the other three shifts are new inference. No outcome-based exclusion or optional stopping was used. Duplicate control windows reuse the same scoring call within a question/order. The technical pilot exactly reproduced all five conditions; scoring checks were recorded before the main experiment.

Map probabilities to original option identity, average four vectors within each condition, and then select the largest mean probability. This is not an oracle over order-specific answers. Ties in the averaged vector use original-identity order. Individual order outcomes preserve the model's displayed-letter tie-breaking. Four cyclic orders balance marginal letter positions but do not enumerate all 24 permutations.

Portable CPU reproduction (Python 3 + NumPy):
  python reproduce_release.py

The reproduction independently recalculates counts, all paired bootstrap intervals, raw-to-compact identity mappings, marginal letter counts, runner-up transitions and the nominal paired correctness reference. It requires no network, model weights or source images. It reads every raw sealed record. The earlier compact records are copied byte-for-byte from S12 and support the descriptive diagnostics.

run.py and prepare.py preserve the actual inference procedure and original local paths. analyze_orders.py and analyze_diagnostics.py preserve the source joins used in the workspace. For full inference, obtain pinned original source data and Qwen weights and reconstruct input text under its original terms as described in S2 and S12. No source pixels, original question/option text or model weights are redistributed here.

All new inference is exploratory and was specified after earlier study outcomes. The protocol hash fixes this extension before its own new inference; it is not external preregistration. One interrupted run retained completed pilot records and was resumed without changing the frozen inference code or conditions. No human clinical annotation audit is claimed.

Study-generated data/documentation: CC BY 4.0. Study code: MIT. OpenAI Codex assisted implementation, execution, verification and documentation. The model answers are actual inference outputs.
