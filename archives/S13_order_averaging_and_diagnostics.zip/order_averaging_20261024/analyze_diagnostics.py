from pathlib import Path
import json,hashlib,math,datetime
from collections import Counter,defaultdict
E=Path(__file__).resolve().parent;R=E.parent;P=R/'review_controls_20261024'
read=lambda p:[json.loads(line) for line in p.read_text(encoding='utf-8').splitlines() if line.strip()]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=read(P/'existing_records.jsonl');new=read(P/'new_records.jsonl')
groups=defaultdict(list)
for row in old:groups[(row['cohort'],row['model'])].append(row)
result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'role':'Descriptive post hoc diagnostics; no causal mechanism identification','source_sha256':{f:sha(P/f) for f in ['existing_records.jsonl','new_records.jsonl','existing_results.json']},'runner_up':[],'letter_positions':[]}
for (cohort,model),rows in groups.items():
 for condition in ['guided','control','duplicate']:
  subsets={k:Counter() for k in ['all_changed','changed_baseline_errors','rescues','harms']}
  for row in rows:
   p=row['baseline_probs'];base='ABCD'.index(row['baseline_answer']);y='ABCD'.index(row['reference']);order=sorted(range(4),key=lambda j:(-p[j],j));assert order[0]==base
   runner=order[1];ties=[j for j in range(4) if j!=base and p[j]==p[runner]]
   targets=row['control_answers'] if condition=='control' else [row[condition+'_answer']]
   for letter in targets:
    ans='ABCD'.index(letter)
    if ans==base:continue
    memberships=['all_changed']+(['changed_baseline_errors'] if base!=y else [])+(['rescues'] if base!=y and ans==y else [])+(['harms'] if base==y else [])
    for name in memberships:
     c=subsets[name];c['n']+=1;c['equals_runner_up']+=int(ans==runner);c['equals_tied_runner_up']+=int(ans in ties);c['runner_up_tied']+=int(len(ties)>1)
  result['runner_up'].append({'cohort':cohort,'model':model,'condition':condition,'strata':{k:{**v,'share':v['equals_runner_up']/v['n'] if v['n'] else None,'tie_inclusive_share':v['equals_tied_runner_up']/v['n'] if v['n'] else None} for k,v in subsets.items()}})
for split in ['pilot','main']:
 rows=[r for r in new if r['split']==split];n=len(rows);out={'split':split,'n':n,'orders':{},'transitions':[]}
 for label in ['original','deranged']:
  refpos=[];predpos=[]
  for r in rows:
   y='ABCD'.index(r['reference']);refpos.append(y if label=='original' else r['permutation'].index(y));predpos.append('ABCD'.index(r['baseline_answer'] if label=='original' else r['permuted_display_answer']))
  out['orders'][label]={'correct_position_counts':[refpos.count(j) for j in range(4)],'predicted_position_counts':[predpos.count(j) for j in range(4)],'per_correct_position':[]}
  for j in range(4):
   indices=[i for i,y in enumerate(refpos) if y==j]
   out['orders'][label]['per_correct_position'].append({'letter':'ABCD'[j],'n':len(indices),'correct':sum(predpos[i]==j for i in indices)})
  correct=sum(a==b for a,b in zip(refpos,predpos));out['orders'][label]['correct']=correct;out['orders'][label]['accuracy']=correct/n
 for a in range(4):
  for b in range(4):
   if a==b:continue
   subset=[r for r in rows if r['reference']=='ABCD'[a] and r['permutation'].index(a)==b]
   bc=sum(r['baseline_answer']==r['reference'] for r in subset);pc=sum(r['permuted_answer']==r['reference'] for r in subset)
   out['transitions'].append({'original_letter':'ABCD'[a],'deranged_letter':'ABCD'[b],'n':len(subset),'original_correct':bc,'deranged_correct':pc,'gain_count':pc-bc})
 rescues=sum(r['baseline_answer']!=r['reference'] and r['permuted_answer']==r['reference'] for r in rows);harms=sum(r['baseline_answer']==r['reference'] and r['permuted_answer']!=r['reference'] for r in rows)
 discordant=rescues+harms
 out['paired_correctness']={'rescues':rescues,'harms':harms,'exact_two_sided_mcnemar_p':min(1,2*sum(math.comb(discordant,k) for k in range(min(rescues,harms)+1))/(2**discordant)),'interpretation':'Nominal descriptive reference for one realised pair of assignments, not proof that derangements systematically improve accuracy.'}
 result['letter_positions'].append(out)
positions=json.loads((P/'existing_results.json').read_text())['evaluations']
result['primary_4b_positions']=next(r for r in positions if r['cohort']=='primary' and r['model']=='4b')['positions']
(E/'diagnostics.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'letter_positions':result['letter_positions'],'runner_up_primary':result['runner_up'][:6]},indent=2))
