from pathlib import Path
import hashlib,json,datetime
import numpy as np
E=Path(__file__).resolve().parent;R=E.parent
CONDITIONS=['E','ROI_HIGH','ROI_RANDOM_1','ROI_RANDOM_7','ROI_RANDOM_42']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:[json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
seedbase=2026102402

def stat(x,seed,divisor=1):
 x=np.asarray(x,dtype=int);v,c=np.unique(x,return_counts=True)
 draws=np.random.default_rng(seed).multinomial(len(x),c/c.sum(),size=20000)@v/len(x)/divisor
 return {'estimate':float(x.mean()/divisor),'ci95':[float(v) for v in np.quantile(draws,[.025,.975])],'seed':seed,'divisor':divisor}

def outcomes(answers,ref,seed):
 correct=(answers==ref[:,None]).astype(int);B=correct[:,0];G=correct[:,1];U=correct[:,2:]
 d3=3*np.maximum(B,G)-np.maximum(B[:,None],U).sum(1)
 data={'n':len(B),'matched_oracle':stat(d3,seed,3),'conditions':{}}
 for j,c in enumerate(CONDITIONS):
  C=correct[:,j];r=(1-B)*C;h=B*(1-C)
  data['conditions'][c]={'direct':stat(C,seed+10+j*5),'oracle':stat(np.maximum(B,C),seed+11+j*5),'headroom':stat(r,seed+12+j*5),'direct_minus_baseline':stat(C-B,seed+13+j*5),'rescues':int(r.sum()),'harms':int(h.sum()),'changes':int((answers[:,j]!=answers[:,0]).sum())}
 data['control_mean_direct']=stat(U.sum(1),seed+50,3)
 data['control_mean_oracle']=stat(np.maximum(B[:,None],U).sum(1),seed+51,3)
 data['control_mean_headroom']=stat(((1-B[:,None])*U).sum(1),seed+52,3)
 data['guided_minus_control_direct']=stat(3*G-U.sum(1),seed+53,3)
 return data,correct,d3

assert json.loads((E/'pilot_gate.json').read_text())['pass']
allrows=[]
for split in ['pilot','main']:
 seal=json.loads((E/(split+'_seal.json')).read_text());assert seal['status']=='SEALED_BEFORE_NEW_REFERENCE_SCORING'
 refs={x['sample_id']:x['reference'] for x in read(R/'controlled_replication'/split/'references.jsonl')}
 assert len(seal['files'])==(128 if split=='pilot' else 2048)
 for f in seal['files']:
  p=E/f['path'];assert sha(p)==f['sha256'];r=json.loads(p.read_text(encoding='utf-8'))
  probs=[];display=[];tokens=[]
  for shift in range(4):
   entry=r['scores'][str(shift)];perm=entry['position_to_original_identity'];assert perm==[(j+shift)%4 for j in range(4)]
   per=[];letters=[];tokenrow=[]
   for c in CONDITIONS:
    s=entry['conditions'][c];q=s['option_probs'];assert len(q)==4 and abs(sum(q)-1)<1e-5
    mapped=[q[perm.index(j)] for j in range(4)];assert mapped==s['option_probs_original_identity']
    assert s['answer_original_identity']=='ABCD'[perm['ABCD'.index(s['answer'])]]
    per.append(mapped);letters.append('ABCD'.index(s['answer']));tokenrow.append(s['image_tokens'])
   probs.append(per);display.append(letters);tokens.append(tokenrow)
  assert all(tokens[0]==t for t in tokens)
  allrows.append({'sample_id':r['sample_id'],'split':split,'reference':'ABCD'.index(refs[r['sample_id']]),'probabilities_by_shift_condition_identity':probs,'display_answers_by_shift_condition':display,'image_tokens_by_condition':tokens[0],'source_prediction_sha256':r['source_prediction_sha256'],'new_prediction_sha256':sha(p),'new_forward_calls':r['new_forward_calls']})
(E/'order_records.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in allrows),encoding='utf-8')
rows=[r for r in allrows if r['split']=='main'];P=np.asarray([r['probabilities_by_shift_condition_identity'] for r in rows]);y=np.asarray([r['reference'] for r in rows]);assert P.shape==(2048,4,5,4)
single=P[:,0].argmax(-1);avg=P.mean(1).argmax(-1)
out={'status':'COMPLETE','role':'Post hoc exploratory four-cyclic-order probability averaging','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'protocol_sha256':sha(E/'protocol.json'),'conditions':CONDITIONS,'pilot_n':128,'main_n':2048,'logical_main_new_scores':2048*5*3,'actual_main_forward_calls':sum(r['new_forward_calls'] for r in rows),'actual_pilot_forward_calls':sum(r['new_forward_calls'] for r in allrows if r['split']=='pilot'),'orders':{}}
out['original'],C0,D0=outcomes(single,y,seedbase)
out['averaged'],CA,DA=outcomes(avg,y,seedbase+100)
out['paired_change_in_matched_oracle']=stat(DA-D0,seedbase+200,3)
out['averaged_minus_original_direct']={c:stat(CA[:,j]-C0[:,j],seedbase+210+j) for j,c in enumerate(CONDITIONS)}
out['averaged_minus_original_guided_headroom']=stat((1-CA[:,0])*CA[:,1]-(1-C0[:,0])*C0[:,1],seedbase+220)
out['answer_changes_averaged_vs_original']={c:int((avg[:,j]!=single[:,j]).sum()) for j,c in enumerate(CONDITIONS)}
for shift in range(4):
 answers=(np.asarray([r['display_answers_by_shift_condition'][shift] for r in rows])+shift)%4
 out['orders'][str(shift)],_,_=outcomes(answers,y,seedbase+300+shift*100)
 out['orders'][str(shift)]['baseline_predicted_letter_counts']=np.bincount(np.asarray([r['display_answers_by_shift_condition'][shift][0] for r in rows]),minlength=4).tolist()
 out['orders'][str(shift)]['reference_letter_counts']=np.bincount((y-shift)%4,minlength=4).tolist()
out['pooled_reference_letter_counts']=np.sum([v['reference_letter_counts'] for v in out['orders'].values()],axis=0).tolist();assert out['pooled_reference_letter_counts']==[2048]*4
out['exact_average_probability_tie_counts']={c:int(sum(np.sum(q==q.max())>1 for q in P.mean(1)[:,j])) for j,c in enumerate(CONDITIONS)}
assert abs(out['original']['matched_oracle']['estimate']-(-.00146484375))<1e-12
(E/'order_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({k:out[k] for k in ['status','main_n','actual_main_forward_calls','actual_pilot_forward_calls','paired_change_in_matched_oracle','averaged_minus_original_direct']},indent=2))
print(json.dumps({'original':out['original'],'averaged':out['averaged']},indent=2))
