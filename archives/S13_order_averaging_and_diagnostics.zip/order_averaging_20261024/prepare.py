from pathlib import Path
import datetime,json,hashlib,shutil
E=Path(__file__).resolve().parent;R=E.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (E/'protocol.json').exists()
shutil.copy2(R/'review_controls_20261024/inference_common.py',E/'inference_common.py')
protocol={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'POST_HOC_EXTENSION_FIXED_BEFORE_OWN_INFERENCE',
 'scope':'Original primary 2B: 128 excluded technical pilot questions followed by all 2048 main questions. No efficacy-based expansion or stopping.',
 'conditions':['E','ROI_HIGH','ROI_RANDOM_1','ROI_RANDOM_7','ROI_RANDOM_42'],
 'orders':'Four cyclic shifts relative to the archived original option order. Shift k puts original option (j+k) mod 4 at display position j. Each identity occupies each letter once; this is not enumeration of all 24 permutations.',
 'aggregation':'Map each four-label probability vector to original option identity, arithmetic mean of four vectors within each condition, then argmax with original-identity index tie-break. For primary analysis shift 0 uses archived original probabilities. Technical pilot recomputes shift 0 for all five conditions. Same within-question orders apply across all five conditions.',
 'technical_gate':'128 complete pilot records. Every condition shift-0 answer agreement >=99%, maximum four-label probability discrepancy <=0.02. Official-forward logprob difference <1e-4 on first two pilot questions, shifts 0/1, E/ROI_HIGH. Image-token count equals archived condition for every order. No reference label used to advance.',
 'inference':'Same frozen Qwen3-VL-2B, BF16, SDPA, 512-pixel global/crop rendering and prompts. Duplicate control windows reuse exact same scoring call within question and order. No new crop ranking, training, neutral-wording substitution or calibration.',
 'statistics':{'draws':20000,'seed':2026102402,'unit':'paired question, one per linked group','intervals':'nominal exploratory 95% percentile bootstrap, no equivalence or confirmatory claims',
 'main_estimand':'Mean max(Bbar,Gbar) minus mean of max(Bbar,Ubar_s) over three original fixed seeds, where bars indicate argmax after four-order probability averaging, not an oracle across orders.',
 'additional_endpoints':['all-five direct accuracies, guided/control headroom, rescue/harm','paired change in matched oracle contrast versus archived single-order result','each individual cyclic-order matched contrast and direct accuracy','order-averaged versus single-order direct change, headroom change','original versus prior derangement correct-letter/predicted-letter marginals and paired correctness','fraction of changed intervention answers equal to original baseline runner-up, descriptive by correctness stratum and cohort/model'],
 'scope_limits':'Four cyclic orders balance marginal letter positions but preserve cyclic adjacency class. Not all 24 orders, not other model/cohorts. Derangement diagnostics cannot identify a chance versus systematic causal mechanism from a single realised assignment.'},
 'bindings':{str(R/'controlled_replication'/split/name):sha(R/'controlled_replication'/split/name) for split in ['pilot','main'] for name in ['inputs.jsonl','prediction_seal.json']},
 'code_bindings':{name:sha(E/name) for name in ['run.py','inference_common.py']}}
(E/'protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
print(json.dumps({'status':protocol['status'],'protocol_sha256':sha(E/'protocol.json')}))
