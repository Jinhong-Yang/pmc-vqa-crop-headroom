"""Independent scalar recomputation of the S13 release (Python + NumPy only)."""
from pathlib import Path, PureWindowsPath
from collections import Counter
import json,math,hashlib
import numpy as np
E=Path(__file__).resolve().parent
read=lambda p:[json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
checks=0
def equal(a,b):
 global checks
 assert np.allclose(a,b,rtol=0,atol=1e-11),(a,b)
 checks+=1
def stat(values,reported):
 d=reported.get('divisor',1);n=len(values);counts=Counter(values);keys=sorted(counts)
 equal(sum(values)/n/d,reported['estimate'])
 draws=np.random.default_rng(reported['seed']).multinomial(n,[counts[k]/n for k in keys],20000)
 bootstrap=np.sum(draws*np.asarray(keys)[None,:],axis=1)/n/d
 equal(np.quantile(bootstrap,[.025,.975]),reported['ci95'])

records=read(E/'order_records.jsonl');results=json.loads((E/'order_results.json').read_text())
assert len(records)==2176 and len({(r['split'],r['sample_id']) for r in records})==2176
main=[r for r in records if r['split']=='main'];n=len(main);assert n==2048
conditions=results['conditions'];ref=[r['reference'] for r in main]
averaged=[];original=[];orders=[[] for _ in range(4)]
for r in main:
 ps=r['probabilities_by_shift_condition_identity'];averages=[];first=[]
 for j in range(5):
  q=[sum(ps[k][j][a] for k in range(4))/4 for a in range(4)]
  averages.append(max(range(4),key=lambda a:q[a]));first.append(r['display_answers_by_shift_condition'][0][j])
  assert all(abs(sum(ps[k][j])-1)<1e-5 for k in range(4))
 averaged.append(averages);original.append(first)
 for k in range(4):orders[k].append([(a+k)%4 for a in r['display_answers_by_shift_condition'][k]])
def check_outcomes(predictions,t):
 correct=[[int(a==y) for a in ans] for y,ans in zip(ref,predictions)]
 ds=[3*max(row[0],row[1])-sum(max(row[0],a) for a in row[2:]) for row in correct]
 stat(ds,t['matched_oracle'])
 for j,c in enumerate(conditions):
  co=[r[j] for r in correct];base=[r[0] for r in correct]
  rescues=[int(not b)*a for a,b in zip(co,base)];harms=[b*(1-a) for a,b in zip(co,base)]
  equal(sum(rescues),t['conditions'][c]['rescues']);equal(sum(harms),t['conditions'][c]['harms']);equal(sum(row[j]!=row[0] for row in predictions),t['conditions'][c]['changes'])
  for key,values in [('direct',co),('oracle',[max(a,b) for a,b in zip(co,base)]),('headroom',rescues),('direct_minus_baseline',[a-b for a,b in zip(co,base)])]:stat(values,t['conditions'][c][key])
 stat([sum(r[2:]) for r in correct],t['control_mean_direct'])
 stat([sum(max(r[0],a) for a in r[2:]) for r in correct],t['control_mean_oracle'])
 stat([(1-r[0])*sum(r[2:]) for r in correct],t['control_mean_headroom'])
 stat([3*r[1]-sum(r[2:]) for r in correct],t['guided_minus_control_direct'])
 return correct,ds
C0,D0=check_outcomes(original,results['original']);CA,DA=check_outcomes(averaged,results['averaged'])
stat([a-b for a,b in zip(DA,D0)],results['paired_change_in_matched_oracle'])
for j,c in enumerate(conditions):
 stat([a[j]-b[j] for a,b in zip(CA,C0)],results['averaged_minus_original_direct'][c])
 equal(sum(a[j]!=b[j] for a,b in zip(averaged,original)),results['answer_changes_averaged_vs_original'][c])
stat([(1-a[0])*a[1]-(1-b[0])*b[1] for a,b in zip(CA,C0)],results['averaged_minus_original_guided_headroom'])
pooled=[0]*4
for k in range(4):
 check_outcomes(orders[k],results['orders'][str(k)])
 actual=[sum((r['reference']-k)%4==a for r in main) for a in range(4)]
 equal(actual,results['orders'][str(k)]['reference_letter_counts'])
 equal([sum(r['display_answers_by_shift_condition'][k][0]==a for r in main) for a in range(4)],results['orders'][str(k)]['baseline_predicted_letter_counts'])
 pooled=[a+b for a,b in zip(pooled,actual)]
equal(pooled,[2048]*4)

# Independently reconstruct every compact vector from the raw sealed record.
for split in ['pilot','main']:
 seal=json.loads((E/(split+'_seal.json')).read_text());mapping={r['sample_id']:r for r in records if r['split']==split}
 for f in seal['files']:
  p=E.joinpath(*PureWindowsPath(f['path']).parts);assert p.resolve().is_relative_to(E.resolve());assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'];raw=json.loads(p.read_text(encoding='utf-8'));r=mapping[raw['sample_id']]
  assert r['new_prediction_sha256']==f['sha256']
  for k in range(4):
   perm=raw['scores'][str(k)]['position_to_original_identity']
   assert perm==[(a+k)%4 for a in range(4)]
   for j,c in enumerate(conditions):
    s=raw['scores'][str(k)]['conditions'][c];mapped=[0.0]*4
    for display,a in enumerate(perm):mapped[a]=s['option_probs'][display]
    assert mapped==r['probabilities_by_shift_condition_identity'][k][j]
    assert s['answer_original_identity']=='ABCD'[perm['ABCD'.index(s['answer'])]]

diag=json.loads((E/'diagnostics.json').read_text());old=read(E/'existing_records.jsonl');previous=read(E/'previous_order_records.jsonl')
for t in diag['runner_up']:
 rs=[r for r in old if (r['cohort'],r['model'])==(t['cohort'],t['model'])]
 for name,s in t['strata'].items():
  tally=Counter()
  for r in rs:
   b='ABCD'.index(r['baseline_answer']);y='ABCD'.index(r['reference']);p=r['baseline_probs'];others=[j for j in range(4) if j!=b];highest=max(p[j] for j in others);ties=[j for j in others if p[j]==highest];runner=min(ties)
   answers=r['control_answers'] if t['condition']=='control' else [r[t['condition']+'_answer']]
   for a in answers:
    a='ABCD'.index(a)
    if a==b:continue
    include=name=='all_changed' or (name=='changed_baseline_errors' and b!=y) or (name=='rescues' and b!=y and a==y) or (name=='harms' and b==y)
    if include:
     tally['n']+=1;tally['equals_runner_up']+=a==runner;tally['equals_tied_runner_up']+=a in ties;tally['runner_up_tied']+=len(ties)>1
  for key in ['n','equals_runner_up','equals_tied_runner_up','runner_up_tied']:equal(tally[key],s[key])
  equal(tally['equals_runner_up']/tally['n'],s['share']);equal(tally['equals_tied_runner_up']/tally['n'],s['tie_inclusive_share'])
for item in diag['letter_positions']:
 rs=[r for r in previous if r['split']==item['split']]
 for label,t in item['orders'].items():
  ys=['ABCD'.index(r['reference']) if label=='original' else r['permutation'].index('ABCD'.index(r['reference'])) for r in rs]
  ans=['ABCD'.index(r['baseline_answer'] if label=='original' else r['permuted_display_answer']) for r in rs]
  equal([ys.count(j) for j in range(4)],t['correct_position_counts']);equal([ans.count(j) for j in range(4)],t['predicted_position_counts']);equal(sum(a==b for a,b in zip(ys,ans)),t['correct'])
 for transition in item['transitions']:
  subset=[r for r in rs if r['reference']==transition['original_letter'] and 'ABCD'[r['permutation'].index('ABCD'.index(r['reference']))]==transition['deranged_letter']]
  equal(len(subset),transition['n']);equal(sum(r['baseline_answer']==r['reference'] for r in subset),transition['original_correct']);equal(sum(r['permuted_answer']==r['reference'] for r in subset),transition['deranged_correct'])
 p=item['paired_correctness'];b,c=p['rescues'],p['harms'];total=b+c
 # Binomial recurrence independently avoids factorial/combinations implementation.
 mass=2.0**(-total);tail=mass
 for k in range(min(b,c)):mass*= (total-k)/(k+1);tail+=mass
 equal(min(1,2*tail),p['exact_two_sided_mcnemar_p'])
receipt={'status':'PASS','numeric_checks':checks,'new_records_verified':len(records),'method':'Scalar arithmetic/tie handling independently from array analysis; raw-to-compact remapping, all bootstrap intervals, runner-up counts and letter-position diagnostics verified.'}
(E/'portable_reproduction_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt,indent=2))
