from inference_common import *

CONDITIONS=['E','ROI_HIGH','ROI_RANDOM_1','ROI_RANDOM_7','ROI_RANDOM_42']
PAIR='The first image is the global view. The second image is an additional view of the same figure; it may or may not contain useful detail.\n'

def main():
 protocol=json.loads((E/'protocol.json').read_text());ph=sha(E/'protocol.json')
 for name,h in protocol['code_bindings'].items():assert sha(E/name)==h,name
 for path,h in protocol['bindings'].items():assert sha(Path(path))==h,path
 lock=E/'gpu.lock'
 with lock.open('x') as f:json.dump({'pid':os.getpid(),'at':now()},f)
 started=time.perf_counter()
 try:
  scorer=Scorer('2b');dump(E/'runtime.json',scorer.meta)
  for split in ['pilot','main']:
   if split=='main':assert json.loads((E/'pilot_gate.json').read_text())['pass']
   xs=read(R/'controlled_replication'/split/'inputs.jsonl');files=[];checks=[]
   source_seal=json.loads((R/'controlled_replication'/split/'prediction_seal.json').read_text())
   source_hashes={Path(f['path']).name:f['sha256'] for f in source_seal['files']}
   new_calls=0
   for i,x in enumerate(xs):
    target=E/'predictions'/split/(x['sample_id']+'.json');src=R/'controlled_replication'/split/'predictions'/(x['sample_id']+'.json')
    assert sha(src)==source_hashes[src.name]
    old=json.loads(src.read_text(encoding='utf-8'))
    if target.exists():
     rec=json.loads(target.read_text(encoding='utf-8'));assert rec['protocol_sha256']==ph
    else:
     tick=time.perf_counter();base=image(x['image_path']);geom=old['observations']['roi']
     with Image.open(x['image_path']) as im:full=ImageOps.exif_transpose(im).convert('RGB')
     windows={'E':None,'ROI_HIGH':geom['chosen'],**{'ROI_RANDOM_'+s:j for s,j in geom['random_indices'].items()}}
     views={j:[base,full.crop(geom['boxes'][j]).resize(tuple(geom['rendered_size']),Image.Resampling.LANCZOS)] for j in set(windows.values()) if j is not None}
     views[None]=base;scores={};technical=[];calls=0
     for shift in range(4):
      perm=[(j+shift)%4 for j in range(4)]
      xp={**x,'options':[x['options'][j] for j in perm]};cache={};row={}
      for cond in CONDITIONS:
       j=windows[cond];text=prompt(xp) if cond=='E' else PAIR+prompt(xp)
       if shift==0 and split=='main':s=dict(old['scores'][cond]);origin='reused_original'
       else:
        if j not in cache:cache[j]=scorer.score(views[j],text);calls+=1
        s=dict(cache[j]);origin='new_inference'
       assert s['image_tokens']==old['scores'][cond]['image_tokens']
       s['answer_original_identity']='ABCD'[perm['ABCD'.index(s['answer'])]]
       s['option_probs_original_identity']=[s['option_probs'][perm.index(k)] for k in range(4)]
       s['source']=origin;row[cond]=s
       if split=='pilot' and shift==0:
        technical.append({'condition':cond,'answer_match':s['answer']==old['scores'][cond]['answer'],'max_probability_error':max(abs(a-b) for a,b in zip(s['option_probs'],old['scores'][cond]['option_probs']))})
       if split=='pilot' and i<2 and shift in [0,1] and cond in ['E','ROI_HIGH']:
        official=scorer.score(views[j],text,official=True);calls+=1
        err=max(abs(a-b) for a,b in zip(official['option_log_probs'],s['option_log_probs']))
        assert err<1e-4
        technical.append({'condition':cond,'shift':shift,'official_logprob_error':err})
      scores[str(shift)]={'position_to_original_identity':perm,'conditions':row}
     rec={'sample_id':x['sample_id'],'split':split,'protocol_sha256':ph,'source_prediction_sha256':sha(src),'image_sha256':sha(Path(x['image_path'])),'scores':scores,'technical_checks':technical,'new_forward_calls':calls,'wall_s':time.perf_counter()-tick,'at':now()}
     dump(target,rec)
    files.append({'path':str(target.relative_to(E)),'sha256':sha(target)});checks.extend(rec['technical_checks']);new_calls+=rec['new_forward_calls']
    if (i+1)%32==0 or i==len(xs)-1:
     progress={'split':split,'done':i+1,'total':len(xs),'new_forward_calls':new_calls,'wall_s':time.perf_counter()-started,'at':now()};dump(E/'progress.json',progress);print(json.dumps(progress),flush=True)
   dump(E/(split+'_seal.json'),{'status':'SEALED_BEFORE_NEW_REFERENCE_SCORING','protocol_sha256':ph,'files':files,'at':now()})
   if split=='pilot':
    repeats=[c for c in checks if 'answer_match' in c]
    per={cond:{'n':len(v:=[c for c in repeats if c['condition']==cond]),'agreement':sum(c['answer_match'] for c in v)/len(v),'max_probability_error':max(c['max_probability_error'] for c in v)} for cond in CONDITIONS}
    gate={'pass':all(v['n']==128 and v['agreement']>=.99 and v['max_probability_error']<=.02 for v in per.values()),'conditions':per,'official_checks':[c for c in checks if 'official_logprob_error' in c],'at':now()}
    dump(E/'pilot_gate.json',gate);assert gate['pass'],gate
  print('COMPLETE',flush=True)
 finally:lock.unlink(missing_ok=True)

if __name__=='__main__':main()
