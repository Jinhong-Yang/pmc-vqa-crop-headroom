NUMERICAL SUPPORTING INFORMATION — submission draft, 18 October 2026

Extract S2, S3, S4 and S5 into the same fresh directory, preserving paths.
These archives contain study-generated numerical records and code, not image
collections or model weights. Earlier reporting files document provenance;
the current manuscript and S1 File govern interpretation.

CPU NUMERICAL REPRODUCTION (Python 3.11+, NumPy and SciPy)
1. python reproducibility_bundle/portable_reanalysis.py reproducibility_bundle
2. Install requirements_additional.txt, then:
   python rerun_additional_analysis.py
   python verify_additional_analysis.py
3. python reproduce_added_analyses.py
The third step creates rerun_controls and recomputes the new input controls,
annotation assay, spatial diagnostics and independent numerical checks.
Use a fresh extraction directory for each rerun. These steps need no network,
GPU, upstream question text or model weights.

UPSTREAM TEXT AND RIGHTS
The original PMC-VQA card records CC BY-SA, without a version number.
Upstream question and choice text is replaced by typed SHA256 references in
27 JSON/JSONL files. Source IDs, permutations, reference letters, model outputs,
probabilities and numerical results remain available. This release does not
purport to relicense upstream text, images or model weights.
The original local manifest and source_text_separation.json retain original
and journal-version hashes. The active bundle manifest describes this release.
Reconstruction against pinned source CSVs restored all 27 files to equivalent
JSON values in a separate check. Consult reconstruct_source_text.py --help.
Obtain PMC-VQA source data at revision
b56ae594f794867893143b337b4118a835794647 from RadGenome/PMC-VQA on Hugging Face.
Respect original source terms. Do not upload reconstructed upstream text as
journal CC BY supporting information without resolving the applicable rights.

INFERENCE REPRODUCTION
Original acquisition/inference scripts, exact prompts, source hashes and model
revisions are archived. Inference scripts retain the executed machine's paths
as provenance; adapt those paths in a separate run, acquire the pinned source
images and model weights, and write a new protocol rather than overwriting
the frozen records. Reference scoring follows prediction sealing.
S5 includes SLAKE source acquisition receipts, annotation-derived input records
and every new prediction. Obtain its images/annotations from BoKelvin/SLAKE at
a9083ce6c34ac3ffb17671a605962924d8a8f9e9. Its pinned card states CC BY 4.0.
The constructed assay is not an evaluation on the original SLAKE VQA test set.
Resource interruptions and pilot-only placement changes are preserved.

S5 contains 35,310 additional experimental predictions (32,034 main and 3,276
pilot); technical probes are separately named and excluded from those totals.
There are 89,030 earlier predictions: 63,206 original main, 4,224 original
pilot and 21,600 historical discovery. Shared questions across conditions or
models are not independent cases.
