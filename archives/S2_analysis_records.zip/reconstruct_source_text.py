"""Restore upstream text into a SEPARATE copy using the original licensed PMC-VQA CSVs.
python reconstruct_source_text.py RELEASE_DIRECTORY OUTPUT_DIRECTORY train.csv test.csv test_clean.csv
Obtain CSVs from RadGenome/PMC-VQA at b56ae594f794867893143b337b4118a835794647.
No network, model, or label-based selection; original third-party terms apply.
"""
from pathlib import Path
import sys,json,csv,hashlib,re,random,shutil
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
def stable(x):return hashlib.sha256(('20261016|'+x).encode()).hexdigest()
def norm(x):return ' '.join(re.sub(r'[^\w\s]',' ',x.lower()).split())
def main():
 if len(sys.argv)<6 or '--help' in sys.argv:
  print(__doc__)
  if '--help' in sys.argv:return
  raise SystemExit('Supply release directory, new output directory, and all three pinned CSV files.')
 source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();assert out!=source and not out.exists(),'Output must be a new separate directory'
 needed=set();files={}
 def collect(x):
  if isinstance(x,dict):
   if 'upstream_value_sha256' in x:needed.add(x['upstream_value_sha256'])
   else:
    for v in x.values():collect(v)
  elif isinstance(x,list):
   for v in x:collect(v)
 for p in source.rglob('*'):
  if p.suffix not in ['.json','.jsonl']:continue
  try:x=[json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s] if p.suffix=='.jsonl' else json.loads(p.read_text(encoding='utf-8-sig'))
  except (ValueError,UnicodeError):continue
  before=len(needed);collect(x);files[p]=x
 lookup={}
 for file in sys.argv[3:]:
  for r in csv.DictReader(Path(file).open(encoding='utf-8-sig',newline='')):
   try:
    q=r['Question'].strip();opts=[re.sub(r'^\s*[A-D]\s*[:.)]\s*','',r['Choice '+a]).strip() for a in 'ABCD'];sid='pmc-'+stable(r['Figure_path']+'|'+q)[:24];order=list(range(4));random.Random(int(stable(sid),16)).shuffle(order)
    candidates=[q,opts,[opts[i] for i in order],r['Answer'].strip(),norm(q)]
   except KeyError:continue
   for v in candidates:
    h=digest(v)
    if h in needed:lookup[h]=v
 assert needed<=lookup.keys(),f'Missing {len(needed-lookup.keys())} values {sorted(needed-lookup.keys())}; provide all pinned CSVs'
 shutil.copytree(source,out)
 def restore(x):
  if isinstance(x,dict):
   if 'upstream_value_sha256' in x:return lookup[x['upstream_value_sha256']]
   return {k:restore(v) for k,v in x.items()}
  if isinstance(x,list):return [restore(v) for v in x]
  return x
 changed=0
 for p,x in files.items():
  y=restore(x)
  if x==y:continue
  dest=out/p.relative_to(source);text=''.join(json.dumps(v,ensure_ascii=False)+'\n' for v in y) if p.suffix=='.jsonl' else json.dumps(y,indent=2,ensure_ascii=False);dest.write_text(text,encoding='utf-8');changed+=1
 # Numerical-release manifests apply to the source copy; restored inputs have separate hashes.
 receipt={'status':'RESTORED_FROM_UPSTREAM','values':len(lookup),'files':changed,'source':str(source),'csv_sha256':{str(p):hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sys.argv[3:]}}
 (out/'RESTORATION_RECEIPT.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt))
if __name__=='__main__':main()
