REPRODUCIBILITY PACKAGE - COMPLETE LOCAL EXPERIMENTAL RELEASE

Scope: retrospective discovery plus prospective fixed-recipe medical figure QA.
The bundle includes all eight new pilot/main model runs, including null, negative and
inconclusive results. Pilots and main runs are separate. Two model sizes share
questions; their records do not double the independent question count.
Historical_discovery additionally retains the actual1350-question,16-condition
discovery outputs, their reference labels and scored table, separately from the
new experiments. The missing early4B report's raw data are not fabricated.

Recalculate the reported numerical findings using Python3 and NumPy:
    python portable_reanalysis.py PATH_TO_THIS_BUNDLE
This verifies every manifest hash and independently reconstructs oracle contrasts,
paired bootstrap intervals, and direct accuracy/rescue/harm/answer-flip counts.
It also verifies the historical discovery predictions and reproduces all six
retrospective equal-candidate comparisons using article-group resampling.
It needs no model weights, GPU, credentials, or network access.

Provenance: original sealed JSON predictions are in raw_predictions. Full original
seal manifests, sources of the scored reference labels, input metadata and checks
are in run_evidence. The byte-preserved original scripts in frozen_code contain
the historical machine paths. They are code snapshots, not a portable inference
installer. Detailed inference procedures and exact models are in the protocols.
The reproduction_assets folder additionally preserves the exact2000-example
retrieval bank, original normalized image embeddings, bank group/source metadata,
configuration snapshots and source/model acquisition receipts. Bank examples are
retrieval evidence and are not added to the query sample size. source_catalog.json
contains source URLs, pinned revisions, recorded file hashes and attribution;
source_cards retains the original dataset and model cards.

Images and model weights are not duplicated in this bundle. Obtain the pinned
PMC-VQA archive and model revisions named in the protocols; verify the per-image
SHA256 and orientation-corrected pixel SHA256 in metadata. Article URLs and
figure licences are retained. QA metadata derives from the source dataset's
CC BY-SA release; figure licences are distinct. Preserve original attribution.
Foundation-model pretraining overlap and independence from the missing early4B
raw cohort are unknown. Author-curated validation is within the same benchmark,
not a second hospital or independently clinician-adjudicated dataset.

This package has not been uploaded or publicly deposited. Author/institutional
statements and publication administration are outside this local numerical audit.
