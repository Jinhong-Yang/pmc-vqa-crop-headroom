"""Full sealed-run intervention, probability and provenance audit (no partials)."""
import json,hashlib,collections,sys,argparse
from pathlib import Path
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def audit(folder):
 P=R/folder;plan=load(P.parent/'protocol_frozen.json');seal=load(P/'prediction_seal.json');xs={r['sample_id']:r for r in read(P/'inputs.jsonl')}
 bank_groups={x['sample_id']:x['group_id'] for x in read(R/'reproduction_assets/original_project/data/g2/frozen/references/bank.jsonl')}
 assert seal['status']=='SEALED_BEFORE_REFERENCE_SCORING' and seal['qa']==len(xs)==plan['design'][P.name]
 assert sha(P.parent/'protocol_frozen.json')==seal['protocol_sha256'] and sha(P/'inputs.jsonl')==seal['input_file_sha256']
 before=load(P/'preservation_before.json');after=load(P/'preservation_after.json');assert before==after and after['status']=='PASS'
 obs=[];probabilities=0;families=collections.Counter();failure=collections.Counter()
 for f in seal['files']:
  p=P/f['path'];assert sha(p)==f['sha256'];r=load(p);x=xs[r['sample_id']]
  assert r['input_sha256']==hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest()
  m=r['observations'];z=m['roi'];scores=np.array(z['scores']);chosen=z['chosen'];random=list(z['random_indices'].values());assert chosen==int(scores.argmax())
  assert len(scores)==len(z['boxes'])==9 and np.isfinite(scores).all() and all(j!=chosen and 0<=j<9 for j in random)
  w,h=z['full_size'];factor=512/max(w,h);expected_size=[max(1,round(w*factor)),max(1,round(h*factor))]
  assert z['rendered_size']==expected_size and z['native_selected_size']==[max(1,w//2),max(1,h//2)]
  selected_edge=max(z['native_selected_size'])
  assert set(r['scores'])==set(plan['conditions']) and set(r['prompt_hashes'])==set(plan['conditions'])
  tokens=[]
  for c,v in r['scores'].items():
   probabilities+=1;pp=np.array(v['option_probs']);lp=np.array(v['option_log_probs']);expected=np.exp(lp-lp.max());expected/=expected.sum()
   np.testing.assert_allclose(pp,expected,atol=1e-6,rtol=1e-5)
   assert v['answer']=='ABCD'[int(lp.argmax())] and abs(pp.sum()-1)<1e-5 and v['context_tokens']<=3072
   if c.startswith('ROI_') and v['status']=='ok':tokens.append(v['image_tokens'])
   failure[c]+=v['status']!='ok'
  assert len(set(tokens))==1
  for c in ['R_IQG','R_SHUFFLE_1','R_SHUFFLE_7','R_SHUFFLE_42']:
   a=m[c];assert a['kept']==len(a['neighbor_ids'])<=3 and a['tokens']<=512
   if c.startswith('R_SHUFFLE'):assert len({bank_groups[i] for i in a['neighbor_ids']})==len(a['neighbor_ids'])
  guided_ids=m['R_IQG']['neighbor_ids'];guided_repeated_group=len({bank_groups[i] for i in guided_ids})<len(guided_ids)
  families[m['family']['predicted']]+=1
  obs.append({'guided_retrieval_repeated_group':guided_repeated_group,'distinct_random_crops':len(set(random)),'retrieval_query_truncated':m['query_tokens']['retrieval_raw']>64,'crop_query_truncated':m['query_tokens']['roi_raw']>64,'retrieval_length_difference':m['R_IQG']['tokens']-np.mean([m[f'R_SHUFFLE_{s}']['tokens'] for s in [1,7,42]]),'retrieval_family_fallback':m['family']['random_pool_fallback'],'native_gt512':z['native_gt512'],'native_gt1024':z['native_gt1024'],'global_source_below512':max(w,h)<512,'selected_crop_below256':selected_edge<256,'selected_crop_equal256':selected_edge==256,'selected_crop_above256':selected_edge>256})
 out={'status':'PASS','cohort':folder,'questions':len(xs),'probability_vectors_verified':probabilities,'source_preservation_identical_before_after':True,'input_and_prediction_hashes_verified':True,'selected_crop_argmax_verified':True,'ROI_image_token_budgets_equal':True,'retrieval_common_ceiling_verified':True,'retrieval_actual_length_difference_mean':float(np.mean([x['retrieval_length_difference'] for x in obs])),'distinct_random_crop_counts':dict(collections.Counter(x['distinct_random_crops'] for x in obs)),'inferred_family_counts':dict(families),'counts':{k:sum(x[k] for x in obs) for k in ['retrieval_query_truncated','crop_query_truncated','retrieval_family_fallback','native_gt512','native_gt1024','guided_retrieval_repeated_group','global_source_below512','selected_crop_below256','selected_crop_equal256','selected_crop_above256']},'failures':dict(failure),'limitations':['Actual retrieved text lengths are not matched.','Guided retrieval can repeat bank groups within a context; control retrieval enforces distinct groups.','Non-selected crops can repeat across seeds and can contain useful information.','This is integrity verification, not medical answer adjudication.']}
 (P/'intervention_integrity_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8');return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('folder');args=p.parse_args();print(json.dumps(audit(args.folder),indent=2))
