"""Independent source-text/reference and image checks; never reads predictions."""
import csv,json,hashlib,re,sys,io,datetime
from pathlib import Path
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'dependencies'))
from PIL import Image,ImageOps
SRC=Path('D:/Codex Research/MedVQA_SCIE_Local_20261016')
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):return ' '.join(re.sub(r'[^\w\s]',' ',s.lower()).split())

def main():
 pool={r['sample_id']:r for r in read(SRC/'data/g2/candidate_pool.jsonl')}
 targets={};cohorts={};sources={};counts={}
 for root,cohort in [('controlled_replication','pilot'),('controlled_replication','main'),('curated_replication_2b','pilot'),('curated_replication_2b','main')]:
  P=R/root/cohort;name=root+'/'+cohort;plan=load(P.parent/'protocol_frozen.json')
  selection=load(P.parent/'selection_audit.json')
  for fn,h in selection['files'].items():assert sha(P.parent/fn)==h
  for fn,h in plan['bindings'].items():assert sha(Path(fn))==h
  xs=read(P/'inputs.jsonl');ms={r['sample_id']:r for r in read(P/'metadata.jsonl')};rs={r['sample_id']:r for r in read(P/'references.jsonl')}
  assert len(xs)==len(ms)==len(rs)==plan['design'][cohort]
  cohorts[name]=ms;counts[name]=len(xs)
  for x in xs:
   sid=x['sample_id'];m=ms[sid];ref=rs[sid];assert set(x)=={'sample_id','question','options','image_path'}
   assert len(x['options'])==4 and len(set(map(norm,x['options'])))==4
   assert ref['reference'] in 'ABCD' and len(ref['reference'])==1
   assert norm(x['options']['ABCD'.index(ref['reference'])])==norm(ref['answer_text'])
   assert norm(x['question'])==m['question_key']
   b=Path(x['image_path']).read_bytes();assert hashlib.sha256(b).hexdigest()==m['image_sha256']
   im=ImageOps.exif_transpose(Image.open(io.BytesIO(b))).convert('RGB');w,h=im.size
   assert (w,h)==(m['image_width'],m['image_height'])
   assert hashlib.sha256(f'{w}x{h}|'.encode()+im.tobytes()).hexdigest()==m['pixel_sha256']
   figure=m.get('figure') or pool[sid]['figure']
   source='clean' if root.startswith('curated') else m['official_split']
   key=(source,figure,x['question'].strip());assert key not in targets
   targets[key]=(x,ref)
 for source,file in [('train',SRC/'data/raw/pmc/train.csv'),('test',SRC/'data/raw/pmc/test.csv'),('clean',R/'clean_validation/test_clean.csv')]:
  found=set()
  with file.open(encoding='utf-8-sig',newline='') as f:
   for row in csv.DictReader(f):
    key=(source,row['Figure_path'],row['Question'].strip())
    if key not in targets:continue
    x,ref=targets[key];opts=[re.sub(r'^\s*[A-D]\s*[:.)]\s*','',row['Choice '+a]).strip() for a in 'ABCD']
    assert set(opts)==set(x['options'])
    assert norm(row['Answer'])==norm(ref['answer_text'])
    assert norm(opts['ABCD'.index(row['Answer_label'].strip())])==norm(ref['answer_text'])
    found.add(key)
  expected={k for k in targets if k[0]==source};assert found==expected
  sources[source]={'path':str(file),'sha256':sha(file),'source_records_verified':len(found)}
 names=list(cohorts)
 for k in ['sample_id','original_group_id','question_key','image_sha256','pixel_sha256']:
  sets=[{r[k] for r in cohorts[n].values()} for n in names]
  for i in range(len(sets)):
   assert len(sets[i])==counts[names[i]],(names[i],k,'within-cohort duplicate')
   for j in range(i):assert not sets[i]&sets[j],(names[i],names[j],k)
 for a,b in [('controlled_replication','controlled_replication_4b'),('curated_replication_2b','curated_replication_4b')]:
  for c in ['pilot','main']:
   for n in ['inputs.jsonl','metadata.jsonl','references.jsonl']:assert sha(R/a/c/n)==sha(R/b/c/n)
 out={'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'unique_questions':sum(counts.values()),'cohorts':counts,'sources':sources,'checks':['source options and reference text survive option permutation','byte and orientation-corrected pixel hashes','within/between cohort article, question and image uniqueness','2B/4B identical input, metadata and reference bytes','all frozen collector bindings verified'],'predictions_or_model_outcomes_read':False,'limitation':'Confirms source fidelity and technical separation; does not adjudicate medical correctness or rule out pretraining overlap.'}
 (R/'all_new_inputs_independent_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
