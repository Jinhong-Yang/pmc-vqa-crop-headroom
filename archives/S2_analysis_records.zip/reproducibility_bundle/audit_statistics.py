"""Independent algebra and categorical-bootstrap checks; no partial-main scoring."""
import json,sys,hashlib,argparse
from pathlib import Path
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
import pandas as pd
def contrast(e,g,c):return np.maximum(e,g)-np.maximum(e[:,None],c).mean(1)
def checks():
 e=np.array([1,0,0,0]);g=np.array([0,1,1,0]);c=np.array([[0,0,0],[0,0,0],[1,0,0],[1,1,1]])
 d=contrast(e,g,c)
 np.testing.assert_allclose(d,[0,1,2/3,-1])
 rescue=(1-e)*(g-c.mean(1));harm=e*((1-g)-(1-c).mean(1))
 np.testing.assert_allclose(d,rescue)
 np.testing.assert_allclose(g-c.mean(1),d-harm)
 assert len(d)==4
 return {'synthetic_algebra_tests':'PASS','synthetic_cases':4,'synthetic_results_not_research_data':True}
def categorical_ci(v,level,nrep=50000):
 levels,counts=np.unique(np.asarray(v),return_counts=True);rng=np.random.default_rng(918263)
 draws=rng.multinomial(len(v),counts/counts.sum(),size=nrep)@levels/len(v)
 return np.quantile(draws,[(1-level)/2,1-(1-level)/2]).tolist()
def audit(folder):
 p=R/folder;v=json.loads((p/'results.json').read_text(encoding='utf-8'));seal=json.loads((p/'prediction_seal.json').read_text())
 protocol=json.loads((p.parent/'protocol_frozen.json').read_text(encoding='utf-8'))
 assert p.name in ['pilot','main'] and seal['qa']==protocol['design'][p.name]
 assert v['checks']['sealed_records_verified']==seal['qa']
 d=pd.read_csv(p/'per_qa_scored.csv');assert d.group_id.nunique()==len(d)==seal['qa'];e=d.E.to_numpy();rows=[]
 for r in v['oracle_contrasts']:
  name=r['comparison']
  if name=='roi':g=d.ROI_HIGH.to_numpy();c=d[[f'ROI_RANDOM_{s}' for s in [1,7,42]]].to_numpy()
  elif name=='retrieval':g=d.R_IQG.to_numpy();c=d[[f'R_SHUFFLE_{s}' for s in [1,7,42]]].to_numpy()
  else:
   g=np.maximum(d.ROI_HIGH,d.R_IQG).to_numpy();c=np.array([np.maximum(d[f'ROI_RANDOM_{s}'],d[f'R_SHUFFLE_{s}']) for s in [1,7,42]]).T
  diff=contrast(e,g,c);rescue=(1-e)*(g-c.mean(1));harm=e*((1-g)-(1-c).mean(1))
  np.testing.assert_allclose(diff,rescue);np.testing.assert_allclose(g-c.mean(1),rescue-harm)
  assert abs(diff.mean()-r['difference'])<1e-12
  interval=categorical_ci(diff,r['ci_level']);tolerance=max(.002,1/len(d))
  assert np.max(np.abs(np.asarray(interval)-r['ci']))<=tolerance,(name,interval,r['ci'])
  rows.append({'comparison':name,'mean_reproduced':float(diff.mean()),'independent_categorical_bootstrap_ci':interval,'recorded_case_bootstrap_ci':r['ci'],'ci_level':r['ci_level'],'normal_standard_error':float(diff.std(ddof=1)/np.sqrt(len(d))),'max_CI_difference':float(np.max(np.abs(np.asarray(interval)-r['ci']))),'algebraic_rescue_harm_identity':'PASS','independent_draws':50000})
 out={'status':'PASS','unit':'one QA per connected group, never seeds','scope':folder,'checks':checks(),'contrasts':rows,'no_partial_main_scoring':True}
 (p/'statistics_independent_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
 return out
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('folder');args=ap.parse_args();print(json.dumps(audit(args.folder),indent=2))
