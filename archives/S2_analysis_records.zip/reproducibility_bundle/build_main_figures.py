"""Scientific figures from fully sealed, audited main outputs only."""
import json,sys,hashlib,datetime
from pathlib import Path
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
FOLDERS=[('controlled_replication','Primary / 2B'),('controlled_replication_4b','Primary / 4B'),('curated_replication_2b','Curated / 2B'),('curated_replication_4b','Curated / 4B')]
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 data=[];sources={}
 for f,label in FOLDERS:
  P=R/f/'main';plan=load(P.parent/'protocol_frozen.json');s=load(P/'prediction_seal.json');v=load(P/'results.json');a=load(P/'statistics_independent_audit.json');u=load(P/'supplementary_results.json')
  assert s['qa']==plan['design']['main']==v['checks']['sealed_records_verified'] and a['status']=='PASS'
  assert v['prediction_seal_sha256']==sha(P/'prediction_seal.json') and v['protocol_sha256']==sha(P.parent/'protocol_frozen.json')
  data.append((label,v,u));sources[f]={n:sha(P/n) for n in ['prediction_seal.json','results.json','supplementary_results.json','statistics_independent_audit.json']}
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','savefig.dpi':300})
 out=R/'figures';out.mkdir(exist_ok=True)
 fig,axs=plt.subplots(1,3,figsize=(12,4.4),sharey=True)
 all_bounds=[100*x for _,v,_ in data for r in v['oracle_contrasts'] for x in r['ci']];lim=max(3,np.ceil(max(abs(x) for x in all_bounds)+.5))
 for ax,comparison,title in zip(axs,['roi','retrieval','two_tools'],['A  Crop oracle (primary)','B  Retrieval oracle (secondary)','C  Combined oracle (secondary)']):
  ax.axvspan(-2,2,color='#ecf2f5',zorder=0);ax.axvline(0,color='#555555',lw=.8);ax.axvline(-2,color='#8f9aa3',ls='--',lw=.8);ax.axvline(2,color='#8f9aa3',ls='--',lw=.8)
  for i,(label,v,_) in enumerate(data):
   r=next(x for x in v['oracle_contrasts'] if x['comparison']==comparison);est=r['difference']*100;lo,hi=np.array(r['ci'])*100;color='#087e8b' if i%2==0 else '#c66525'
   ax.errorbar(est,i,xerr=[[est-lo],[hi-est]],fmt='o',color=color,capsize=4,ms=6,lw=1.8)
   ax.annotate(f'{est:+.2f} [{lo:+.2f}, {hi:+.2f}]',xy=(.02,i),xycoords=('axes fraction','data'),xytext=(0,13),textcoords='offset points',fontsize=8)
  ax.set_title(title,loc='left',fontsize=10,pad=12);ax.set_xlim(-lim,lim);ax.set_xlabel('Guided minus control oracle (pp)');ax.grid(axis='x',alpha=.15)
 axs[0].set_yticks(range(4),[f'{label}\n(n={v["oracle_contrasts"][0]["n"]:,})' for label,v,_ in data]);axs[0].set_ylim(3.5,-.65)
 fig.suptitle('Equal candidate counts: question-guided evidence versus fixed controls',fontsize=13,y=.98)
 fig.text(.02,.025,'Bars: paired group bootstrap intervals (crop 95%; secondary contrasts 97.5%). Shading: predeclared ±2 pp planning range.\nOne question per connected group. Model sizes share questions; cohorts are separate. These are oracle bounds, not deployable accuracy.',fontsize=8)
 fig.subplots_adjust(left=.15,right=.985,top=.82,bottom=.25,wspace=.13)
 for ext in ['png','svg','pdf']:fig.savefig(out/f'main_oracle_contrasts.{ext}')
 plt.close(fig)
 fig,axs=plt.subplots(1,2,figsize=(10.8,4.6),sharey=True)
 for ax,tool,title in zip(axs,['crop','retrieval'],['A  Crop intervention','B  Retrieval intervention']):
  ax.axvline(0,color='#666666',lw=.8)
  for j,(name,color,offset) in enumerate([('excess_rescue','#087e8b',-.18),('excess_harm','#c66525',0),('direct_vs_control','#5050a0',.18)]):
   for i,(_,_,u) in enumerate(data):
    r=next(x for x in u['secondary_contrasts'] if x['tool']==tool and x['contrast']==name);est=r['estimate']*100;lo,hi=np.array(r['ci95'])*100
    ax.errorbar(est,i+offset,xerr=[[est-lo],[hi-est]],fmt='o',color=color,capsize=3,ms=4,label=name.replace('_',' ').capitalize() if i==0 else None)
  ax.set_title(title,loc='left');ax.set_xlabel('Guided minus control difference (pp)');ax.grid(axis='x',alpha=.15)
 axs[0].set_yticks(range(4),[label for label,_,_ in data]);axs[0].set_ylim(3.5,-.5)
 handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.55,.93),ncol=3,frameon=False)
 fig.suptitle('Oracle rescue and net direct accuracy answer different questions',y=.995,fontsize=13)
 fig.text(.02,.025,'Net direct difference = excess rescue − excess harm. Positive excess harm means more baseline-correct answers were lost.\nIntervals are exploratory 95% paired group bootstrap intervals; no multiplicity adjustment in this descriptive family.',fontsize=8)
 fig.subplots_adjust(left=.16,right=.985,top=.77,bottom=.22,wspace=.2)
 for ext in ['png','svg','pdf']:fig.savefig(out/f'main_rescue_harm.{ext}')
 plt.close(fig)
 manifest={'status':'GENERATED_PENDING_VISUAL_INSPECTION','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources,'script_sha256':sha(Path(__file__)),'outputs':{p.name:sha(p) for p in out.glob('main_*')},'no_partial_main_results':True}
 (out/'main_figure_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 print(json.dumps(manifest,indent=2))
if __name__=='__main__':main()
