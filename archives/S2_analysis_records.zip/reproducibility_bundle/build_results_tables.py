"""Produce exact-value manuscript tables from all complete, audited main runs."""
import json,hashlib,shutil
from pathlib import Path
R=Path(__file__).resolve().parent;M=R/'manuscript'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def escape(s):return s.replace('_',r'\_').replace('%',r'\%')
def pct(x):return f'{100*x:.2f}'
def interval(r):return f"[{100*r['ci'][0]:+.2f}, {100*r['ci'][1]:+.2f}]"
def main():
 definitions=[('controlled_replication','Primary','2B'),('controlled_replication_4b','Primary','4B'),('curated_replication_2b','Curated','2B'),('curated_replication_4b','Curated','4B')]
 datasets=[];sources={}
 for folder,cohort,model in definitions:
  P=R/folder/'main';v=load(P/'results.json');seal=load(P/'prediction_seal.json');audit=load(P/'statistics_independent_audit.json');integrity=load(P/'intervention_integrity_audit.json')
  assert audit['status']==integrity['status']=='PASS' and v['prediction_seal_sha256']==sha(P/'prediction_seal.json')
  assert seal['qa']==load(P.parent/'protocol_frozen.json')['design']['main']
  datasets.append((cohort,model,v));sources[folder]=sha(P/'results.json')
 lines=[r'\subsubsection{Complete main-cohort estimates}',r'All model-specific main prediction sets were sealed before reference scoring. Pilots are excluded from the following tables. The primary 2B cohort is the main confirmatory comparison; the other model/cohort estimates assess model-scale and source-quality robustness. No cross-model pooling is performed.',r'\begin{table}[htbp]\centering\small',r'\caption{Crop oracle accuracy at matched candidate count and crop image-token budget. Accuracy columns are percentages; differences and confidence intervals are percentage points. Intervals are 95\% paired group-bootstrap intervals.}',r'\begin{tabular}{llrrrrr}\toprule',r'Cohort/model & $n$ & Baseline & Guided & Control & Difference & 95\% CI\\\midrule']
 for cohort,model,v in datasets:
  r=next(x for x in v['oracle_contrasts'] if x['comparison']=='roi')
  lines.append(f"{cohort}/{model} & {r['n']:,} & {pct(r['baseline_accuracy'])} & {pct(r['guided_oracle'])} & {pct(r['control_oracle_mean'])} & {100*r['difference']:+.2f} & {interval(r)} "+r'\\')
 lines += [r'\bottomrule\end{tabular}\end{table}',r'\begin{table}[htbp]\centering\small',r'\caption{Secondary oracle contrasts. Both sides contain two candidates for retrieval and three for combined tools. Each interval is 97.5\% to account for the two secondary oracle comparisons within a model/cohort.}',r'\begin{tabular}{llrrrr}\toprule',r'Cohort/model & Contrast & Guided (\%) & Control (\%) & Difference (pp) & CI (pp)\\\midrule']
 for cohort,model,v in datasets:
  for key,label in [('retrieval','Retrieval'),('two_tools','Combined')]:
   r=next(x for x in v['oracle_contrasts'] if x['comparison']==key)
   lines.append(f"{cohort}/{model} & {label} & {pct(r['guided_oracle'])} & {pct(r['control_oracle_mean'])} & {100*r['difference']:+.2f} & {interval(r)} "+r'\\')
 lines += [r'\bottomrule\end{tabular}\end{table}']
 (M/'results_generated.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 extra=[r'\section*{Supplementary direct-outcome tables}',r'Counts are per question. Rescue means baseline incorrect and intervention correct; harm means baseline correct and intervention incorrect. Flip counts include wrong-to-wrong answer changes. All eleven conditions are retained.']
 for cohort,model,v in datasets:
  extra += [r'\subsection*{'+cohort+' cohort, '+model+' model}',r'\begin{longtable}{lrrrrr}\toprule',r'Condition & Accuracy (\%) & Rescue & Harm & Answer flips & Failures\\\midrule\endhead']
  for r in v['direct_metrics']:extra.append(f"{escape(r['condition'])} & {pct(r['accuracy'])} & {r['rescue_count']} & {r['harm_count']} & {r['answer_flip_count']} & {r['failure_count']} "+r'\\')
  extra += [r'\bottomrule\end{longtable}']
 extra += [r'\section*{Supplementary pilot gates}',r'Pilot effects were not used as efficacy gates and pilot questions are excluded from main estimates. The projected half-width uses the model-specific pilot standard deviation and the planned main sample size. These are planning projections, not realised main confidence intervals.',r'\begin{longtable}{lrrrr}\toprule',r'Cohort/model & Pilot $n$ & Predictions & Failures & Projected half-width (pp)\\\midrule\endhead']
 for folder,cohort,model in definitions:
  p=R/folder/'pilot';g=load(p/'gate_decision.json');v=load(p/'results.json');s=load(p/'prediction_seal.json')
  assert g['main_authorized_by_protocol'] and all(g['criteria'].values())
  sources[folder+'_pilot_gate']=sha(p/'gate_decision.json')
  extra.append(f"{cohort}/{model} & {s['qa']} & {s['predictions']:,} & {sum(v['checks']['failed_conditions'].values())} & {100*g['projected_main_primary_half_width']:.3f} "+r'\\')
 extra += [r'\bottomrule\end{longtable}',r'\section*{Supplementary collection resources}',r'Wall time is full model-specific collection time, including shared construction of all tested interventions. It is not deployed single-tool latency. Peak reserved GPU memory and minimum free GPU memory are process observations during collection.',r'\begin{longtable}{lrrr}\toprule',r'Cohort/model & Wall time (min) & Peak reserved (GiB) & Minimum free (GiB)\\\midrule\endhead']
 for folder,cohort,model in definitions:
  v=load(R/folder/'main/inference_complete.json')
  extra.append(f"{cohort}/{model} & {v['wall_s']/60:.2f} & {v['peak_reserved_gib']:.2f} & {v['min_free_vram_gib']:.2f} "+r'\\')
 extra += [r'\bottomrule\end{longtable}',r'\section*{Supplementary crop sensitivity}',r'The frozen protocol included duplicate-global and reduced-resolution crop sensitivity conditions. Exact contrast reporting was implemented after the primary 2B results were known. These are exploratory paired differences (selected crop minus control), with unadjusted 95\% intervals. Duplicate means an extra global image; low resolution means the selected crop resampled to a 256-pixel longest edge and then enlarged to the common display size (the first step enlarges native crops below 256 pixels). Neither condition is an information-free placebo.',r'\begin{longtable}{lllrr}\toprule',r'Cohort/model & Control & Outcome & Difference (pp) & 95\% CI (pp)\\\midrule\endhead']
 for folder,cohort,model in definitions:
  u=load(R/folder/'main/supplementary_results.json');sources[folder+'_supplementary']=sha(R/folder/'main/supplementary_results.json')
  for r in u['sensitivity_contrasts']:
   control='Duplicate' if r['control']=='ROI_DUPLICATE' else 'Low resolution';metric='Direct' if r['metric']=='direct_accuracy' else 'Oracle'
   extra.append(f"{cohort}/{model} & {control} & {metric} & {100*r['estimate']:+.2f} & [{100*r['ci95'][0]:+.2f}, {100*r['ci95'][1]:+.2f}] "+r'\\')
 extra += [r'\bottomrule\end{longtable}',r'\section*{Supplementary answer diversity}',r'Mean number of distinct answer labels in each candidate set. Controls average separate seed-specific sets; they do not pool candidates across seeds. Diversity is descriptive and does not establish visual grounding.',r'\begin{longtable}{lrrrrrr}\toprule',r'Cohort/model & Crop G & Crop C & Retrieval G & Retrieval C & Combined G & Combined C\\\midrule\endhead']
 for folder,cohort,model in definitions:
  u=load(R/folder/'main/supplementary_results.json');values={r['candidate_set']:r['mean_unique_answer_labels'] for r in u['candidate_diversity']}
  extra.append(f'{cohort}/{model} & '+' & '.join(f'{values[k]:.3f}' for k in ['crop_guided','crop_controls','retrieval_guided','retrieval_controls','combined_guided','combined_controls'])+r'\\')
 extra += [r'\bottomrule\end{longtable}',r'G: guided evidence; C: mean of controls. Crop and retrieval sets contain two candidates; combined sets contain three.']
 (M/'supplementary_tables_generated.tex').write_text('\n'.join(extra)+'\n',encoding='utf-8')
 (M/'table_provenance.json').write_text(json.dumps({'status':'GENERATED_PENDING_LAYOUT_AND_SCIENTIFIC_REVIEW','source_result_sha256':sources,'files':{n:sha(M/n) for n in ['results_generated.tex','supplementary_tables_generated.tex']},'main_outputs_only':True},indent=2),encoding='utf-8')
 print('Generated all4main tables; scientific interpretation and layout review remain.')
if __name__=='__main__':main()
