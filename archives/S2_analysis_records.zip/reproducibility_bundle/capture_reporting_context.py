"""Reconstruct cohort flow without predictions and capture current software metadata."""
from pathlib import Path
import json,hashlib,collections,datetime,subprocess,sys,platform,importlib.metadata
R=Path(__file__).resolve().parent
SRC=Path('D:/Codex Research/MedVQA_SCIE_Local_20261016')
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def versions():
 out={}
 for n in ['torch','transformers','accelerate','numpy','pandas','pillow','safetensors','tokenizers','scipy','matplotlib']:
  try:out[n]=importlib.metadata.version(n)
  except importlib.metadata.PackageNotFoundError:out[n]='not installed in this interpreter'
 return {'python':platform.python_version(),'executable':sys.executable,'platform':platform.platform(),'packages':out}
def main():
 audit=load(R/'controlled_replication/selection_audit.json')
 for p,h in audit['source_hashes'].items():assert sha(Path(p))==h
 pool=read(SRC/'data/g2/candidate_pool.jsonl');old=read(SRC/'data/g2/frozen/split_manifest.jsonl')
 prior=old+read(SRC/'data/metadata/pilot128_manifest.jsonl')+read(SRC/'data/metadata/bank_manifest.jsonl')
 originals={x.get('original_group_id',x['group_id']) for x in prior}
 used={x['group_id'] for x in old}|{x['group_id'] for x in pool if x['original_group_id'] in originals}
 questions={x['question_key'] for x in prior};bytes_used={x['image_sha256'] for x in prior};pixels_used={x['pixel_sha256'] for x in old if x.get('pixel_sha256')}
 eligible=[];excluded=collections.Counter();splits=collections.defaultdict(set)
 for x in pool:
  splits[x['group_id']].add(x['official_split'])
  reason='not_PMC' if x['source_family']!='PMC-VQA' else 'previous_connected_group_including_G1' if x['group_id'] in used else 'exact_normalized_question_seen' if x['question_key'] in questions else 'previous_image_exact' if x['image_sha256'] in bytes_used or x.get('pixel_sha256') in pixels_used else 'technical' if x.get('decode_status')!='PASS' else None
  if reason:excluded[reason]+=1
  else:eligible.append(x)
 assert len(eligible)==audit['eligible_qa'] and dict(excluded)==audit['exclusions']
 assert len(eligible)+sum(excluded.values())==len(pool)
 stable=lambda s:hashlib.sha256(('tool-control-replication-20261018|'+s).encode()).hexdigest()
 selected_questions=set();selected_groups=set();cohorts={}
 for name,tag,n in [('pilot','train',128),('main','test',2048)]:
  by={};qa=0
  for x in eligible:
   if splits[x['group_id']]!={tag}:continue
   qa+=1;g=x['group_id']
   if g not in by or stable(x['sample_id'])<stable(by[g]['sample_id']):by[g]=x
  taken=[];skipped=0
  for x in sorted(by.values(),key=lambda x:stable(x['group_id'])):
   if x['group_id'] in selected_groups or x['question_key'] in selected_questions:skipped+=1;continue
   taken.append(x['sample_id']);selected_groups.add(x['group_id']);selected_questions.add(x['question_key'])
   if len(taken)==n:break
  assert taken==[x['sample_id'] for x in read(R/'controlled_replication'/name/'metadata.jsonl')]
  cohorts[name]={'official_partition':tag,'eligible_questions':qa,'eligible_groups':len(by),'selected_groups':len(taken),'duplicate_question_or_group_skips_before_quota':skipped,'groups_not_selected':len(by)-len(taken)}
 clean=load(R/'clean_validation/selection_audit.json');counts=clean['counts'];excluded_clean=collections.Counter(x['reason'] for x in clean['excluded'])
 retained=counts['parsed_QA']-counts['linked_to_prior_or_current_group']-counts['exact_question_previously_used']
 assert counts['native_QA']-len(clean['excluded'])==retained
 for name,n in [('pilot',64),('validation',825)]:assert len(read(R/'clean_validation'/name/'metadata.jsonl'))==n
 flow={'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'primary':{'archived_candidates':len(pool),'exclusions_by_first_applicable_rule':dict(excluded),'exclusion_priority':['not_PMC','previous_connected_group_including_G1','exact_normalized_question_seen','previous_image_exact','technical'],'eligible_questions_before_split_restriction':len(eligible),'mixed_partition_questions_excluded':sum(len(splits[x['group_id']])>1 for x in eligible),'mixed_partition_groups_excluded':len({x['group_id'] for x in eligible if len(splits[x['group_id']])>1}),'cohorts':cohorts},'curated':{'source_questions':counts['native_QA'],'parsed_questions':counts['parsed_QA'],'exclusions':dict(excluded_clean),'eligible_questions':retained,'one_question_per_connected_group':counts['final_groups'],'questions_not_selected_within_groups':retained-counts['final_groups'],'pilot':64,'validation':825},'caveats':['Primary flow begins with the archived technically screened candidate pool, not the complete PMC-VQA release.','QA counts and connected-group counts have different units.','2B and 4B use identical selected questions; no doubling of sample size.'],'sources':{'primary_audit':sha(R/'controlled_replication/selection_audit.json'),'curated_audit':sha(R/'clean_validation/selection_audit.json')}}
 (R/'cohort_flow.json').write_text(json.dumps(flow,indent=2),encoding='utf-8')
 env_code="import sys;sys.path.insert(0,"+repr(str(R))+ ");from capture_reporting_context import versions;import json;print(json.dumps(versions()))"
 gpu=subprocess.run([str(SRC/'.venv/Scripts/python.exe'),'-B','-c',env_code],capture_output=True,text=True,check=True)
 smi=subprocess.run(['nvidia-smi','--query-gpu=name,driver_version,memory.total','--format=csv,noheader'],capture_output=True,text=True,check=True)
 sys.path.insert(0,str(R/'dependencies'))
 environment={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Contemporaneous environment capture during 4B collection; not a historical environment reconstruction for previous experiments. Metadata reads only; no GPU model loaded.','inference':json.loads(gpu.stdout),'analysis':versions(),'gpu_device_driver_memory':smi.stdout.strip(),'gpu_parallelism':1}
 (R/'environment_reporting.json').write_text(json.dumps(environment,indent=2),encoding='utf-8')
 print(json.dumps({'flow':flow,'environment':environment},indent=2))
if __name__=='__main__':main()
