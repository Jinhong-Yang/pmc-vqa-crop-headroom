"""Frozen G3 BANK rebuild and resumable non-test four-state collection."""
import os
os.environ.setdefault('HF_HUB_OFFLINE','1');os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
from pathlib import Path
import time,json,argparse,traceback,hashlib
import numpy as np,torch,psutil
from transformers import AutoProcessor,AutoImageProcessor,Qwen3VLForConditionalGeneration,SiglipVisionModel
from g3_common import *
from g2_inputs import load_inputs
from run_pilot import Trial,Monitor,image,GIB

def rebuild_bank():
 bank=read(locked('data/g2/frozen/bank_retrieval.jsonl'));p=bank_dir();p.mkdir(parents=True,exist_ok=True)
 if (p/'manifest.json').exists():validate_bank();print('BANK_VALIDATED',flush=True);return
 t=time.perf_counter();processor=AutoImageProcessor.from_pretrained(ROOT/'models/siglip2-base-patch16-224',local_files_only=True)
 model=SiglipVisionModel.from_pretrained(ROOT/'models/siglip2-base-patch16-224',local_files_only=True,dtype=torch.float32).to('cuda').eval();vectors=[]
 with torch.inference_mode():
  for k in range(0,len(bank),16):
   inputs=processor(images=[image(r['image_path'],512) for r in bank[k:k+16]],return_tensors='pt').to('cuda')
   v=torch.nn.functional.normalize(model(**inputs).pooler_output.float(),dim=-1);vectors.append(v.cpu().numpy())
   if k%256==0:print('BANK',min(k+16,len(bank)),len(bank),flush=True)
 vec=np.concatenate(vectors);assert vec.shape==(2000,768) and np.isfinite(vec).all()
 tmp=p/'embeddings.tmp'
 with tmp.open('wb') as f:np.save(f,vec);f.flush();os.fsync(f.fileno())
 tmp.replace(p/'embeddings.npy')
 cfg=load(ROOT/'configs/local_protocol.json')
 dump(p/'manifest.json',dict(bank_sha256=sha(locked('data/g2/frozen/bank_retrieval.jsonl')),experiment_lock_sha256=sha(ROOT/'configs/experiment.lock.json'),encoder_revision=cfg['retrieval']['encoder_revision'],embedding_sha256=sha(p/'embeddings.npy'),sample_ids=[r['sample_id'] for r in bank],image_sha256=[sha(ROOT/r['image_path']) for r in bank],shape=list(vec.shape),dtype=str(vec.dtype),normalization='L2',elapsed_s=time.perf_counter()-t,device='cuda',at_kst=now(),prior_g1_cache_used=False))
 validate_bank();print('BANK_REBUILT',flush=True)

def rank_neighbors(similarities,ids,k=3):return sorted(range(len(ids)),key=lambda i:(-float(similarities[i]),ids[i]))[:k]

class FrozenTrial(Trial):
 def __init__(self):
  t=time.perf_counter();bank,vectors,_=validate_bank()
  self.proc=AutoProcessor.from_pretrained(ROOT/'models/Qwen3-VL-2B-Instruct',local_files_only=True)
  self.zoomproc=AutoProcessor.from_pretrained(ROOT/'models/Qwen3-VL-2B-Instruct',local_files_only=True)
  self.proc.image_processor.size={'shortest_edge':1024,'longest_edge':512**2};self.zoomproc.image_processor.size={'shortest_edge':1024,'longest_edge':256**2}
  self.model=Qwen3VLForConditionalGeneration.from_pretrained(ROOT/'models/Qwen3-VL-2B-Instruct',local_files_only=True,dtype=torch.bfloat16,attn_implementation='sdpa',device_map={'':'cuda'}).eval();self.model.requires_grad_(False)
  self.encoder=SiglipVisionModel.from_pretrained(ROOT/'models/siglip2-base-patch16-224',local_files_only=True,dtype=torch.float32).to('cpu').eval()
  self.ip=AutoImageProcessor.from_pretrained(ROOT/'models/siglip2-base-patch16-224',local_files_only=True)
  self.bank=bank;self.vectors=torch.from_numpy(vectors);self.label_ids=[self.proc.tokenizer.encode(c,add_special_tokens=False) for c in 'ABCD'];assert all(len(x)==1 for x in self.label_ids)
  self.label_ids=[x[0] for x in self.label_ids];self.load_s=time.perf_counter()-t
 @torch.inference_mode()
 def retrieve(self,im):
  b=self.ip(images=im,return_tensors='pt');v=torch.nn.functional.normalize(self.encoder(**b).pooler_output.float(),dim=-1);sims=(v@self.vectors.T)[0].numpy();idx=rank_neighbors(sims,[r['sample_id'] for r in self.bank]);texts=[];ids=[]
  for k in idx:
   r=self.bank[k];texts.append(f'Neighbor {len(texts)+1} (cosine {sims[k]:.6f}): Question: '+r['question']+' Choices: '+'; '.join(r['options'])+' Neighbor answer text: '+r['answer_text']);ids.append(r['sample_id'])
  while texts and len(self.proc.tokenizer.encode('\n'.join(texts),add_special_tokens=False))>512:texts.pop();ids.pop()
  return texts,dict(neighbor_ids=ids,cosine=[float(sims[k]) for k in idx[:len(ids)]],kept=len(ids),retrieval_tokens=len(self.proc.tokenizer.encode('\n'.join(texts),add_special_tokens=False)))
 def attempt(self,name,fn,errors,times):
  start=time.perf_counter()
  for retry in range(3):
   try:
    out=fn();times[name]=time.perf_counter()-start;return out
   except Exception as e:
    transient=isinstance(e,(OSError,torch.cuda.OutOfMemoryError))
    errors.append(dict(component=name,error=type(e).__name__,message=str(e)[:500],retry=retry,transient=transient))
    if isinstance(e,torch.cuda.OutOfMemoryError):torch.cuda.empty_cache()
    if not transient or retry==2:break
  times[name]=time.perf_counter()-start;return None
 def collect(self,x,outdir,binding):
  assert set(x)=={'sample_id','question','options','image_path'}
  t=time.perf_counter();torch.cuda.reset_peak_memory_stats();times={};errors=[];states={};features={};obs={};im=image(x['image_path'],512)
  obs['R']=self.attempt('RETRIEVE',lambda:self.retrieve(im),errors,times)
  obs['Z']=self.attempt('ZOOM',lambda:self.zoom(x),errors,times)
  for s in STATES:
   required=[a for a in ('Z','R') if a in s]
   if any(obs[a] is None for a in required):states[s]={'status':'failed','reason':'tool_failure'};continue
   z=obs['Z'][0] if 'Z' in s else '';r=obs['R'][0] if 'R' in s else []
   def score():
    ns=list(r)
    while True:
     try:
      b,_=self.inputs(im,self.prompt(x,z,ns));del b;break
     except ValueError as e:
      if not ns:raise
      ns.pop()
    result,f=self.score(im,self.prompt(x,z,ns));result.update(status='ok',retrieval_neighbors_used=len(ns));return result,f
   outcome=self.attempt(s,score,errors,times)
   if outcome is None:states[s]={'status':'failed','reason':'scoring_failure'}
   else:states[s],features[s]=outcome
  edges=[]
  for parent,action,child in [('E','Z','Z'),('E','R','R'),('Z','R','ZR'),('R','Z','ZR')]:
   failed=states[parent]['status']!='ok' or obs[action] is None or states[child]['status']!='ok'
   edges.append(dict(parent=parent,action=action,child=child,failed=failed,terminal=failed,attempts=1,last_valid_state=parent if states[parent]['status']=='ok' else None,outcome_state=parent if failed else child,delta_override=0 if failed else None,future_value_allowed=not failed))
  p=outdir/(x['sample_id']+'_features.npz');tmp=p.with_suffix('.tmp')
  with tmp.open('wb') as f:np.savez(f,**features);f.flush();os.fsync(f.fileno())
  tmp.replace(p);row=dict(sample_id=x['sample_id'],input_sha256=hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest(),image_sha256=sha(ROOT/x['image_path']),binding=binding,states=states,edges=edges,zoom_observation=obs['Z'][0] if obs['Z'] else '',zoom=obs['Z'][1] if obs['Z'] else {},retrieval=obs['R'][1] if obs['R'] else {},errors=errors,times_s=times,feature_sha256=sha(p),bundle_s=time.perf_counter()-t,peak_reserved_gib=torch.cuda.max_memory_reserved()/GIB,free_vram_gib_after=torch.cuda.mem_get_info()[0]/GIB,process_rss_gib=psutil.Process().memory_info().rss/GIB,at_kst=now())
  dump(outdir/(x['sample_id']+'.json'),row);return row

def complete_record(x,outdir,binding):
 p=outdir/(x['sample_id']+'.json');f=outdir/(x['sample_id']+'_features.npz')
 if not p.exists() or not f.exists():return None
 r=load(p);assert r['sample_id']==x['sample_id'] and r['binding']==binding
 assert r['input_sha256']==hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest() and r['image_sha256']==sha(ROOT/x['image_path'])
 assert r['feature_sha256']==sha(f) and set(r['states'])==set(STATES) and len(r['edges'])==4
 with np.load(f) as v:
  for s in STATES:
   if r['states'][s]['status']=='ok':assert v[s].shape==(2048,) and np.isfinite(v[s]).all() and np.isfinite(r['states'][s]['option_probs']).all() and abs(sum(r['states'][s]['option_probs'])-1)<1e-5
 return r

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--bank-only',action='store_true');args=parser.parse_args()
 torch.set_num_threads(8);torch.set_num_interop_threads(2);torch.manual_seed(20261016);np.random.seed(20261016)
 ev=ROOT/'evidence/g3';ev.mkdir(parents=True,exist_ok=True);dump(ev/'freeze_verification.json',verify_freeze())
 with gpu_lock():
  rebuild_bank()
  if args.bank_only:return
  binding={name:sha(path) for name,path in [('experiment_lock',ROOT/'configs/experiment.lock.json'),('bank_manifest',bank_dir()/'manifest.json'),('collector',Path(__file__)),('common',ROOT/'scripts/g3_common.py')]}
  out=ROOT/'runs/g3';out.mkdir(parents=True,exist_ok=True);total=sum(len(load_inputs(s)) for s in ALLOWED);monitor=Monitor();monitor.start();start=time.perf_counter();trial=None;completed=0;failures=0
  try:
   for split in ALLOWED:
    dest=out/split.lower();dest.mkdir(exist_ok=True);inputs=load_inputs(split)
    for i,x in enumerate(inputs):
     row=complete_record(x,dest,binding)
     if row is None:
      if trial is None:
       trial=FrozenTrial();dump(ev/'interface_check.json',trial.verify_interface(x));print('MODEL_LOADED',trial.load_s,flush=True)
      row=trial.collect(x,dest,binding)
      assert complete_record(x,dest,binding) is not None
     completed+=1;failures+=sum(s['status']!='ok' for s in row['states'].values())
     if completed%10==0 or i==len(inputs)-1:
      status=dict(stage='COLLECTION',completed_qa=completed,total_qa=total,split=split,split_completed=i+1,failed_states=failures,wall_s=time.perf_counter()-start,at_kst=now(),test_opened=False)
      dump(ev/'progress.json',status);print(json.dumps(status),flush=True)
     if row['peak_reserved_gib']>12 or monitor.free/GIB<2 or (monitor.rss-monitor.base_rss)/GIB>24:raise RuntimeError('Resource gate failed')
     if time.perf_counter()-start>150*3600:raise RuntimeError('Conservative occupancy cap stop')
   dump(ev/'collection_complete.json',dict(status='PASS',qa=completed,state_records=4*completed,failed_states=failures,wall_s=time.perf_counter()-start,binding=binding,peak_rss_gib=monitor.rss/GIB,incremental_rss_gib=(monitor.rss-monitor.base_rss)/GIB,min_free_vram_gib=monitor.free/GIB,test_opened=False,at_kst=now()))
  finally:monitor.stop()
if __name__=='__main__':main()
