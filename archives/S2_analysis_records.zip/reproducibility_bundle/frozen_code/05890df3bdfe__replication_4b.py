"""Second model scale, same fixed input and intervention recipes."""
import sys,time,hashlib,json
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R.parent/'single_tool_feasibility_20261017'))
import collect_feasibility as legacy
import collect_replication as core
from g3_common import validate_bank
from transformers import AutoProcessor,AutoImageProcessor,Qwen3VLForConditionalGeneration,SiglipVisionModel,SiglipTextModel,AutoTokenizer
import torch,numpy as np
MODEL=R/'models/Qwen3-VL-4B-Instruct'

class Experiment4B(legacy.Experiment):
 def __init__(self):
  start=time.perf_counter();bank,vectors,_=validate_bank()
  self.proc=AutoProcessor.from_pretrained(MODEL,local_files_only=True)
  self.zoomproc=AutoProcessor.from_pretrained(MODEL,local_files_only=True)
  self.proc.image_processor.size={'shortest_edge':1024,'longest_edge':512**2};self.zoomproc.image_processor.size={'shortest_edge':1024,'longest_edge':256**2}
  self.model=Qwen3VLForConditionalGeneration.from_pretrained(MODEL,local_files_only=True,dtype=torch.bfloat16,attn_implementation='sdpa',device_map={'':'cuda'}).eval();self.model.requires_grad_(False)
  self.encoder=SiglipVisionModel.from_pretrained(legacy.PROJECT/'models/siglip2-base-patch16-224',local_files_only=True,dtype=torch.float32).to('cuda').eval();self.encoder.requires_grad_(False)
  self.ip=AutoImageProcessor.from_pretrained(legacy.PROJECT/'models/siglip2-base-patch16-224',local_files_only=True)
  self.bank=bank;self.vectors=torch.from_numpy(vectors)
  ids=[self.proc.tokenizer.encode(c,add_special_tokens=False) for c in 'ABCD'];assert all(len(x)==1 for x in ids);self.label_ids=[x[0] for x in ids]
  self.tm=SiglipTextModel.from_pretrained(legacy.PROJECT/'models/siglip2-base-patch16-224',local_files_only=True,dtype=torch.float32).to('cuda').eval();self.tm.requires_grad_(False)
  self.tok=AutoTokenizer.from_pretrained(legacy.PROJECT/'models/siglip2-base-patch16-224',local_files_only=True)
  self.bids=[r['sample_id'] for r in self.bank];self.bvec=self.vectors.to('cuda')
  self.btext=self.embed_text([legacy.query_text(r) for r in self.bank]);self.templates=self.embed_text(list(legacy.FAMILIES.values()))
  self.bfamily=torch.softmax((self.bvec@self.templates.T)/.07,-1).cpu().numpy()
  self.bg=legacy.groups_only('BANK');self.family_names=list(legacy.FAMILIES)
  np.savez_compressed(legacy.OUT/'bank_text_family_features.npz',text=self.btext.cpu().numpy(),family=self.bfamily,templates=self.templates.cpu().numpy(),sample_ids=self.bids)
  self.load_s=time.perf_counter()-start
 @torch.inference_mode()
 def score(self,im,text):
  b,info=self.inputs(im,text);o=self.model.model(**b,use_cache=False,return_dict=True)
  h=o.last_hidden_state[:,-1,:];logits=self.model.lm_head(h).float();lp=torch.log_softmax(logits,dim=-1)[0,self.label_ids]
  probs=torch.softmax(lp,dim=-1).cpu().tolist();feature=h[0].to(device='cpu',dtype=torch.float16).numpy().copy()
  assert feature.shape==(2560,) and np.isfinite(feature).all() and all(np.isfinite(probs))
  result={'answer':'ABCD'[int(torch.argmax(lp))],'option_log_probs':lp.cpu().tolist(),'option_probs':probs,**info}
  del o,h,logits,lp,b
  return result,feature

if __name__=='__main__':
 core.O=R/'controlled_replication_4b';legacy.OUT=core.O
 legacy.Experiment=Experiment4B
 core.main()
