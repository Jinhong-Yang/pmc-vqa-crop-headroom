"""Sealed, reference-blind fresh-group inference using archived tool recipes."""
import sys,os,json,hashlib,time,datetime,argparse
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;O=R/'curated_replication_2b'
sys.path.insert(0,str(R.parent/'single_tool_feasibility_20261017'))
import collect_feasibility as legacy
legacy.OUT=O
from feasibility_common import preserve
from run_pilot import Monitor,GIB
import torch,numpy as np
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def dump(p,x):
 p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');tmp.replace(p)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--cohort',choices=['pilot','main'],required=True);args=ap.parse_args()
 P=O/args.cohort;plan=json.loads((O/'protocol_frozen.json').read_text(encoding='utf-8'));ph=sha(O/'protocol_frozen.json')
 assert sha(Path(__file__))==plan['bindings'][str(Path(__file__).resolve())]
 for p,h in plan['bindings'].items():assert sha(Path(p))==h,(p,'binding changed')
 if args.cohort=='main':assert json.loads((O/'pilot/gate_decision.json').read_text())['main_authorized_by_protocol'] is True
 assert not (P/'prediction_seal.json').exists(),'Already sealed'
 xs=read(P/'inputs.jsonl');expected=plan['design'][args.cohort];assert len(xs)==expected
 for x in xs:assert set(x)=={'sample_id','question','options','image_path'}
 torch.set_num_threads(8);torch.set_num_interop_threads(2);torch.manual_seed(20261018);np.random.seed(20261018)
 assert not (legacy.PROJECT/'runs/gpu.lock').exists(),'Other GPU job active'
 lock=O/'gpu.lock'
 with lock.open('x') as f:json.dump({'pid':os.getpid(),'at':now(),'cohort':args.cohort},f)
 mon=Monitor();mon.start();start=time.perf_counter();files=[];failures=0
 try:
  dump(P/'preservation_before.json',preserve());exp=legacy.Experiment()
  dump(P/'interface_check.json',exp.verify_interface(xs[0]));print('MODEL_READY',args.cohort,flush=True)
  for i,x in enumerate(xs):
   p=P/'predictions'/(x['sample_id']+'.json')
   if p.exists():
    rec=json.loads(p.read_text(encoding='utf-8'));assert rec['protocol_sha256']==ph
   else:
    start_case=time.perf_counter();base,ret,direct,meta=exp.new_observations(x);scores={};errors=[];times={};prompts={}
    for name in plan['conditions']:
     ims=[base,direct[name]] if name.startswith('ROI_') else base
     rr=list(ret.get(name,[]));text=exp.prompt(x,neighbors=rr)
     if name.startswith('ROI_'):text='The first image is the global view. The second image is an additional view of the same figure; it may or may not contain useful detail.\n'+text
     # Existing context bound fits all views; fail explicitly rather than silently edit the prompt.
     def fn():
      out,_=exp.score(ims,text);return dict(out,status='ok',retrieval_neighbors_used=len(rr))
     out=exp.attempt(name,fn,errors,times)
     if out is None:
      if name=='E':raise RuntimeError('Baseline failed: '+str(errors))
      out=dict(scores['E'],status='failed_fallback_E')
     scores[name]=out;prompts[name]=hashlib.sha256(text.encode()).hexdigest()
    torch.cuda.synchronize()
    for name in plan['conditions']:
     if name.startswith('ROI_') and scores[name]['status']=='ok':assert scores[name]['image_tokens']==scores['ROI_HIGH']['image_tokens'],'unmatched ROI image tokens'
    rec=dict(sample_id=x['sample_id'],protocol_sha256=ph,input_sha256=hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest(),scores=scores,observations=meta,errors=errors,times_s=times,prompt_hashes=prompts,bundle_s=time.perf_counter()-start_case)
    dump(p,rec)
   failures+=sum(v['status']!='ok' for v in rec['scores'].values());files.append(dict(path=str(p.relative_to(P)),sha256=sha(p)))
   assert torch.cuda.max_memory_reserved()/GIB<=12 and mon.free/GIB>=2 and (mon.rss-mon.base_rss)/GIB<=24,'Resource gate breach'
   if (i+1)%8==0 or i==len(xs)-1:
    state=dict(stage='INFERENCE',cohort=args.cohort,qa=i+1,total=len(xs),failures=failures,wall_s=time.perf_counter()-start,at=now());dump(P/'progress.json',state);print(json.dumps(state),flush=True)
  dump(P/'prediction_seal.json',dict(status='SEALED_BEFORE_REFERENCE_SCORING',files=files,qa=len(files),predictions=len(files)*len(plan['conditions']),protocol_sha256=ph,input_file_sha256=sha(P/'inputs.jsonl'),at=now()))
  dump(P/'inference_complete.json',dict(status='PASS',qa=len(files),failures=failures,wall_s=time.perf_counter()-start,peak_reserved_gib=torch.cuda.max_memory_reserved()/GIB,min_free_vram_gib=mon.free/GIB,incremental_rss_gib=(mon.rss-mon.base_rss)/GIB,query_references_read=False,at=now()))
  dump(P/'preservation_after.json',preserve());print('SEALED',args.cohort,flush=True)
 finally:mon.stop();lock.unlink(missing_ok=True)
if __name__=='__main__':main()
