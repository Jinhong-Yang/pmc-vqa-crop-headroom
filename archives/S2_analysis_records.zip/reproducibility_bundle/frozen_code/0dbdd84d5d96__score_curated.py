import sys
import score_replication as core
if __name__=='__main__':
 model=sys.argv.pop(1);assert model in ['2b','4b']
 core.O=core.R/('curated_replication_'+model)
 core.main()
