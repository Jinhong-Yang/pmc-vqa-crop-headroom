import collect_curated as core
from replication_4b import Experiment4B
if __name__=='__main__':
 core.O=core.R/'curated_replication_4b'
 core.legacy.OUT=core.O
 core.legacy.Experiment=Experiment4B
 core.main()
