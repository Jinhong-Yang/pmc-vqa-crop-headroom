"""Paired inference only after a complete prediction seal; never tune conditions."""
import json,hashlib,sys,argparse,datetime,collections
from pathlib import Path
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
import pandas as pd
O=R/'controlled_replication'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def ci(a,level=.95,replicates=20000):
 a=np.asarray(a,float);rng=np.random.default_rng(20261018);draws=[]
 for _ in range(replicates//500):draws.append(a[rng.integers(0,len(a),(500,len(a)))].mean(1))
 return np.quantile(np.concatenate(draws),[(1-level)/2,1-(1-level)/2]).tolist()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--cohort',choices=['pilot','main'],required=True);args=ap.parse_args();P=O/args.cohort
 plan=load(O/'protocol_frozen.json');seal=load(P/'prediction_seal.json');selection=load(O/'selection_audit.json')
 assert seal['status']=='SEALED_BEFORE_REFERENCE_SCORING' and seal['protocol_sha256']==sha(O/'protocol_frozen.json')
 assert seal['qa']==plan['design'][args.cohort]
 for n,h in selection['files'].items():assert sha(O/n)==h,(n,'selection input changed')
 xs=read(P/'inputs.jsonl');meta={x['sample_id']:x for x in read(P/'metadata.jsonl')};refs={x['sample_id']:x for x in read(P/'references.jsonl')}
 assert len(meta)==len(refs)==len(xs)==seal['qa'] and len({m['group_id'] for m in meta.values()})==len(xs)
 rows=[];fail=collections.Counter();budgets=[];lengths=[]
 for f in seal['files']:
  p=P/f['path'];assert sha(p)==f['sha256'];r=load(p);sid=r['sample_id'];assert r['protocol_sha256']==seal['protocol_sha256']
  assert set(r['scores'])==set(plan['conditions'])
  row={'sample_id':sid,'group_id':meta[sid]['group_id'],'reference':refs[sid]['reference'],'family':r['observations']['family']['predicted'],'native_long_edge':max(r['observations']['roi']['full_size'])}
  good_roi=[]
  for n,v in r['scores'].items():
   pp=np.asarray(v['option_probs']);assert len(pp)==4 and np.isfinite(pp).all() and abs(pp.sum()-1)<1e-5
   assert v['answer']=='ABCD'[int(pp.argmax())]
   row[n]=int(v['answer']==row['reference']);row[n+'_answer']=v['answer'];fail[n]+=v['status']!='ok'
   if n.startswith('ROI_') and v['status']=='ok':good_roi.append(v['image_tokens'])
  budgets.append(len(set(good_roi))==1)
  lengths.append({'sample_id':sid,**{n:r['scores'][n]['context_tokens'] for n in plan['conditions']}})
  rows.append(row)
 assert len({x['sample_id'] for x in rows})==len(xs) and {x['sample_id'] for x in rows}==set(meta)
 d=pd.DataFrame(rows);e=d.E.to_numpy();oracles=[];D={}
 for name,real,controls in [
  ('roi',['E','ROI_HIGH'],[['E',f'ROI_RANDOM_{s}'] for s in [1,7,42]]),
  ('retrieval',['E','R_IQG'],[['E',f'R_SHUFFLE_{s}'] for s in [1,7,42]]),
  ('two_tools',['E','R_IQG','ROI_HIGH'],[['E',f'R_SHUFFLE_{s}',f'ROI_RANDOM_{s}'] for s in [1,7,42]])]:
  a=d[real].max(axis=1).to_numpy();b=np.mean([d[c].max(axis=1).to_numpy() for c in controls],axis=0);diff=a-b;D[name]=diff
  level=.95 if name=='roi' else .975;interval=ci(diff,level)
  oracles.append({'comparison':name,'tier':'primary' if name=='roi' else 'secondary','n':len(d),'baseline_accuracy':float(e.mean()),'guided_oracle':float(a.mean()),'control_oracle_mean':float(b.mean()),'guided_headroom':float(a.mean()-e.mean()),'control_headroom':float(b.mean()-e.mean()),'difference':float(diff.mean()),'ci_level':level,'ci':interval,'sd':float(diff.std(ddof=1)),'within_2pp':interval[0]>-.02 and interval[1]<.02})
 direct=[]
 for n in plan['conditions']:
  a=d[n].to_numpy();direct.append({'condition':n,'n':len(d),'accuracy':float(a.mean()),'difference_from_E':float((a-e).mean()),'rescue_count':int(((e==0)&(a==1)).sum()),'harm_count':int(((e==1)&(a==0)).sum()),'answer_flip_count':int((d[n+'_answer']!=d.E_answer).sum()),'failure_count':fail[n]})
 checks={'sealed_records_verified':len(d),'same_ROI_image_token_budget':all(budgets),'failed_conditions':dict(fail),'interface_check':load(P/'interface_check.json'),'inference':load(P/'inference_complete.json'),'source_preservation':load(P/'preservation_after.json'),'no_seed_pseudoreplication':True,'one_QA_per_group':True,'reference_join_after_seal':True}
 d.to_csv(P/'per_qa_scored.csv',index=False);pd.DataFrame(lengths).to_csv(P/'context_token_audit.csv',index=False);pd.DataFrame(direct).to_csv(P/'direct_tool_metrics.csv',index=False)
 dump(P/'results.json',{'scope':'pilot exploratory; excluded from main' if args.cohort=='pilot' else 'prespecified fresh local group evaluation; fixed model and recipe','oracle_contrasts':oracles,'direct_metrics':direct,'checks':checks,'protocol_sha256':seal['protocol_sha256'],'prediction_seal_sha256':sha(P/'prediction_seal.json'),'scorer_sha256':sha(Path(__file__)),'bootstrap':'20000 paired group draws; one QA per group; fixed seed20261018','limitations':plan['tools']['caveats']+['Benchmark reference quality and foundation-model pretraining overlap not verified'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 if args.cohort=='pilot':
  half=1.96*float(D['roi'].std(ddof=1))/np.sqrt(plan['design']['main'])
  criteria={'integrity':all(budgets) and checks['interface_check']['pass'],'technical':all(n/len(d)<=.01 for n in fail.values()),'precision':bool(half<=.02),'scientific':True}
  dump(P/'gate_decision.json',{'main_authorized_by_protocol':all(criteria.values()),'criteria':criteria,'projected_main_primary_half_width':float(half),'effect_sign_not_a_gate':True,'scientific_rationale':'A fixed-model, fixed-benchmark empirical replication/extension estimates question-guided crop-selection advantage over non-selected crops at equal candidate count and image-token budget. Does not claim a novel oracle metric, a new ROI method, or general causal information value.','not_journal_ready':True,'remaining':['complete main cohort before reading its aggregate outcomes','replicate at a second model scale if resource pilot passes','assess scope, label quality, literature and full reproducibility'],'results_sha256':sha(P/'results.json')})
 print(json.dumps({'cohort':args.cohort,'oracles':oracles,'gate':load(P/'gate_decision.json') if args.cohort=='pilot' else None},indent=2))
if __name__=='__main__':main()
