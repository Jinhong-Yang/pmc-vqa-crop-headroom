"""Local four-state VQA feasibility trial. Model inputs never include query labels."""
from pathlib import Path
import os,json,time,argparse,hashlib,threading,subprocess,datetime,traceback,contextlib,sys,statistics
os.environ.setdefault('HF_HUB_OFFLINE','1');os.environ.setdefault('TRANSFORMERS_OFFLINE','1');os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import torch,numpy as np,psutil
from PIL import Image,ImageOps
from transformers import AutoProcessor,AutoImageProcessor,Qwen3VLForConditionalGeneration,SiglipVisionModel
ROOT=Path(__file__).resolve().parents[1]
GIB=2**30
def readlines(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True); t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');t.replace(p)
def image(p,edge):
    with Image.open(ROOT/p) as im: x=ImageOps.exif_transpose(im).convert('RGB')
    x.thumbnail((edge,edge),Image.Resampling.LANCZOS);return x
def samples_config():
    return {'model_revision':'89644892e4d85e24eaac8bacfd4f463576704203','dtype':'bfloat16','attention':'sdpa','image_edge':512,'crop_edge':256,'max_context':3072,'zoom_max_new_tokens':64,'sampling':False,'original_min_pixels':1024,'original_max_pixels':512**2,'zoom_min_pixels':1024,'zoom_max_pixels':256**2,'cpu_threads':8,'retrieval_neighbors':3,'retrieval_max_tokens':512,'scoring':'conditional log probability of A/B/C/D at final pre-answer position; normalized over four choices','feature':'final pre-answer last-layer hidden state, 2048 dims, FP16 CPU','query_input_fields':['sample_id','question','options','image_path']}
class Monitor:
    def __init__(self):self.stop_event=threading.Event();self.rss=psutil.Process().memory_info().rss;self.base_rss=self.rss;self.free=1e99;self.samples=0;self.system_available=1e99
    def loop(self):
        while not self.stop_event.is_set():
            self.rss=max(self.rss,psutil.Process().memory_info().rss);self.system_available=min(self.system_available,psutil.virtual_memory().available)
            try:self.free=min(self.free,torch.cuda.mem_get_info()[0])
            except Exception:pass
            self.samples+=1;self.stop_event.wait(.2)
    def start(self):self.thread=threading.Thread(target=self.loop,daemon=True);self.thread.start()
    def stop(self):self.stop_event.set();self.thread.join()
def build_bank():
    torch.set_num_threads(8); torch.set_num_interop_threads(2)
    bank=readlines(ROOT/'data/metadata/bank_manifest.jsonl'); t=time.perf_counter()
    processor=AutoImageProcessor.from_pretrained(ROOT/'models/siglip2-base-patch16-224',local_files_only=True)
    model=SiglipVisionModel.from_pretrained(ROOT/'models/siglip2-base-patch16-224',local_files_only=True,dtype=torch.float32).to('cuda').eval()
    vectors=[]
    with torch.inference_mode():
        for k in range(0,len(bank),16):
            batch=[image(x['image_path'],512) for x in bank[k:k+16]]
            inputs=processor(images=batch,return_tensors='pt').to('cuda')
            v=model(**inputs).pooler_output.float();v=torch.nn.functional.normalize(v,dim=-1);vectors.append(v.cpu())
            if k%256==0:print(f'BANK_EMBED {min(k+16,len(bank))}/{len(bank)}',flush=True)
    vec=torch.cat(vectors).numpy(); assert vec.shape[0]==len(bank) and np.isfinite(vec).all()
    dest=ROOT/'cache/retrieval';dest.mkdir(exist_ok=True,parents=True)
    tmp=dest/'bank_embeddings.tmp';
    with tmp.open('wb') as f:np.save(f,vec)
    tmp.replace(dest/'bank_embeddings.npy')
    dump(dest/'bank_embedding_manifest.json',{'bank_manifest_sha256':digest(ROOT/'data/metadata/bank_manifest.jsonl'),'model_revision':next(x['revision'] for x in json.loads((ROOT/'evidence/source_snapshots.json').read_text(encoding='utf-8')) if x['repo']=='google/siglip2-base-patch16-224'),'shape':list(vec.shape),'dtype':str(vec.dtype),'sha256':digest(dest/'bank_embeddings.npy'),'elapsed_s':time.perf_counter()-t,'device':'cuda','cpu_threads':8,'peak_reserved_gib':torch.cuda.max_memory_reserved()/GIB})
    print('BANK_COMPLETE',vec.shape,time.perf_counter()-t,flush=True)
class Trial:
    def __init__(self):
        t=time.perf_counter();self.proc=AutoProcessor.from_pretrained(ROOT/'models/Qwen3-VL-2B-Instruct',local_files_only=True)
        self.zoomproc=AutoProcessor.from_pretrained(ROOT/'models/Qwen3-VL-2B-Instruct',local_files_only=True)
        self.proc.image_processor.size={'shortest_edge':1024,'longest_edge':512**2}
        self.zoomproc.image_processor.size={'shortest_edge':1024,'longest_edge':256**2}
        self.model=Qwen3VLForConditionalGeneration.from_pretrained(ROOT/'models/Qwen3-VL-2B-Instruct',local_files_only=True,dtype=torch.bfloat16,attn_implementation='sdpa',device_map={'':'cuda'}).eval()
        self.model.requires_grad_(False)
        self.encoder=SiglipVisionModel.from_pretrained(ROOT/'models/siglip2-base-patch16-224',local_files_only=True,dtype=torch.float32).to('cpu').eval()
        self.ip=AutoImageProcessor.from_pretrained(ROOT/'models/siglip2-base-patch16-224',local_files_only=True)
        self.bank=readlines(ROOT/'data/metadata/bank_manifest.jsonl'); self.vectors=torch.from_numpy(np.load(ROOT/'cache/retrieval/bank_embeddings.npy'))
        self.label_ids=[self.proc.tokenizer.encode(c,add_special_tokens=False) for c in 'ABCD'];assert all(len(x)==1 for x in self.label_ids),self.label_ids
        self.label_ids=[x[0] for x in self.label_ids];self.load_s=time.perf_counter()-t
    def prompt(self,x,z='',neighbors=None):
        q=x['question']+'\n'+'\n'.join(f'{a}: {s}' for a,s in zip('ABCD',x['options']))
        s='Answer the multiple-choice question using the image. The additional observations may be helpful or misleading.\n'+q
        if z:s+='\nVisual crop observation:\n'+z
        if neighbors:s+='\nRetrieved examples (different images):\n'+'\n'.join(neighbors)
        return s+'\nRespond with exactly one of A, B, C, D.\nAnswer:'
    def inputs(self,im,text,zoom=False):
        p=self.zoomproc if zoom else self.proc
        ims=im if isinstance(im,list) else [im]
        content=[{'type':'image','image':v} for v in ims]+[{'type':'text','text':text}]
        b=p.apply_chat_template([{'role':'user','content':content}],tokenize=True,add_generation_prompt=True,return_dict=True,return_tensors='pt')
        n=int(b['input_ids'].shape[-1]);g=b.get('image_grid_thw')
        info={'context_tokens':n,'image_tokens':int(g.prod(dim=-1).sum().item()//4) if g is not None else 0,'native_image_shapes':[[int(row[1])*16,int(row[2])*16] for row in g] if g is not None else []}
        if n+(64 if zoom else 1)>3072:raise ValueError(f'context_overflow {n}')
        return b.to('cuda'),info
    @torch.inference_mode()
    def verify_interface(self,x):
        im=image(x['image_path'],512);b,info=self.inputs(im,self.prompt(x))
        optimized,feature=self.score(im,self.prompt(x))
        official=self.model(**b,use_cache=False,logits_to_keep=1,return_dict=True).logits
        assert official.shape[1]==1
        lp=torch.log_softmax(official[0,-1].float(),dim=-1)[self.label_ids].cpu().numpy()
        error=float(np.max(np.abs(lp-np.asarray(optimized['option_log_probs']))))
        assert error<1e-4, error
        return {'official_logits_shape':list(official.shape),'max_absolute_logprob_difference':error,'hidden_feature_shape':list(feature.shape),'single_token_options':True,'pass':True,**info}
    @torch.inference_mode()
    def score(self,im,text):
        b,info=self.inputs(im,text)
        # Only the final position is passed to lm_head; no full-context vocab logits.
        o=self.model.model(**b,use_cache=False,return_dict=True)
        h=o.last_hidden_state[:,-1,:];logits=self.model.lm_head(h).float();lp=torch.log_softmax(logits,dim=-1)[0,self.label_ids]
        probs=torch.softmax(lp,dim=-1).cpu().tolist();feature=h[0].to(device='cpu',dtype=torch.float16).numpy().copy()
        assert feature.shape==(2048,) and np.isfinite(feature).all() and all(np.isfinite(probs))
        result={'answer':'ABCD'[int(torch.argmax(lp))],'option_log_probs':lp.cpu().tolist(),'option_probs':probs,**info}
        del o,h,logits,lp,b
        return result,feature
    @torch.inference_mode()
    def zoom(self,x):
        # Crops come from the original full-resolution image, before original-image resizing.
        full=image(x['image_path'],10**9);w,h=full.size; crops=[]
        for box in [(0,0,w//2,h//2),(w//2,0,w,h//2),(0,h//2,w//2,h),(w//2,h//2,w,h)]:
            crop=full.crop(box);crop.thumbnail((256,256),Image.Resampling.LANCZOS);crops.append(crop)
        text='Inspect these four non-overlapping image crops. Briefly describe visual findings relevant to this question. Do not choose an option.\n'+x['question']+'\n'+'\n'.join(f'{a}: {s}' for a,s in zip('ABCD',x['options']))
        b,info=self.inputs(crops,text,zoom=True);n=b['input_ids'].shape[-1]
        ids=self.model.generate(**b,max_new_tokens=64,do_sample=False,use_cache=True,pad_token_id=self.proc.tokenizer.eos_token_id)
        new=ids[0,n:];out=self.proc.tokenizer.decode(new,skip_special_tokens=True).strip()
        info['generated_tokens']=int(new.numel());info['hit_token_cap']=new.numel()==64
        if not out:raise ValueError('empty_zoom_observation')
        return out,info
    @torch.inference_mode()
    def retrieve(self,im):
        b=self.ip(images=im,return_tensors='pt');v=self.encoder(**b).pooler_output.float();v=torch.nn.functional.normalize(v,dim=-1)
        sims=(v@self.vectors.T)[0];values,idx=torch.topk(sims,3)
        texts=[];ids=[]
        for val,k in zip(values.tolist(),idx.tolist()):
            row=self.bank[k]
            text=f'Neighbor {len(texts)+1} (cosine {val:.6f}): Question: '+row['question']+' Choices: '+'; '.join(row['options'])+' Neighbor answer text: '+row['answer_text']
            texts.append(text);ids.append(row['sample_id'])
        while texts and len(self.proc.tokenizer.encode('\n'.join(texts),add_special_tokens=False))>512:texts.pop();ids.pop()
        return texts,{'neighbor_ids':ids,'cosine':values.tolist()[:len(ids)],'kept':len(ids),'retrieval_tokens':len(self.proc.tokenizer.encode('\n'.join(texts),add_special_tokens=False))}
    def one(self,x,outdir):
        assert set(x)=={'sample_id','question','options','image_path'},'Forbidden model input fields'
        t=time.perf_counter();torch.cuda.reset_peak_memory_stats();times={};states={};features=[];errors=[];zi={};ri={};z='';r=[]
        im=image(x['image_path'],512)
        for component in ('E','RETRIEVE','ZOOM','Z','R','ZR'):
            ts=time.perf_counter()
            try:
                if component=='RETRIEVE':r,ri=self.retrieve(im)
                elif component=='ZOOM':z,zi=self.zoom(x)
                else:
                    ns=list(r) if 'R' in component else []
                    zs=z if 'Z' in component else ''
                    while True:
                        try:b,info=self.inputs(im,self.prompt(x,zs,ns));del b;break
                        except ValueError:
                            if not ns:raise
                            ns.pop()
                    s,feature=self.score(im,self.prompt(x,zs,ns));s['retrieval_neighbors_used']=len(ns);s['status']='ok';states[component]=s;features.append((component,feature))
            except Exception as e:
                msg={'component':component,'error':type(e).__name__,'message':str(e)[:500]};errors.append(msg)
                if isinstance(e,torch.cuda.OutOfMemoryError):torch.cuda.empty_cache()
                if component in ('E','Z','R','ZR'):states[component]={'status':'failed',**msg}
            torch.cuda.synchronize();times[component]=time.perf_counter()-ts
        path=outdir/(x['sample_id']+'_features.npz');tmp=path.with_suffix('.tmp')
        with tmp.open('wb') as f:np.savez(f,**{k:v for k,v in features})
        tmp.replace(path)
        record={'sample_id':x['sample_id'],'states':states,'zoom_observation':z,'zoom':zi,'retrieval':ri,'errors':errors,'times_s':times,'peak_allocated_gib':torch.cuda.max_memory_allocated()/GIB,'peak_reserved_gib':torch.cuda.max_memory_reserved()/GIB,'free_vram_gib_after':torch.cuda.mem_get_info()[0]/GIB,'process_rss_gib':psutil.Process().memory_info().rss/GIB,'feature_sha256':digest(path)}
        dump(outdir/(x['sample_id']+'.json'),record);record['bundle_s']=time.perf_counter()-t
        # The ledger includes retrieval CPU work, preprocessing, four-state scoring and durable writes.
        with (outdir/'ledger.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(record,ensure_ascii=False,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
        return record
def run(args):
    torch.set_num_threads(8);torch.set_num_interop_threads(2);torch.manual_seed(20261016);np.random.seed(20261016)
    inputs=readlines(ROOT/'data/metadata/pilot128_inputs.jsonl')[:args.count]
    cfg=samples_config();outdir=ROOT/'runs/pilot128'/args.run_id;outdir.mkdir(parents=True,exist_ok=True)
    if (outdir/'ledger.jsonl').exists():raise FileExistsError('Use a new run-id for a continuous measured pass')
    dump(outdir/'config.json',cfg)
    monitor=Monitor();monitor.start();wall=time.perf_counter();rows=[]
    try:
        trial=Trial();print('MODEL_LOADED',trial.load_s,'label_token_ids',trial.label_ids,flush=True)
        dump(outdir/'load.json',{'load_s':trial.load_s,'label_token_ids':trial.label_ids,'torch':torch.__version__,'transformers':__import__('transformers').__version__,'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name(0)})
        if args.count==1:
            validation=trial.verify_interface(inputs[0]);dump(outdir/'interface_checks.json',validation);print('INTERFACE_CHECK',validation,flush=True)
        for k,x in enumerate(inputs):
            row=trial.one(x,outdir);rows.append(row);print(f"QA {k+1}/{len(inputs)} bundle={row['bundle_s']:.2f}s reserved={row['peak_reserved_gib']:.2f}GiB errors={len(row['errors'])}",flush=True)
            if row['peak_reserved_gib']>12 or monitor.free/GIB<2 or (monitor.rss-monitor.base_rss)/GIB>24:
                print('RESOURCE_GATE_STOP',flush=True);break
    finally:monitor.stop()
    elapsed=time.perf_counter()-wall;times=[r['bundle_s'] for r in rows];errors=[e for r in rows for e in r['errors']]
    report={'run_id':args.run_id,'requested_qa':args.count,'completed_qa':len(rows),'state_records':sum(len(r['states']) for r in rows),'state_successes':sum(s['status']=='ok' for r in rows for s in r['states'].values()),'errors':errors,'oom_count':sum(e['error']=='OutOfMemoryError' for e in errors),'mean_bundle_s':statistics.mean(times),'p50_bundle_s':float(np.percentile(times,50)),'p95_bundle_s':float(np.percentile(times,95)),'max_bundle_s':max(times),'total_wall_s':elapsed,'cold_load_s':trial.load_s,'peak_allocated_gib':max(r['peak_allocated_gib'] for r in rows),'peak_reserved_gib':max(r['peak_reserved_gib'] for r in rows),'min_free_vram_gib_sampled':monitor.free/GIB,'peak_process_rss_gib':monitor.rss/GIB,'incremental_process_rss_gib':(monitor.rss-monitor.base_rss)/GIB,'min_system_available_ram_gib':monitor.system_available/GIB,'monitor_samples':monitor.samples,'max_context_tokens':max((s.get('context_tokens',0) for r in rows for s in r['states'].values()),default=0),'max_zoom_input_tokens':max((r['zoom'].get('context_tokens',0) for r in rows),default=0),'zoom_empty_count':sum(not r['zoom_observation'] for r in rows),'zoom_token_cap_count':sum(r['zoom'].get('hit_token_cap',False) for r in rows),'input_manifest_sha256':digest(ROOT/'data/metadata/pilot128_inputs.jsonl'),'config_sha256':digest(outdir/'config.json'),'labels_used_by_inference':False,'finished_at_kst':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat()}
    report['estimates_hours']={name:1.2*(n*report['mean_bundle_s']/3600+16) for name,n in [('local-main',6928),('local-small',4028)]}
    report['estimates_p95_hours']={name:1.2*(n*report['p95_bundle_s']/3600+16) for name,n in [('local-main',6928),('local-small',4028)]}
    report['resource_gate_pass']=len(rows)==args.count and not errors and report['oom_count']==0 and report['peak_reserved_gib']<=12 and report['min_free_vram_gib_sampled']>=2 and report['incremental_process_rss_gib']<=24
    dump(outdir/'summary.json',report);print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--bank',action='store_true');parser.add_argument('--count',type=int,default=128);parser.add_argument('--run-id',default='continuous128');args=parser.parse_args()
    lock=ROOT/'runs/gpu.lock'
    try:
        with lock.open('x') as f:json.dump({'pid':os.getpid(),'started_at':time.time(),'command':sys.argv},f)
    except FileExistsError:raise RuntimeError('GPU project lock exists; inspect owner before restarting')
    try:
        if args.bank:build_bank()
        else:run(args)
    finally:lock.unlink(missing_ok=True)
if __name__=='__main__':main()
