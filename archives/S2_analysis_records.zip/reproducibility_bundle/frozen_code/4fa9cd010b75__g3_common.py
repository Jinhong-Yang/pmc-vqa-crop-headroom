"""G3 freeze bindings. Evaluation partitions are never opened here."""
from pathlib import Path
import json, hashlib, datetime, os, contextlib
ROOT=Path(__file__).resolve().parents[1]
ALLOWED=('PILOT','TRAIN','DEV_FIT')
STATES=('E','Z','R','ZR')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):return [json.loads(s) for s in Path(p).read_text(encoding='utf-8').splitlines() if s.strip()]
def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def now():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat()
def dump(p,obj):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp')
 with t.open('w',encoding='utf-8') as f:json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
 t.replace(p)
def locked(rel):
 entry=next(x for x in load(ROOT/'configs/experiment.lock.json')['artifacts'] if x['path']==rel)
 if sha(ROOT/rel)!=entry['sha256']:raise RuntimeError('Frozen artifact mismatch: '+rel)
 return ROOT/rel
def verify_freeze():
 paths=['configs/local_protocol.json','scripts/run_pilot.py','scripts/g2_inputs.py','environment/requirements.lock.txt','data/g2/frozen/bank_retrieval.jsonl','data/g2/frozen/crossfit_folds.json']
 paths += [f'data/g2/frozen/{kind}/{s.lower()}.jsonl' for s in ALLOWED for kind in ('inputs','references')]
 for rel in paths:locked(rel)
 cfg=load(ROOT/'configs/local_protocol.json');assert cfg['selected_profile']=='local-main' and cfg['document_version']=='4.1'
 return {'status':'PASS','checked_paths':paths,'experiment_lock_sha256':sha(ROOT/'configs/experiment.lock.json'),'protocol_sha256':sha(ROOT/'configs/local_protocol.json'),'test_or_dev_lock_opened':False,'at_kst':now()}
def references(split):
 if split.upper() not in ALLOWED:raise RuntimeError('G3 reference partition forbidden')
 return read(locked(f'data/g2/frozen/references/{split.lower()}.jsonl'))
def bank_dir():return ROOT/'cache/g3_bank_v4_1'
def validate_bank():
 import numpy as np
 p=bank_dir();m=load(p/'manifest.json');bank=read(locked('data/g2/frozen/bank_retrieval.jsonl'))
 assert m['bank_sha256']==sha(locked('data/g2/frozen/bank_retrieval.jsonl'))
 assert m['experiment_lock_sha256']==sha(ROOT/'configs/experiment.lock.json')
 assert m['sample_ids']==[r['sample_id'] for r in bank]
 assert m['embedding_sha256']==sha(p/'embeddings.npy')
 assert m['encoder_revision']==load(ROOT/'configs/local_protocol.json')['retrieval']['encoder_revision']
 v=np.load(p/'embeddings.npy');assert v.shape==(len(bank),768) and v.dtype==np.float32 and np.isfinite(v).all()
 assert np.max(np.abs(np.linalg.norm(v,axis=1)-1))<1e-5
 for r,h in zip(bank,m['image_sha256']):assert sha(ROOT/r['image_path'])==h
 return bank,v,m
@contextlib.contextmanager
def gpu_lock():
 p=ROOT/'runs/gpu.lock';token={'pid':os.getpid(),'at_kst':now(),'stage':'G3'}
 with p.open('x',encoding='utf-8') as f:json.dump(token,f)
 try:yield
 finally:
  if p.exists() and load(p).get('pid')==os.getpid():p.unlink()
