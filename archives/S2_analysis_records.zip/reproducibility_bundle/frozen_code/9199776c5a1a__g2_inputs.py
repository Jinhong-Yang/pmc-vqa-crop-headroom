"""Strict query loader for the G2 freeze. Does not read reference files."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
FIELDS={'sample_id','question','options','image_path'}
def load_inputs(split,stage='development'):
 split=split.upper()
 if split in {'TEST_ID','TEST_SOURCE','DEV_LOCK'} and stage!='final_locked_evaluation':raise RuntimeError('G4 completion and final evaluation stage required for this partition')
 if split not in {'PILOT','BANK','TRAIN','DEV_FIT','DEV_LOCK','TEST_ID','TEST_SOURCE'}:raise ValueError(split)
 lock=json.loads((ROOT/'configs/experiment.lock.json').read_text(encoding='utf-8'))
 if split in {'TEST_ID','TEST_SOURCE','DEV_LOCK'}:
  gate=ROOT/'evidence/g4_completion.json'
  if not gate.exists():raise RuntimeError('G4 completion evidence is absent')
  record=json.loads(gate.read_text(encoding='utf-8'))
  if record.get('status')!='PASS' or record.get('experiment_lock_sha256')!=hashlib.sha256((ROOT/'configs/experiment.lock.json').read_bytes()).hexdigest():raise RuntimeError('G4 record does not authorize this experiment lock')
 rel=f'data/g2/frozen/inputs/{split.lower()}.jsonl';entry=next(r for r in lock['artifacts'] if r['path']==rel);p=ROOT/rel
 if hashlib.sha256(p.read_bytes()).hexdigest()!=entry['sha256']:raise RuntimeError('Frozen input hash mismatch')
 rows=[json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s]
 if not all(set(r)==FIELDS for r in rows):raise ValueError('Forbidden input metadata or missing fields')
 return rows
