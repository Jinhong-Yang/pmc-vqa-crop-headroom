"""Run with Python3+NumPy: python portable_reanalysis.py /path/to/reproducibility_bundle.

Independent aggregate calculations from released answer records. Does not import
the original inference or score code, use a GPU, or change a study decision.
"""
import argparse,csv,json,hashlib
from pathlib import Path
import numpy as np
SEEDS=(1,7,42)
def interval(x,level):
 rng=np.random.default_rng(20261018);means=[];n=len(x)
 for _ in range(40):
  idx=rng.integers(0,n,size=(500,n));means.extend(np.sum(x[idx],axis=1)/n)
 return np.quantile(means,[(1-level)/2,1-(1-level)/2]).tolist()
def calculate(path,include_sensitivity=False):
 rows=list(csv.DictReader(path.open(encoding='utf-8',newline='')));groups={};answers={};refs={}
 for r in rows:
  sid=r['sample_id'];groups.setdefault(sid,r['group_id']);refs.setdefault(sid,r['reference']);answers.setdefault(sid,{})
  assert groups[sid]==r['group_id'] and refs[sid]==r['reference']
  assert r['condition'] not in answers[sid] and r['answer'] in 'ABCD' and len(r['answer'])==1
  probabilities=np.array([float(r['probability_'+a]) for a in 'ABCD'])
  assert np.isfinite(probabilities).all() and np.all(probabilities>=0) and abs(probabilities.sum()-1)<1e-5
  assert r['answer']=='ABCD'[int(probabilities.argmax())]
  answers[sid][r['condition']]=r['answer']
 ids=list(answers);assert len(set(groups.values()))==len(ids)
 conditions=list(answers[ids[0]])
 assert len(conditions)==11 and all(set(a)==set(conditions) for a in answers.values())
 c={k:np.array([int(answers[s][k]==refs[s]) for s in ids],dtype=float) for k in conditions};e=c['E'];contrasts=[]
 for name,guided,control in [('roi',['ROI_HIGH'],[[f'ROI_RANDOM_{s}'] for s in SEEDS]),('retrieval',['R_IQG'],[[f'R_SHUFFLE_{s}'] for s in SEEDS]),('two_tools',['ROI_HIGH','R_IQG'],[[f'ROI_RANDOM_{s}',f'R_SHUFFLE_{s}'] for s in SEEDS])]:
  a=np.maximum.reduce([e]+[c[k] for k in guided]);b=sum(np.maximum.reduce([e]+[c[k] for k in keys]) for keys in control)/3;d=a-b;level=.95 if name=='roi' else .975
  contrasts.append({'comparison':name,'n':len(ids),'baseline_accuracy':float(e.mean()),'guided_oracle':float(a.mean()),'control_oracle_mean':float(b.mean()),'difference':float(d.mean()),'ci_level':level,'ci':interval(d,level)})
 direct=[{'condition':k,'accuracy':float(c[k].mean()),'rescue_count':int(np.sum((e==0)&(c[k]==1))),'harm_count':int(np.sum((e==1)&(c[k]==0))),'answer_flip_count':sum(answers[s][k]!=answers[s]['E'] for s in ids)} for k in conditions]
 result={'oracle_contrasts':contrasts,'direct_metrics':direct}
 if include_sensitivity:
  sensitivity=[];diversity=[];g=c['ROI_HIGH']
  for control in ['ROI_DUPLICATE','ROI_LOW']:
   for metric,delta in [('direct_accuracy',g-c[control]),('two_candidate_oracle',np.maximum(e,g)-np.maximum(e,c[control]))]:
    sensitivity.append({'guided':'ROI_HIGH','control':control,'metric':metric,'n':len(ids),'estimate':float(delta.mean()),'ci95':interval(delta,.95)})
  for name,sets in [('crop_guided',[['E','ROI_HIGH']]),('crop_controls',[['E',f'ROI_RANDOM_{s}'] for s in SEEDS]),('retrieval_guided',[['E','R_IQG']]),('retrieval_controls',[['E',f'R_SHUFFLE_{s}'] for s in SEEDS]),('combined_guided',[['E','R_IQG','ROI_HIGH']]),('combined_controls',[['E',f'R_SHUFFLE_{s}',f'ROI_RANDOM_{s}'] for s in SEEDS])]:
   counts=np.array([[len({answers[s][condition] for condition in columns}) for s in ids] for columns in sets]);k=len(sets[0])
   diversity.append({'candidate_set':name,'questions':len(ids),'candidates_per_set':k,'seed_sets':len(sets),'mean_unique_answer_labels':float(counts.mean()),'fraction_by_unique_labels':{str(j):float((counts==j).mean()) for j in range(1,k+1)}})
  result.update(sensitivity_contrasts=sensitivity,candidate_diversity=diversity)
 return result
def verify_raw_records(root,label):
 evidence=root/'run_evidence'/label
 seal=json.loads((evidence/'prediction_seal.json').read_text(encoding='utf-8'))
 refs={r['sample_id']:r['reference'] for r in [json.loads(s) for s in (evidence/'references.jsonl').read_text(encoding='utf-8').splitlines() if s]}
 records={}
 for f in seal['files']:
  p=root/'raw_predictions'/label/f['path'].replace('\\','/').split('/')[-1]
  assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
  r=json.loads(p.read_text(encoding='utf-8'));assert r['sample_id'] not in records;records[r['sample_id']]=r
 rows=list(csv.DictReader((root/'answer_records'/(label+'.csv')).open(encoding='utf-8',newline='')))
 assert len(rows)==11*len(records)==seal['predictions'] and set(records)==set(refs)
 keys=set()
 for row in rows:
  sid,c=row['sample_id'],row['condition'];assert (sid,c) not in keys;keys.add((sid,c));v=records[sid]['scores'][c]
  assert row['reference']==refs[sid] and row['answer']==v['answer'] and row['status']==v['status']
  assert [float(row['probability_'+a]) for a in 'ABCD']==v['option_probs']
 return len(rows)
def verify_historical(root):
 P=root/'historical_discovery'
 if not P.exists():return {'status':'NOT_INCLUDED_IN_SINGLE_COHORT_DEVELOPMENT_CHECK'}
 seal=json.loads((P/'prediction_seal.json').read_text(encoding='utf-8'));rows=list(csv.DictReader((P/'per_qa_scored.csv').open(encoding='utf-8-sig',newline='')))
 table={(r['split'],r['sample_id']):r for r in rows};refs={(r['split'],r['sample_id']):r['reference'] for r in [json.loads(s) for s in (P/'selected_references.jsonl').read_text(encoding='utf-8').splitlines() if s]}
 checked=0
 for f in seal['files']:
  p=P/f['path'].replace('\\','/');assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'];r=json.loads(p.read_text(encoding='utf-8'));split=f['path'].replace('\\','/').split('/')[1].upper();key=(split,r['sample_id'])
  assert len(r['scores'])==16
  for condition,value in r['scores'].items():assert float(table[key][condition])==int(value['answer']==refs[key]);checked+=1
 assert checked==21600 and len(rows)==1350
 expected=json.loads((root/'discovery_reanalysis/equal_cardinality_oracle_diagnostic.json').read_text(encoding='utf-8'));results=[]
 for split in ['DEV_FIT','TRAIN']:
  rr=[r for r in rows if r['split']==split];names=['E','ROI_HIGH','R_IQG']+[f'{p}_{s}' for p in ['ROI_RANDOM','R_SHUFFLE'] for s in SEEDS];c={k:np.array([float(r[k]) for r in rr]) for k in names};groups=np.array([r['group_id'] for r in rr]);unique,inv=np.unique(groups,return_inverse=True);sizes=np.bincount(inv)
  for name,guided,controls in [('roi',['ROI_HIGH'],[[f'ROI_RANDOM_{s}'] for s in SEEDS]),('retrieval',['R_IQG'],[[f'R_SHUFFLE_{s}'] for s in SEEDS]),('two_tools',['ROI_HIGH','R_IQG'],[[f'ROI_RANDOM_{s}',f'R_SHUFFLE_{s}'] for s in SEEDS])]:
   a=np.maximum.reduce([c['E']]+[c[k] for k in guided]);b=sum(np.maximum.reduce([c['E']]+[c[k] for k in control]) for control in controls)/3;delta=a-b;sums=np.bincount(inv,weights=delta);rng=np.random.default_rng(20261018);idx=rng.integers(0,len(unique),(5000,len(unique)));ci=np.quantile(sums[idx].sum(1)/sizes[idx].sum(1),[.025,.975]);wanted=next(x for x in expected if x['split']==split and x['comparison']==name)
   assert abs(delta.mean()-wanted['contrast'])<1e-12 and np.max(np.abs(ci-wanted['ci95']))<1e-10
   results.append({'split':split,'comparison':name,'difference':float(delta.mean()),'ci95':ci.tolist(),'qa':len(rr),'groups':len(unique)})
 return {'status':'PASS','questions':1350,'predictions_verified':checked,'role':'Discovery only, not independent new validation','contrasts':results}
def main():
 p=argparse.ArgumentParser();p.add_argument('bundle',type=Path);args=p.parse_args();root=args.bundle;manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
 for rel,h in manifest['files'].items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==h,rel
 audit={}
 for fn in sorted((root/'answer_records').glob('*.csv')):
  raw_count=verify_raw_records(root,fn.stem)
  supplementary_path=root/'run_evidence'/fn.stem/'supplementary_results.json'
  supplementary=json.loads(supplementary_path.read_text(encoding='utf-8')) if supplementary_path.exists() else None
  result=calculate(fn,include_sensitivity=supplementary is not None);expected=json.loads((root/'reported_results'/(fn.stem+'.json')).read_text(encoding='utf-8'))
  for got,want in zip(result['oracle_contrasts'],expected['oracle_contrasts']):
   assert got['comparison']==want['comparison'] and got['n']==want['n']
   for key in ['baseline_accuracy','guided_oracle','control_oracle_mean','difference','ci_level']:assert abs(got[key]-want[key])<1e-12,(fn.name,key)
   assert np.max(np.abs(np.asarray(got['ci'])-want['ci']))<1e-10,(fn.name,'CI',got['ci'],want['ci'])
  expected_direct={r['condition']:r for r in expected['direct_metrics']}
  for got in result['direct_metrics']:
   for key,value in got.items():
    if key!='condition':assert abs(value-expected_direct[got['condition']][key])<1e-12,(fn.name,key)
  if supplementary is not None:
   assert len(supplementary['sensitivity_contrasts'])==4 and len(supplementary['candidate_diversity'])==6
   for got,want in zip(result['sensitivity_contrasts'],supplementary['sensitivity_contrasts']):
    for key in ['guided','control','metric','n']:assert got[key]==want[key],(fn.name,key)
    assert abs(got['estimate']-want['estimate'])<1e-12 and np.max(np.abs(np.array(got['ci95'])-want['ci95']))<1e-10
   for got,want in zip(result['candidate_diversity'],supplementary['candidate_diversity']):
    for key,value in got.items():assert value==want[key],(fn.name,key)
  audit[fn.stem]={'status':'PASS','n':result['oracle_contrasts'][0]['n'],'predictions':raw_count,'raw_seal_to_reference_to_CSV_verified':True,'sensitivity_and_diversity_verified':supplementary is not None,'recalculated':result}
 historical=verify_historical(root)
 out={'status':'PASS','scope':'All released pilot and main answer records, candidate-count contrasts, bootstrap intervals and direct rescue/harm/flip counts','cohorts':audit,'historical_discovery':historical,'numpy_version':np.__version__}
 (root/'independent_reanalysis.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({'status':'PASS','cohorts':len(audit),'new_predictions':sum(v['predictions'] for v in audit.values()),'historical_predictions':historical.get('predictions_verified',0)},indent=2))
if __name__=='__main__':main()
