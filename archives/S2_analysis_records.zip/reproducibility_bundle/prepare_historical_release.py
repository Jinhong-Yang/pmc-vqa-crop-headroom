"""Preserve and independently verify the actual historical discovery data."""
import csv,json,hashlib,shutil,sys,collections
from pathlib import Path
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
OLD=R.parent/'single_tool_feasibility_20261017';SRC=Path('D:/Codex Research/MedVQA_SCIE_Local_20261016');O=R/'historical_release'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,rel):
 q=O/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);assert sha(q)==sha(p)
def main():
 inventory=load(R/'legacy_reuse/asset_inventory_and_reuse.json')
 for r in inventory['inputs']:assert sha(Path(r['path']))==r['sha256']
 seal=load(OLD/'prediction_seal.json');assert sha(OLD/'protocol_frozen.json')==seal['protocol_sha256']
 perqa=list(csv.DictReader((OLD/'per_qa_scored.csv').open(encoding='utf-8-sig',newline='')));assert len(perqa)==1350
 labels={split:{r['sample_id']:r for r in read(SRC/f'data/g2/frozen/references/{split.lower()}.jsonl')} for split in ['TRAIN','DEV_FIT']}
 table={(r['split'],r['sample_id']):r for r in perqa};records={};references=[];conditions=None
 for f in seal['files']:
  p=OLD/f['path'];assert sha(p)==f['sha256'];r=load(p);split=f['path'].replace('\\','/').split('/')[1].upper();sid=r['sample_id'];ref=labels[split][sid]['reference'];row=table[(split,sid)]
  assert r['group_id']==row['group_id'];conditions=conditions or set(r['scores']);assert set(r['scores'])==conditions and len(conditions)==16
  for c,v in r['scores'].items():assert float(row[c])==int(v['answer']==ref)
  for prefix in ['ROI_RANDOM','R_SHUFFLE']:assert abs(float(row[prefix+'_MEAN'])-np.mean([float(row[f'{prefix}_{s}']) for s in [1,7,42]]))<1e-12
  records[(split,sid)]=r;references.append({'split':split,'sample_id':sid,'group_id':row['group_id'],'reference':ref});copy(p,Path('predictions')/split.lower()/p.name)
 assert len(records)==1350
 O.mkdir(exist_ok=True);(O/'selected_references.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in references),encoding='utf-8')
 for n in ['per_qa_scored.csv','prediction_seal.json','protocol_frozen.json','collect_feasibility.py','score_feasibility.py','feasibility_common.py']:copy(OLD/n,n)
 copy(R.parent/'diagnostics_train_dev_20261017/qa_branch_outcomes.csv','historical_four_state_outcomes.csv')
 expected=load(R/'legacy_reuse/equal_cardinality_oracle_diagnostic.json');checks=[]
 for split in ['DEV_FIT','TRAIN']:
  rows=[r for r in perqa if r['split']==split];cols={c:np.array([float(r[c]) for r in rows]) for c in conditions};e=cols['E'];groups=np.array([r['group_id'] for r in rows]);unique,inv=np.unique(groups,return_inverse=True);sizes=np.bincount(inv)
  for name,guided,random in [('retrieval',['R_IQG'],[[f'R_SHUFFLE_{s}'] for s in [1,7,42]]),('roi',['ROI_HIGH'],[[f'ROI_RANDOM_{s}'] for s in [1,7,42]]),('two_tools',['R_IQG','ROI_HIGH'],[[f'R_SHUFFLE_{s}',f'ROI_RANDOM_{s}'] for s in [1,7,42]])]:
   a=np.maximum.reduce([e]+[cols[c] for c in guided]);b=sum(np.maximum.reduce([e]+[cols[c] for c in rr]) for rr in random)/3;diff=a-b;sums=np.bincount(inv,weights=diff);rng=np.random.default_rng(20261018);draws=rng.integers(0,len(unique),(5000,len(unique)));means=sums[draws].sum(1)/sizes[draws].sum(1);interval=np.quantile(means,[.025,.975]);want=next(x for x in expected if x['split']==split and x['comparison']==name)
   assert abs(diff.mean()-want['contrast'])<1e-12 and np.max(np.abs(interval-want['ci95']))<1e-10
   checks.append({'split':split,'comparison':name,'qa':len(rows),'groups':len(unique),'contrast':float(diff.mean()),'ci95':interval.tolist(),'status':'PASS'})
 branches=list(csv.DictReader((O/'historical_four_state_outcomes.csv').open(encoding='utf-8-sig',newline='')));pairs=[]
 for split in sorted({r['split'] for r in branches}):
  rows=[r for r in branches if r['split']==split];n=sum(int(float(r['ZR']))==1 and max(float(r[c]) for c in ['E','Z','R'])==0 for r in rows);wanted=next(x for x in inventory['headroom_recount'] if x['split']==split);assert n==wanted['unique_pair_gain'];pairs.append({'split':split,'qa':len(rows),'unique_pair_gain':n})
 out={'status':'PASS','role':'Retrospective discovery only; never pooled with fresh validation','actual_historical_QA':1350,'actual_historical_predictions_verified':1350*16,'retrospective_equal_candidate_contrasts':checks,'four_state_recount':pairs,'missing_early4B_raw_data':'Not available; report-only numbers are not reconstructed or counted as verified predictions.','files':{str(p.relative_to(O)).replace('\\','/'):sha(p) for p in O.rglob('*') if p.is_file() and p.name!='historical_data_audit.json'}}
 (O/'historical_data_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='files'},indent=2))
if __name__=='__main__':main()
