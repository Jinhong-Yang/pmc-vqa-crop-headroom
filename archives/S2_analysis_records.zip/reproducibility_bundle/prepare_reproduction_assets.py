"""Preserve the exact public retrieval bank and source acquisition provenance."""
from pathlib import Path
import json,hashlib,shutil,datetime,sys
R=Path(__file__).resolve().parent;SRC=Path('D:/Codex Research/MedVQA_SCIE_Local_20261016');O=R/'reproduction_assets'
sys.path.insert(0,str(R/'dependencies'))
import numpy as np
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,rel):
 q=O/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);assert sha(p)==sha(q)
def main():
 O.mkdir(exist_ok=True)
 bank=read(SRC/'data/g2/frozen/bank_retrieval.jsonl');manifest=load(SRC/'cache/g3_bank_v4_1/manifest.json')
 assert len(bank)==2000 and manifest['sample_ids']==[r['sample_id'] for r in bank]
 assert manifest['bank_sha256']==sha(SRC/'data/g2/frozen/bank_retrieval.jsonl')
 assert manifest['embedding_sha256']==sha(SRC/'cache/g3_bank_v4_1/embeddings.npy')
 arr=np.load(SRC/'cache/g3_bank_v4_1/embeddings.npy',allow_pickle=False);assert arr.shape==(2000,768) and arr.dtype==np.float32 and np.isfinite(arr).all()
 np.testing.assert_allclose(np.linalg.norm(arr,axis=1),1,atol=1e-5)
 meta=[r for r in read(SRC/'data/g2/frozen/split_manifest.jsonl') if r['split']=='BANK']
 assert {r['sample_id'] for r in meta}=={r['sample_id'] for r in bank}
 for rel in ['data/g2/frozen/bank_retrieval.jsonl','data/g2/frozen/references/bank.jsonl','cache/g3_bank_v4_1/manifest.json','cache/g3_bank_v4_1/embeddings.npy','configs/local_protocol.json','configs/experiment.lock.json']:
  copy(SRC/rel,Path('original_project')/rel)
 (O/'bank_source_metadata.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in meta),encoding='utf-8')
 allowed={'RadGenome/PMC-VQA','Qwen/Qwen3-VL-2B-Instruct','google/siglip2-base-patch16-224'}
 old=load(SRC/'evidence/acquisition_manifest.json');receipts=[x for x in old['files'] if x.get('repo') in allowed]
 assert all(x['integrity']=='PASS' for x in receipts)
 source=next(x for x in load(SRC/'evidence/source_snapshots.json') if x['repo']=='RadGenome/PMC-VQA')
 new=load(R/'models/Qwen3-VL-4B-Instruct/acquisition_receipt.json')
 catalog={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'historical_acquisition_checked_at':old['checked_at'],'dataset':{'repo':source['repo'],'revision':source['revision'],'page':'https://huggingface.co/datasets/RadGenome/PMC-VQA','publication':'https://doi.org/10.1038/s43856-024-00709-2','attribution':'Zhang X, Wu C, Zhao Z, et al. Development of a large-scale medical visual question-answering dataset. Communications Medicine. 2024;4:277.','qa_license':'CC BY-SA, version not specified in the archived dataset README','figure_licenses':'CC BY or CC0 according to the archived per-article OA metadata; retain per-figure attribution','source_files':source['tree']},'existing_acquisition_receipts':receipts,'new4B_acquisition_receipt':new,'curated_metadata_receipt':load(R/'clean_validation/acquisition_and_profile.json'),'model_licenses':{'Qwen/Qwen3-VL-2B-Instruct':'Apache-2.0','Qwen/Qwen3-VL-4B-Instruct':'Apache-2.0','google/siglip2-base-patch16-224':'Apache-2.0'},'scope':'Existing acquisition receipts retained as provenance; large archives and model weights are not downloaded or rehashed again by this reporting step.'}
 (O/'source_catalog.json').write_text(json.dumps(catalog,indent=2),encoding='utf-8')
 for src,dst in [(SRC/'data/raw/pmc/README.md','PMC_VQA_README.md'),(SRC/'models/Qwen3-VL-2B-Instruct/README.md','Qwen3_VL_2B_README.md'),(SRC/'models/siglip2-base-patch16-224/README.md','SigLIP2_README.md'),(R/'models/Qwen3-VL-4B-Instruct/README.md','Qwen3_VL_4B_README.md')]:copy(src,Path('source_cards')/dst)
 info={'status':'PASS','at':catalog['at'],'bank_examples':2000,'bank_connected_groups':len({r['group_id'] for r in meta}),'bank_image_embeddings_shape':list(arr.shape),'embedding_manifest_hash_verified':True,'bank_rows_and_metadata_ids_identical':True,'bank_role':'Fixed public retrieval evidence, not added to the query sample size','external_images_and_weights':'Not duplicated; exact URLs, revisions and recorded hashes in source_catalog.json','inference_portability':'Original scripts and assets preserve historical paths. Analysis reexecution is portable; inference setup requires adapting paths and acquiring pinned external models/images.','files':{str(p.relative_to(O)).replace('\\','/'):sha(p) for p in O.rglob('*') if p.is_file() and p.name!='asset_audit.json'}}
 (O/'asset_audit.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in info.items() if k!='files'},indent=2))
if __name__=='__main__':main()
