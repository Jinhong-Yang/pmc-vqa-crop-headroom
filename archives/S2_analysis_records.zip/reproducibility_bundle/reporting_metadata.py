"""Outcome-independent reporting metadata from already archived source citations."""
import csv,json,re,collections,hashlib,datetime
from pathlib import Path
R=Path(__file__).resolve().parent;SRC=Path('D:/Codex Research/MedVQA_SCIE_Local_20261016')
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
groups={}
for root in ['controlled_replication','curated_replication_2b']:
 for cohort in ['pilot','main']:groups[root+'/'+cohort]=read(R/root/cohort/'metadata.jsonl')
used={r['original_group_id'] for rows in groups.values() for r in rows};citations={}
source=SRC/'data/raw/pmc/oa_comm_use_file_list.csv'
with source.open(encoding='utf-8-sig',newline='') as f:
 for r in csv.DictReader(f):
  if r['Accession ID'] in used:citations[r['Accession ID']]=r
out={};year_records=[]
for name,rows in groups.items():
 years=[];missing=[];licensed=collections.Counter()
 for r in rows:
  cite=citations.get(r['original_group_id']);year=None
  if cite:
   match=re.search(r'\.\s*((?:19|20)\d{2})(?=\s+[A-Z][a-z]{2}\b|\s*;)',cite['Article Citation'])
   if match:year=int(match.group(1))
   licensed[cite['License']]+=1
  if year:years.append(year)
  else:missing.append(r['sample_id'])
  year_records.append({'cohort':name,'sample_id':r['sample_id'],'article':r['original_group_id'],'publication_year':year,'article_citation':cite['Article Citation'] if cite else ''})
 out[name]={'qa':len(rows),'article_year_min':min(years) if years else None,'article_year_max':max(years) if years else None,'year_counts':dict(sorted(collections.Counter(years).items())),'unresolved_article_years':missing,'figure_article_licences':dict(licensed)}
with (R/'article_year_records.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(year_records[0]));w.writeheader();w.writerows(year_records)
v={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':sha(source),'cohorts':out,'year_definition':'Year in the date position after the journal-ending period, followed by month or semicolon. Journal-title years and page numbers are not treated as dates. Missing dates remain missing. Not the text-creation date, image-acquisition date, clinical follow-up date or model pretraining cutoff.','parser_quality_note':'Initial first-year extraction caught journal-title1994 and page-number1987. Replaced before reporting with date-position parsing; no study eligibility or prediction changed.','model_training_end_date':'Not established from the acquired model cards; revision hashes are fixed.','model_card_sha256':sha(R/'models/Qwen3-VL-4B-Instruct/README.md'),'source_text_creation_dates':'Not available in acquired QA metadata; no dates imputed.','patient_demographic_fields':'Not available for this public figure QA benchmark; demographic fairness was not measured.','language_scope':'English prompt; source benchmark question and choice text preserved.','predictions_read':False}
(R/'reporting_metadata.json').write_text(json.dumps(v,indent=2),encoding='utf-8')
print(json.dumps({k:{'qa':x['qa'],'min_year':x['article_year_min'],'max_year':x['article_year_max'],'unresolved':len(x['unresolved_article_years'])} for k,x in out.items()},indent=2))
