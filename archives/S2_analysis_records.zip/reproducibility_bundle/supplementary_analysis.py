"""Already specified secondary contrasts, harm decomposition, and runtime summaries."""
import json,sys,hashlib,datetime
from pathlib import Path
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
import pandas as pd
from score_replication import ci
from audit_statistics import audit
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def analyze(folder):
 P=R/folder;seal=load(P/'prediction_seal.json');protocol=load(P.parent/'protocol_frozen.json');assert P.name=='main' and seal['qa']==protocol['design']['main']
 assert (P/'results.json').exists()
 audit(folder)
 d=pd.read_csv(P/'per_qa_scored.csv');e=d.E.to_numpy();rows=[];sub=[];runtime=[];sensitivity=[];diversity=[]
 # These conditions and sensitivity analyses were in the frozen protocol.
 # Exact contrast reporting was completed after primary2B outcomes were known.
 g=d.ROI_HIGH.to_numpy()
 for control in ['ROI_DUPLICATE','ROI_LOW']:
  c=d[control].to_numpy()
  for metric,arr in [('direct_accuracy',g-c),('two_candidate_oracle',np.maximum(e,g)-np.maximum(e,c))]:
   sensitivity.append({'guided':'ROI_HIGH','control':control,'metric':metric,'n':len(d),'estimate':float(arr.mean()),'ci95':ci(arr),'interpretation':'Exploratory sensitivity; no multiplicity adjustment, no change to primary inference'})
 for name,sets in [('crop_guided',[['E','ROI_HIGH']]),('crop_controls',[['E',f'ROI_RANDOM_{s}'] for s in [1,7,42]]),('retrieval_guided',[['E','R_IQG']]),('retrieval_controls',[['E',f'R_SHUFFLE_{s}'] for s in [1,7,42]]),('combined_guided',[['E','R_IQG','ROI_HIGH']]),('combined_controls',[['E',f'R_SHUFFLE_{s}',f'ROI_RANDOM_{s}'] for s in [1,7,42]])]:
  counts=np.array([d[[c+'_answer' for c in cols]].nunique(axis=1).to_numpy() for cols in sets]);k=len(sets[0])
  diversity.append({'candidate_set':name,'questions':len(d),'candidates_per_set':k,'seed_sets':len(sets),'mean_unique_answer_labels':float(counts.mean()),'fraction_by_unique_labels':{str(j):float((counts==j).mean()) for j in range(1,k+1)},'interpretation':'Descriptive answer-label diversity; average over separate equal-count sets, not union over control seeds or evidence of medical grounding'})
 for name,real,ctrl in [('crop','ROI_HIGH',[f'ROI_RANDOM_{s}' for s in [1,7,42]]),('retrieval','R_IQG',[f'R_SHUFFLE_{s}' for s in [1,7,42]])]:
  g=d[real].to_numpy();c=d[ctrl].mean(axis=1).to_numpy();rescue=(1-e)*(g-c);harm=e*((1-g)-(1-c))
  for label,arr in [('direct_vs_baseline',g-e),('direct_vs_control',g-c),('excess_rescue',rescue),('excess_harm',harm)]:
   rows.append({'tool':name,'contrast':label,'n':len(d),'estimate':float(arr.mean()),'ci95':ci(arr),'interpretation':'Exploratory secondary95% interval; no adjustment across this descriptive family'})
  np.testing.assert_allclose(g-c,rescue-harm)
  for kind,values in [('family',d.family),('native_size',np.where(d.native_long_edge>1024,'>1024',np.where(d.native_long_edge>512,'513-1024','<=512')))]:
   for value in sorted(set(values)):
    take=np.asarray(values)==value;n=int(take.sum());arr=rescue[take]
    sub.append({'tool':name,'stratum':kind,'value':value,'n':n,'excess_rescue':float(arr.mean()),'ci95':ci(arr) if n>=30 else None,'small_strata_no_interval':n<30,'status':'Exploratory; no subgroup-selected main claim'})
 for f in seal['files']:
  r=load(P/f['path']);runtime.append({'sample_id':r['sample_id'],'bundle_s':r['bundle_s'],**r['times_s']})
 rt=pd.DataFrame(runtime);duration=[]
 for c in rt.columns[1:]:duration.append({'condition':c,'median_seconds':float(rt[c].median()),'p95_seconds':float(rt[c].quantile(.95)),'n':int(rt[c].count())})
 out={'cohort':folder,'n':len(d),'secondary_contrasts':rows,'sensitivity_contrasts':sensitivity,'candidate_diversity':diversity,'subgroups':sub,'costs':duration,'decomposition':'guided-control direct accuracy = excess rescue - excess harm; oracle contrast equals excess rescue','not_a_new_estimator':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (P/'supplementary_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
 pd.DataFrame(rows).to_csv(P/'supplementary_contrasts.csv',index=False);pd.DataFrame(sub).to_csv(P/'exploratory_subgroups.csv',index=False);pd.DataFrame(duration).to_csv(P/'runtime_summary.csv',index=False)
 return out
if __name__=='__main__':
 for f in ['controlled_replication/main','controlled_replication_4b/main','curated_replication_2b/main','curated_replication_4b/main']:
  v=analyze(f);print(f,'COMPLETE',v['n'])
