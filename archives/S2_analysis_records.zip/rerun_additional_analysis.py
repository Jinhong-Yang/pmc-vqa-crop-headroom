"""Exploratory analyses of existing sealed predictions; no new model inference."""
from pathlib import Path
import json,sys,hashlib,datetime,shutil
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
from scipy.stats import bootstrap
O=R/'rerun_exploratory';O.mkdir(exist_ok=True)
defs=[('controlled_replication','Primary/2B'),('controlled_replication_4b','Primary/4B'),('curated_replication_2b','Curated/2B'),('curated_replication_4b','Curated/4B')]
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def jl(p):return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines()]
def stat(x,seed=20261018):
 x=np.asarray(x,float);u,ct=np.unique(x,return_counts=True);rng=np.random.default_rng(seed)
 vals=rng.multinomial(len(x),ct/ct.sum(),size=20000)@u/len(x)
 return {'n':len(x),'estimate':float(x.mean()),'ci95':np.quantile(vals,[.025,.975]).tolist()}
def iou(a,b):
 inter=max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))
 return inter/((a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-inter)
def aggregate(prob,policy):
 if policy=='mean_probability':return prob.mean(axis=1).argmax(axis=1)
 if policy=='max_confidence':j=prob.max(axis=2).argmax(axis=1)
 else:j=(-np.sum(prob*np.log(np.maximum(prob,1e-30)),axis=2)).argmin(axis=1)
 return prob[np.arange(len(prob)),j].argmax(axis=1)
bank={x['sample_id']:x['group_id'] for x in jl(R/'reproducibility_bundle/reproduction_assets/original_project/data/g2/frozen/references/bank.jsonl')}
results={};provenance={}
for folder,label in defs:
 P=R/'reproducibility_bundle/run_evidence'/(folder+'__main');seal=load(P/'prediction_seal.json');refs={x['sample_id']:'ABCD'.index(x['reference']) for x in jl(P/'references.jsonl')}
 rows=[]
 for f in seal['files']:
  p=R/'reproducibility_bundle/raw_predictions'/(folder+'__main')/f['path'].replace('\\','/').split('/')[-1];assert sha(p)==f['sha256'];rows.append(load(p))
 n=len(rows);y=np.array([refs[x['sample_id']] for x in rows]);names=list(rows[0]['scores']);prob={c:np.array([x['scores'][c]['option_probs'] for x in rows]) for c in names};ans={c:p.argmax(1) for c,p in prob.items()};cor={c:(a==y).astype(float) for c,a in ans.items()};e=cor['E'];g=cor['ROI_HIGH'];d=cor['ROI_DUPLICATE'];cs=[f'ROI_RANDOM_{s}' for s in [1,7,42]]
 flips=[]
 for c in names:
  changed=ans[c]!=ans['E'];wrong=e==0;right=e==1;resc=wrong&(cor[c]==1)
  flips.append({'condition':c,'baseline_wrong':int(wrong.sum()),'baseline_correct':int(right.sum()),'flips_from_wrong':int((wrong&changed).sum()),'rescues':int(resc.sum()),'p_correct_given_wrong_flip':float(resc.sum()/(wrong&changed).sum()) if (wrong&changed).sum() else None,'flips_from_correct':int((right&changed).sum()),'p_flip_from_correct':float((right&changed).sum()/right.sum())})
 rg=(1-e)*g;rd=(1-e)*d
 duplicate={'guided_rescues':int(rg.sum()),'duplicate_rescues':int(rd.sum()),'count_ratio':float(rd.sum()/rg.sum()),'intersection_rescues':int(((rg==1)&(rd==1)).sum()),'guided_rescues_also_rescued_by_duplicate_fraction':float(((rg==1)&(rd==1)).sum()/rg.sum()),'duplicate_headroom':float(rd.mean()),'guided_headroom':float(rg.mean()),'duplicate_direct_minus_baseline':stat(d-e)}
 overlap=np.array([[iou(x['observations']['roi']['boxes'][x['observations']['roi']['chosen']],x['observations']['roi']['boxes'][x['observations']['roi']['random_indices'][str(s)]]) for s in [1,7,42]] for x in rows])
 mask=overlap==0;eligible=mask.any(axis=1);control=np.stack([cor[c] for c in cs],1);dc=(g[:,None]*(1-e[:,None])-control*(1-e[:,None]));sub=np.array([dc[i,mask[i]].mean() for i in np.flatnonzero(eligible)])
 overlap_summary={'selected_window_counts':np.bincount([x['observations']['roi']['chosen'] for x in rows],minlength=9).tolist(),'iou_mean':float(overlap.mean()),'iou_quantiles':np.quantile(overlap,[0,.25,.5,.75,1]).tolist(),'zero_overlap_pairs':int(mask.sum()),'pairs':n*3,'eligible_questions':int(eligible.sum()),'nonoverlap_oracle_contrast':stat(sub),'distinct_control_windows_counts':{str(k):sum(len(set(x['observations']['roi']['random_indices'].values()))==k for x in rows) for k in [1,2,3]}}
 trunc=np.array([x['observations']['query_tokens']['retrieval_raw']>64 for x in rows]);dup=np.array([len(set(bank[s] for s in x['observations']['R_IQG']['neighbor_ids']))<len(x['observations']['R_IQG']['neighbor_ids']) for x in rows]);fallback=sum(x['observations']['family']['random_pool_fallback'] for x in rows)
 retrieval=[]
 for filtername,keep in [('not_truncated',~trunc),('distinct_guided_bank_groups',~dup),('both',~trunc&~dup)]:
  for kind,gg,ctrl in [('retrieval',np.maximum(e,cor['R_IQG']),np.mean([np.maximum(e,cor[f'R_SHUFFLE_{s}']) for s in [1,7,42]],axis=0)),('combined',np.maximum.reduce([e,cor['R_IQG'],g]),np.mean([np.maximum.reduce([e,cor[f'R_SHUFFLE_{s}'],cor[f'ROI_RANDOM_{s}']]) for s in [1,7,42]],axis=0))]:
   retrieval.append({'filter':filtername,'contrast':kind,**stat((gg-ctrl)[keep])})
 selectors=[]
 for family in ['crop','retrieval','combined']:
  guided=['E']+({'crop':['ROI_HIGH'],'retrieval':['R_IQG'],'combined':['R_IQG','ROI_HIGH']}[family])
  controls=[['E']+({'crop':[f'ROI_RANDOM_{s}'],'retrieval':[f'R_SHUFFLE_{s}'],'combined':[f'R_SHUFFLE_{s}',f'ROI_RANDOM_{s}']}[family]) for s in [1,7,42]]
  for policy in ['max_confidence','minimum_entropy','mean_probability']:
   ga=(aggregate(np.stack([prob[c] for c in guided],1),policy)==y).astype(float)
   ca=np.mean([(aggregate(np.stack([prob[c] for c in cc],1),policy)==y) for cc in controls],axis=0)
   selectors.append({'family':family,'policy':policy,'guided_accuracy':float(ga.mean()),'control_accuracy':float(ca.mean()),'guided_minus_control':stat(ga-ca),'guided_minus_baseline':stat(ga-e),'control_minus_baseline':stat(ca-e)})
 contrast=(1-e)*(g-control.mean(1));bca=bootstrap((contrast,),np.mean,n_resamples=20000,method='BCa',random_state=np.random.default_rng(20261018),batch=200)
 values=load(R/'reproducibility_bundle/reported_results'/(folder+'__main.json'));r=next(x for x in values['oracle_contrasts'] if x['comparison']=='roi')
 margin={'planning_margin_relative_to_guided_headroom':.02/rg.mean(),'minimum_symmetric_margin_covering_original_ci':max(abs(v) for v in r['ci']),'interval_within_margin':{str(m):bool(r['ci'][0]>-m and r['ci'][1]<m) for m in [.005,.01,.015,.02]},'BCa_ci95':[float(bca.confidence_interval.low),float(bca.confidence_interval.high)]}
 results[label]={'n':n,'flip_diagnostics':flips,'duplicate_view':duplicate,'crop_overlap':overlap_summary,'retrieval_exclusions':retrieval,'retrieval_fallback_questions':int(fallback),'selectors':selectors,'margin_context':margin,'oracle_positive_points':sum(x['difference']>0 for x in values['oracle_contrasts'])}
 provenance[label]={'seal_sha256':sha(P/'prediction_seal.json'),'references_sha256':sha(P/'references.jsonl')}
 print(label,json.dumps({'ratio':duplicate['count_ratio'],'same_rescue_fraction':duplicate['guided_rescues_also_rescued_by_duplicate_fraction'],'nonoverlap':overlap_summary['nonoverlap_oracle_contrast'],'bca':margin['BCa_ci95'],'fallback':fallback}))
payload={'status':'COMPUTED_PENDING_INDEPENDENT_CHECK','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'analysis_class':'Exploratory; specified after all main outcomes were known. Original confirmatory analyses unchanged.','bootstrap':'20000 paired question resamples; percentile95% for new exploratory contrasts; BCa95% for original crop contrast. Fixed seed20261018. No multiplicity adjustment.','selector_rules':'No fitting or tuning. Max confidence and min entropy choose among computed candidate responses; ties favour baseline then listed intervention. Mean probability averages four-label distributions then argmax with A-first ties. All candidate inference costs are incurred.','nonoverlap_rule':'Keep questions with at least one measured seed control of IoU zero; average eligible seeds within question, then average questions. Excludes others; different target population.','duplicate_ratio_interpretation':'Ratio of aggregate rescue counts, not fraction of same questions or causal fraction of headroom. Intersection separately reported.','sources':provenance,'runs':results}
(O/'additional_results.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
print('Saved',O/'additional_results.json')
