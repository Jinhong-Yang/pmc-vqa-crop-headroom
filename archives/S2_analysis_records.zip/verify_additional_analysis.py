"""Independent point checks from released CSVs, plus case-resampling CI checks."""
from pathlib import Path
import csv,json,math,sys,hashlib
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'dependencies'));import numpy as np
O=R/'rerun_exploratory';p=O/'additional_results.json';v=json.loads(p.read_text())
defs=[('controlled_replication','Primary/2B'),('controlled_replication_4b','Primary/4B'),('curated_replication_2b','Curated/2B'),('curated_replication_4b','Curated/4B')]
checks=[]
def near(a,b):assert abs(a-b)<1e-12,(a,b)
for folder,label in defs:
 records={}
 with (R/'reproducibility_bundle/answer_records'/(folder+'__main.csv')).open(encoding='utf-8') as f:
  for x in csv.DictReader(f):records.setdefault(x['sample_id'],{})[x['condition']]=x
 z=v['runs'][label];assert len(records)==z['n']
 for d in z['flip_diagnostics']:
  bad=good=wf=resc=harm=0
  for r in records.values():
   baseline=r['E'];q=r[d['condition']];correct=baseline['answer']==baseline['reference'];flip=q['answer']!=baseline['answer']
   bad+=not correct;good+=correct;wf+=(not correct and flip);resc+=(not correct and q['answer']==q['reference']);harm+=(correct and flip)
  assert (bad,good,wf,resc,harm)==tuple(d[k] for k in ['baseline_wrong','baseline_correct','flips_from_wrong','rescues','flips_from_correct'])
  if wf:near(resc/wf,d['p_correct_given_wrong_flip'])
  near(harm/good,d['p_flip_from_correct'])
 for d in z['selectors']:
  sets={'crop':['ROI_HIGH'],'retrieval':['R_IQG'],'combined':['R_IQG','ROI_HIGH']}
  guid=['E']+sets[d['family']];controls=[['E']+[c.replace('ROI_HIGH',f'ROI_RANDOM_{s}').replace('R_IQG',f'R_SHUFFLE_{s}') for c in sets[d['family']]] for s in [1,7,42]]
  def choose(r,cs):
   probs=[[float(r[c]['probability_'+a]) for a in 'ABCD'] for c in cs]
   if d['policy']=='mean_probability':out=[sum(pr[j] for pr in probs)/len(probs) for j in range(4)]
   else:
    score=[max(pr) if d['policy']=='max_confidence' else sum(q*math.log(q) for q in pr if q) for pr in probs]
    out=probs[max(range(len(score)),key=score.__getitem__)]
   return 'ABCD'[max(range(4),key=out.__getitem__)]
  gg=[];cc=[];ee=[]
  for r in records.values():
   ref=r['E']['reference'];gg.append(choose(r,guid)==ref);cc.append(sum(choose(r,c)==ref for c in controls)/3);ee.append(r['E']['answer']==ref)
  near(sum(gg)/len(gg),d['guided_accuracy']);near(sum(cc)/len(cc),d['control_accuracy']);near(np.mean(np.array(gg)-cc),d['guided_minus_control']['estimate'])
  near(np.mean(np.array(gg,dtype=float)-ee),d['guided_minus_baseline']['estimate'])
  if d['family']=='crop' and d['policy']=='max_confidence':
   delta=np.array(gg)-cc;rng=np.random.default_rng(419);boot=[]
   for _ in range(100):boot.extend(delta[rng.integers(0,len(delta),(200,len(delta)))].mean(1))
   bounds=np.quantile(boot,[.025,.975]);error=float(np.max(np.abs(bounds-d['guided_minus_control']['ci95'])))
   assert error<.0015,(label,error)
 checks.append({'run':label,'all_11_flip_diagnostics':'PASS','all_9_selector_points':'PASS','max_confidence_crop_CI_independent_case_resampling_max_deviation_pp':error*100})
v['status']='VERIFIED';p.write_text(json.dumps(v,indent=2),encoding='utf-8')
receipt={'status':'PASS','scope':'All flip counts and all36 selector estimates independently calculated from released CSVs; four selected bootstrap intervals checked with independent case-resampling. Other exploratory CIs generated from paired discrete resampling, not independently replicated here.','checks':checks,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(O/'additional_analysis_verification.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt,indent=2))
