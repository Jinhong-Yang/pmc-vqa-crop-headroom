"""Outcome-blind local single-tool inference; no scoring imports or label joins."""
from feasibility_common import *
from g3_collect import FrozenTrial
from run_pilot import Monitor,image,GIB
from transformers import AutoTokenizer,SiglipTextModel
from transformers.utils import logging
from PIL import Image
logging.set_verbosity_error()

def resize(im,edge):
 w,h=im.size;f=edge/max(w,h)
 return im.resize((max(1,round(w*f)),max(1,round(h*f))),Image.Resampling.LANCZOS)
def norm(v):return torch.nn.functional.normalize(v.float(),dim=-1)
def ranks(v,ids):
 order=sorted(range(len(v)),key=lambda j:(-float(v[j]),ids[j]));out=np.empty(len(v),int);out[order]=np.arange(1,len(v)+1);return out
def query_text(x):return x['question']+' Choices: '+'; '.join(x['options'])

class Experiment(FrozenTrial):
 def __init__(self):
  super().__init__();self.encoder.to('cuda');self.encoder.requires_grad_(False)
  self.tm=SiglipTextModel.from_pretrained(PROJECT/'models/siglip2-base-patch16-224',local_files_only=True,dtype=torch.float32).to('cuda').eval();self.tm.requires_grad_(False)
  self.tok=AutoTokenizer.from_pretrained(PROJECT/'models/siglip2-base-patch16-224',local_files_only=True)
  self.bids=[r['sample_id'] for r in self.bank];self.bvec=self.vectors.to('cuda')
  self.btext=self.embed_text([query_text(r) for r in self.bank]);self.templates=self.embed_text(list(FAMILIES.values()))
  self.bfamily=torch.softmax((self.bvec@self.templates.T)/.07,-1).cpu().numpy()
  self.bg=groups_only('BANK');self.family_names=list(FAMILIES)
  np.savez_compressed(OUT/'bank_text_family_features.npz',text=self.btext.cpu().numpy(),family=self.bfamily,templates=self.templates.cpu().numpy(),sample_ids=self.bids)
 @torch.inference_mode()
 def embed_text(self,texts):
  vs=[]
  for i in range(0,len(texts),32):
   b=self.tok(texts[i:i+32],padding='max_length',truncation=True,max_length=64,return_tensors='pt').to('cuda')
   vs.append(norm(self.tm(**{k:v for k,v in b.items() if k in ('input_ids','attention_mask')}).pooler_output))
  return torch.cat(vs)
 @torch.inference_mode()
 def embed_image(self,ims):
  return norm(self.encoder(**self.ip(images=ims,return_tensors='pt').to('cuda')).pooler_output)
 def evidence(self,idx,similarity,no_answer=False):
  texts=[];kept=[]
  for j in idx[:3]:
   r=self.bank[j];t=f'Neighbor {len(texts)+1} (cosine {float(similarity[j]):.6f}): Question: '+r['question']+' Choices: '+'; '.join(r['options'])
   if not no_answer:t+=' Neighbor answer text: '+r['answer_text']
   texts.append(t);kept.append(j)
  while texts and len(self.proc.tokenizer.encode('\n'.join(texts),add_special_tokens=False))>512:texts.pop();kept.pop()
  return texts,dict(neighbor_ids=[self.bids[j] for j in kept],kept=len(kept),tokens=len(self.proc.tokenizer.encode('\n'.join(texts),add_special_tokens=False)))
 @torch.inference_mode()
 def new_observations(self,x):
  full=image(x['image_path'],10**9);base=full.copy();base.thumbnail((512,512),Image.Resampling.LANCZOS)
  v=self.embed_image([base]);qt=self.embed_text([query_text(x),'Medical image region relevant to the question: '+x['question']])
  si=(v@self.bvec.T)[0].cpu().numpy();sq=(qt[:1]@self.btext.T)[0].cpu().numpy()
  fam=torch.softmax((v@self.templates.T)/.07,-1)[0].cpu().numpy();sf=self.bfamily@fam
  ri,rq,rf=[ranks(a,self.bids) for a in (si,sq,sf)]
  iq=1/(60+ri)+1/(60+rq);iqg=iq+.5/(60+rf)
  indexes={n:sorted(range(len(s)),key=lambda j:(-float(s[j]),self.bids[j]))[:3] for n,s in [('R_Q',sq),('R_IQ',iq),('R_IQG',iqg)]}
  predicted=int(fam.argmax());pool=np.flatnonzero(self.bfamily.argmax(1)==predicted).tolist();fallback=len({self.bg[self.bids[j]] for j in pool})<3
  if fallback:pool=list(range(len(self.bank)))
  for seed in SEEDS:
   order=sorted(pool,key=lambda j:stable(f"{x['sample_id']}|retrieval|{seed}|{self.bids[j]}"));taken=[];seen=set()
   for j in order:
    if self.bg[self.bids[j]] not in seen:taken.append(j);seen.add(self.bg[self.bids[j]])
    if len(taken)==3:break
   assert len(taken)==3;indexes[f'R_SHUFFLE_{seed}']=taken
  retrieved={};meta={}
  for name,idx in indexes.items():retrieved[name],meta[name]=self.evidence(idx,si)
  main_kept=[self.bids.index(sid) for sid in meta['R_IQG']['neighbor_ids']]
  retrieved['R_IQG_NO_ANSWER'],meta['R_IQG_NO_ANSWER']=self.evidence(main_kept,si,True)
  w,h=full.size;boxes=[]
  for y in (0,.25,.5):
   for z in (0,.25,.5):
    left=round(z*w);top=round(y*h);boxes.append((left,top,left+max(1,w//2),top+max(1,h//2)))
  crops=[full.crop(b) for b in boxes];cv=self.embed_image(crops);scores=(cv@qt[1:2].T)[:,0].cpu().numpy();chosen=min(range(9),key=lambda j:(-float(scores[j]),j))
  randoms={s:min([j for j in range(9) if j!=chosen],key=lambda j:stable(f"{x['sample_id']}|roi|{s}|{j}")) for s in SEEDS}
  target=resize(full,512).size
  high=crops[chosen].resize(target,Image.Resampling.LANCZOS);low=resize(crops[chosen],256).resize(target,Image.Resampling.LANCZOS)
  direct={'ROI_HIGH':high,'ROI_LOW':low,'ROI_DUPLICATE':resize(full,512)}
  direct.update({f'ROI_RANDOM_{s}':crops[j].resize(target,Image.Resampling.LANCZOS) for s,j in randoms.items()})
  meta['family']=dict(predicted=self.family_names[predicted],probabilities=fam.tolist(),random_pool=len(pool),random_pool_fallback=fallback)
  meta['roi']=dict(full_size=[w,h],boxes=boxes,scores=scores.tolist(),chosen=chosen,random_indices=randoms,native_selected_size=list(crops[chosen].size),rendered_size=list(high.size),native_gt512=max(w,h)>512,native_gt1024=max(w,h)>1024)
  meta['query_tokens']=dict(retrieval_raw=len(self.tok.encode(query_text(x))),roi_raw=len(self.tok.encode('Medical image region relevant to the question: '+x['question'])),truncated_to=64)
  return base,retrieved,direct,meta

def main():
 torch.set_num_threads(8);torch.set_num_interop_threads(2);torch.manual_seed(20261016);np.random.seed(20261016)
 plan=freeze();assert not (OUT/'prediction_seal.json').exists(),'Completed predictions already sealed; do not overwrite'
 progress('G5_PRESERVATION_BEFORE');dump('preservation_before.json',preserve())
 xs,gg,bg=selected_inputs();assert not (PROJECT/'runs/gpu.lock').exists(),'Another heavy GPU job is active'
 lock=OUT/'gpu.lock'
 with lock.open('x',encoding='utf-8') as f:json.dump(dict(pid=os.getpid(),at_kst=now()),f)
 monitor=Monitor();monitor.start();t=time.perf_counter();records=[];reproduced=0;timings=[]
 try:
  exp=Experiment();progress('MODELS_READY',bank=len(exp.bank),conditions=len(CONDITIONS))
  dump('feature_binding.json',dict(bank_features_sha256=sha(OUT/'bank_text_family_features.npz'),frozen_bank_image_manifest_sha256=sha(PROJECT/'cache/g3_bank_v4_1/manifest.json'),protocol_sha256=sha(OUT/'protocol_frozen.json')))
  for split in ('TRAIN','DEV_FIT'):
   for i,x in enumerate(xs[split]):
    sid=x['sample_id'];rel=Path('predictions')/split.lower()/(sid+'.json');p=OUT/rel
    if p.exists():
     rec=load(p);assert rec['protocol_sha256']==sha(OUT/'protocol_frozen.json');records.append(dict(path=rel.as_posix(),sha256=sha(p)));continue
    ts=time.perf_counter();base,ret,direct,meta=exp.new_observations(x);old=load(PROJECT/f'runs/g3/{split.lower()}/{sid}.json')
    scores={n:dict(old['states'][s],cache_reused=True) for n,s in [('E','E'),('OLD_Z','Z'),('R_IMAGE','R')]};errors=[];times={}
    if i<10:
     for name,z,rr in [('E','',[]),('R_IMAGE','',[f'Neighbor {k+1} (cosine {val:.6f}): Question: '+exp.bank[exp.bids.index(bid)]['question']+' Choices: '+'; '.join(exp.bank[exp.bids.index(bid)]['options'])+' Neighbor answer text: '+exp.bank[exp.bids.index(bid)]['answer_text'] for k,(bid,val) in enumerate(zip(old['retrieval']['neighbor_ids'],old['retrieval']['cosine']))])]:
      while True:
       try:out,_=exp.score(base,exp.prompt(x,z,rr));break
       except ValueError:
        if not rr:raise
        rr.pop()
      assert out['answer']==scores[name]['answer'];np.testing.assert_allclose(out['option_probs'],scores[name]['option_probs'],atol=1e-5,rtol=1e-5);reproduced+=1
    for name in CONDITIONS[3:]:
     tick=time.perf_counter();ims=[base,direct[name]] if name.startswith('ROI_') else base
     rr=list(ret.get(name,[]));text=exp.prompt(x,neighbors=rr)
     if name.startswith('ROI_'):
      text='The first image is the global view. The second image is an additional view of the same figure; it may or may not contain useful detail.\n'+text
     def fn():
      nonlocal text
      while True:
       try:out,_=exp.score(ims,text);return dict(out,status='ok',cache_reused=False,retrieval_neighbors_used=len(rr))
       except ValueError:
        if not rr:raise
        rr.pop();text=exp.prompt(x,neighbors=rr)
     out=exp.attempt(name,fn,errors,times)
     scores[name]=out if out is not None else dict(scores['E'],status='failed_fallback_E',cache_reused=False)
     times[name]=time.perf_counter()-tick
    torch.cuda.synchronize()
    for k in ('ROI_LOW','ROI_RANDOM_1','ROI_RANDOM_7','ROI_RANDOM_42','ROI_DUPLICATE'):
     if scores[k]['status']=='ok' and scores['ROI_HIGH']['status']=='ok':assert scores[k]['image_tokens']==scores['ROI_HIGH']['image_tokens'],(sid,k,'unmatched ROI image-token budget')
    rec=dict(split=split,sample_id=sid,group_id=gg[split][sid],protocol_sha256=sha(OUT/'protocol_frozen.json'),input_sha256=hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest(),old_cache_sha256=sha(PROJECT/f'runs/g3/{split.lower()}/{sid}.json'),scores=scores,observations=meta,errors=errors,times_s=times,bundle_s=time.perf_counter()-ts)
    dump(rel,rec);records.append(dict(path=rel.as_posix(),sha256=sha(p)));timings.append(rec['bundle_s'])
    assert torch.cuda.max_memory_reserved()/GIB<=12 and monitor.free/GIB>=2 and (monitor.rss-monitor.base_rss)/GIB<=24,'Resource gate breach'
    if (i+1)%10==0:progress('INFERENCE',split=split,qa=i+1,total=len(xs[split]),overall=len(records),wall_s=time.perf_counter()-t)
  dump('prediction_seal.json',dict(status='SEALED_BEFORE_SCORING',files=records,qa=len(records),predictions=len(records)*len(CONDITIONS),protocol_sha256=sha(OUT/'protocol_frozen.json'),baseline_reproductions=reproduced,at_kst=now()))
  dump('inference_complete.json',dict(status='PASS',qa=len(records),predictions=len(records)*len(CONDITIONS),new_method_predictions=len(records)*(len(CONDITIONS)-3),cached_method_predictions=len(records)*3,baseline_reproductions=reproduced,wall_s=time.perf_counter()-t,median_qa_s=float(np.median(timings)),p95_qa_s=float(np.percentile(timings,95)),peak_reserved_gib=torch.cuda.max_memory_reserved()/GIB,min_free_vram_gib=monitor.free/GIB,incremental_rss_gib=(monitor.rss-monitor.base_rss)/GIB,no_query_labels_in_model_inputs=True,no_test_or_dev_lock_analysis=True,at_kst=now()))
  progress('PREDICTIONS_SEALED',qa=len(records),predictions=len(records)*len(CONDITIONS))
 finally:
  monitor.stop();lock.unlink(missing_ok=True)

if __name__=='__main__':main()
