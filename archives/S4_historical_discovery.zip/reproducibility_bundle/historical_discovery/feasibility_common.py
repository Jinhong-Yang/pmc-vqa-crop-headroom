"""Post-G5 single-tool feasibility. Original project is strictly read-only."""
import os
os.environ.setdefault('HF_HUB_OFFLINE','1')
os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
os.environ.setdefault('OMP_NUM_THREADS','8')
import sys,json,hashlib,csv,time
from pathlib import Path
import numpy as np
import torch
PROJECT=Path('D:/Codex Research/MedVQA_SCIE_Local_20261016')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(PROJECT/'scripts'))
from g3_common import sha,load,read,now
from g2_inputs import load_inputs
SEEDS=(1,7,42)
CONDITIONS=('E','OLD_Z','R_IMAGE','R_Q','R_IQ','R_IQG','R_IQG_NO_ANSWER',
            'R_SHUFFLE_1','R_SHUFFLE_7','R_SHUFFLE_42','ROI_HIGH','ROI_LOW',
            'ROI_RANDOM_1','ROI_RANDOM_7','ROI_RANDOM_42','ROI_DUPLICATE')
FAMILIES={
 'RADIOLOGY':'A radiology image, such as X-ray, CT, MRI or ultrasound.',
 'HISTOLOGY':'A histopathology tissue slide under a microscope.',
 'MICROSCOPY':'A microscopy, cell culture or electron microscopy image.',
 'CLINICAL':'A clinical photograph of skin, tissue, wound or body.',
 'OPHTHALMIC':'An ophthalmology image, fundus photograph or retinal OCT.',
 'PLOT':'A scientific plot, graph, chart or quantitative result.',
 'DIAGRAM':'A scientific diagram, schematic drawing or flowchart.',
 'OTHER':'A photograph of laboratory equipment, gels or other scientific figures.'}
PRIMARY=(('R_IQG','E'),('R_IQG','R_SHUFFLE_MEAN'),('R_IQG','R_IMAGE'),
         ('ROI_HIGH','E'),('ROI_HIGH','ROI_RANDOM_MEAN'),('ROI_HIGH','ROI_LOW'))

def dump(name,obj):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
 tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');tmp.replace(p)
def csvout(name,rows):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def stable(s):return hashlib.sha256(('single-tool-feasibility-20261017|'+s).encode()).hexdigest()
def progress(stage,**kw):
 v=dict(stage=stage,**kw,at_kst=now());dump('progress.json',v);print(json.dumps(v,ensure_ascii=False),flush=True)
def preserve():
 m=PROJECT/'evidence/g5/artifact_manifest.json';a=load(m)['artifacts']
 for x in a:assert sha(PROJECT/x['path'])==x['sha256'],x['path']
 return dict(status='PASS',g5_artifacts_verified=len(a),g5_manifest_sha256=sha(m),
  g5_completion_sha256=sha(PROJECT/'evidence/g5/completion.json'),
  g4_final_lock_sha256=sha(PROJECT/'configs/final_evaluation.lock.json'))
def groups_only(split):
 assert split in ('BANK','TRAIN','DEV_FIT')
 # This metadata projection is the only reference access in the collector.
 return {r['sample_id']:r['group_id'] for r in read(PROJECT/f'data/g2/frozen/references/{split.lower()}.jsonl')}
def selected_inputs():
 result={};groups={}
 for split in ('TRAIN','DEV_FIT'):
  xs=load_inputs(split);gg=groups_only(split);groups[split]=gg
  if split=='TRAIN':
   by={}
   for x in xs:
    g=gg[x['sample_id']]
    if g not in by or stable(x['sample_id'])<stable(by[g]['sample_id']):by[g]=x
   xs=sorted(by.values(),key=lambda x:stable(x['sample_id']))[:600]
  result[split]=xs
 assert len(result['TRAIN'])==600 and len(result['DEV_FIT'])==750
 assert not set(groups['TRAIN'].values())&set(groups['DEV_FIT'].values())
 bg=groups_only('BANK')
 assert not set(bg.values())&(set(groups['TRAIN'].values())|set(groups['DEV_FIT'].values()))
 return result,groups,bg
def freeze():
 xs,gg,bg=selected_inputs()
 code={p.name:sha(p) for p in sorted(OUT.glob('*.py')) if p.name in ('feasibility_common.py','collect_feasibility.py','score_feasibility.py')}
 plan=dict(status='FROZEN_BEFORE_NEW_TOOL_PREDICTIONS',at_kst=now(),
  purpose='단일 도구의 실제 추가 정보가 순이득을 만드는지 확인하고 후속 저널 연구 투자 여부를 결정한다.',
  scope=['TRAIN 600 QA / 600 connected groups, label-blind stable-hash sample','DEV_FIT all 750 QA / 586 connected groups','BANK 2000 frozen examples; group-disjoint'],
  forbidden=['DEV_LOCK analysis','TEST_ID analysis','TEST_SOURCE analysis','G5 mutation','post-DEV tuning'],
  prior_knowledge='Post-G5 follow-up informed by completed TRAIN/DEV diagnosis. DEV_FIT is reused, not an independent confirmatory cohort.',
  selection='Fixed recipes, no hyperparameter grid or outcome-based selection. Both tools and all ablations reported. TRAIN and DEV new predictions sealed together before scoring.',
  selected_ids={s:[x['sample_id'] for x in v] for s,v in xs.items()},
  model=dict(name='Qwen3-VL-2B-Instruct',revision='89644892e4d85e24eaac8bacfd4f463576704203',dtype='BF16',scoring='frozen final-position A/B/C/D conditional log probabilities',sampling=False,base_long_edge=512,max_context=3072),
  encoder=dict(name='google/siglip2-base-patch16-224',revision='75de2d55ec2d0b4efc50b3e9ad70dba96a7b2fa2',dtype='FP32',text_max_tokens=64,text_padding='max_length',normalized=True),
  retrieval=dict(query='question + option text; no query reference; bank question + options only for ranking',
   image='frozen normalized bank image vectors and query image vector',question='cosine between frozen SigLIP text embeddings',
   family='zero-shot image-to-template cosine, softmax temperature 0.07; group affinity = probability-vector dot product; no ground-truth modality labels',families=FAMILIES,
   fusion='reciprocal-rank fusion k=60, image:question:family weights 1:1:0.5; IQ ablation 1:1:0; Q text-only; deterministic sample-id ties',
   evidence='top 3 bank examples formatted using frozen question/options/answer-text template; drop trailing examples until <=512 Qwen tokens; no neighbor letter transfer',
   controls='3 stable-hash random BANK sets matched to query predicted family; fallback entire bank if <3; distinct bank connected groups within each set; no-answer ablation shares main neighbors',
   seeds=list(SEEDS)),
  roi=dict(candidates='9 half-width/half-height windows at fractional left/top 0,0.25,0.5; question-guided SigLIP crop-image/text cosine; stable candidate-index ties',
   query='Medical image region relevant to the question: + question; no options/reference',
   direct_input='original image long edge 512 followed by selected original-resolution crop resampled to long edge 512; identical extra-image prompt for all ROI conditions',
   low_control='same selected ROI, first downsample to long edge 256 then upsample to 512; same image-token budget as HIGH',
   random_control='3 hash-seeded candidate indices excluding selected candidate; identical crop dimensions/pixel budget',
   duplicate_control='second copy of global 512 image; same dimensions/pixel budget',
   warning='Candidate ROI is a weakly localized crop, not an annotated lesion. Upsampling cannot create new detail; native long edge >512 and >1024 reported separately.',seeds=list(SEEDS)),
  conditions=list(CONDITIONS),
  inference='One fixed deterministic VLM, no policy training. Random evidence/crop controls use 3 seeds; their QA-level mean is compared with main deterministic tool. Do not count seeds as extra QA.',
  failure='Retry transient OSError/CUDA OOM up to 2 times. Persistent method failure retains cached E answer and is counted as failure. No QA exclusion. Resource breach stops collection; no efficacy-based stopping.',
  reference_access='Collector projects BANK/TRAIN/DEV reference files to group IDs only; labels joined only by separate scorer after complete prediction seal. Cached old E/Z/R predictions are comparators, not used to select new recipes.',
  statistical=dict(unit='QA, paired connected-article-group resampling; no independent-QA or independent-seed approximation',replicates=50000,seed=20261017,
   primary_contrasts=[a+'-'+b for a,b in PRIMARY],familywise_alpha=.05,number_required_contrasts=6,interval='two-sided percentile cluster CI, Bonferroni 99.1666667% for each of six required contrasts',percentiles=[100*.05/12,100*(1-.05/12)],secondary='95% descriptive intervals; all ablations/strata exploratory; no posthoc winning subgroup can pass the gate'),
  go_rules=dict(
   common=['No resource violation; method failure rate <=1%','No G5 changes and no forbidden split analysis','TRAIN same-tool point difference vs E >0 (consistency, no TRAIN significance requirement)'],
   retrieval=['DEV R_IQG - E >=0.02 and adjusted CI lower >0','DEV R_IQG - mean of 3 matched-family random sets adjusted CI lower >0','DEV R_IQG - old image-only retrieval adjusted CI lower >0','Nonempty main retrieval evidence >=95% of DEV QA'],
   roi=['DEV ROI_HIGH - E >=0.02 and adjusted CI lower >0','DEV ROI_HIGH - mean of 3 random ROIs adjusted CI lower >0','DEV ROI_HIGH - ROI_LOW adjusted CI lower >0','At least 100 DEV QA have native long edge >512'],
   interpretation='At least one tool must meet ALL its rules to justify a bounded fresh-cohort/two-model validation. Failure means stop this implementation/paper direction at current evidence, not proof of zero information or all ROI/RAG futility.',
   threshold_reason='2 percentage points is an internal investment threshold, not clinical relevance or journal acceptance standard.',
   publication='Even PASS is not journal-ready. Require an independently preregistered new group-disjoint cohort, >=2 VLMs and >=2 image domains, power based on TRAIN discordance, direct relevant published baselines, and held-out test used once. Preserve G5 negative findings.'),
  novelty=dict(existing=['RULE: calibrated retrieval and over-reliance harm control','MMed-RAG: domain-aware retrieval/adaptive context','MR-RAG CVPR 2026: multimodal retrieval relevance and generation','LobA IJCAI 2025: ROI localization/grounding','Med-CAP MICCAI 2026: counterfactual evidence/prior suppression (publisher abstract only)','Option-Aware Retrieval MedReason 2026: answer semantics, marginal retrieval and gating contributions'],
   candidate_contribution='A controlled, resource-bounded study separating query relevance, visual-family matching, native ROI detail and added context, with paired rescue/harm and explicit abstention from policy training until tool evidence is useful.',
   limit='This design is a testable evaluation contribution, not established algorithmic novelty. A single PMC cohort/small general VLM cannot establish publishable generality.'),
  code_sha256=code,input_sha256={s:sha(PROJECT/f'data/g2/frozen/inputs/{s.lower()}.jsonl') for s in xs},
  sources=[dict(title=t,url=u) for t,u in [
   ('RULE','https://aclanthology.org/2024.emnlp-main.62/'),
   ('MMed-RAG','https://proceedings.iclr.cc/paper_files/paper/2025/hash/a559a5a8aa5ae6682ced009ad97cdb16-Abstract-Conference.html'),
   ('MR-RAG','https://openaccess.thecvf.com/content/CVPR2026/html/Li_MR-RAG_Multimodal_Relevance-Aware_Retrieval-Augmented_Generation_for_Medical_Visual_Question_Answering_CVPR_2026_paper.html'),
   ('LobA','https://www.ijcai.org/proceedings/2025/0853.pdf'),
   ('Med-CAP','https://link.springer.com/chapter/10.1007/978-3-032-38059-3_30'),
   ('Option-Aware Retrieval','https://arxiv.org/abs/2609.15530')]])
 path=OUT/'protocol_frozen.json'
 if path.exists():
  old=load(path);assert old['code_sha256']==code and old['selected_ids']==plan['selected_ids'];return old
 dump('protocol_frozen.json',plan);dump('protocol_seal.json',dict(protocol_sha256=sha(path),code_sha256=code,at_kst=now(),before_new_predictions=True))
 return plan

if __name__=='__main__':freeze();progress('PROTOCOL_FROZEN',sha256=sha(OUT/'protocol_frozen.json'))
