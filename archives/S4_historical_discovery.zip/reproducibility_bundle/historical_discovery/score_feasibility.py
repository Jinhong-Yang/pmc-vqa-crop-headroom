"""Separate label join and all prespecified comparisons, only after full seal."""
from feasibility_common import *
import collections

def bootstrap_matrix(c,groups,replicates=50000):
 ids=sorted(set(groups));sums=np.array([c[np.array(groups)==g].sum(0) for g in ids]);sizes=np.array([groups.count(g) for g in ids]);rng=np.random.default_rng(20261017);draws=[]
 for i in range(0,replicates,1000):
  counts=rng.multinomial(len(ids),np.full(len(ids),1/len(ids)),size=min(1000,replicates-i));draws.append((counts@sums)/(counts@sizes)[:,None])
 return np.concatenate(draws)

def main():
 torch.set_num_threads(8)
 plan=load(OUT/'protocol_frozen.json');seal=load(OUT/'prediction_seal.json');assert sha(OUT/'protocol_frozen.json')==seal['protocol_sha256']
 for name,h in plan['code_sha256'].items():assert sha(OUT/name)==h,name
 for x in seal['files']:assert sha(OUT/x['path'])==x['sha256']
 summaries=[];comparisons=[];strata=[];perqa=[];diagnostics=[];all_results={}
 names=list(CONDITIONS)+['R_SHUFFLE_MEAN','ROI_RANDOM_MEAN'];idx={s:i for i,s in enumerate(names)}
 for split in ('TRAIN','DEV_FIT'):
  # This is the first correctness-label join for the new experiment.
  refs={r['sample_id']:r for r in read(PROJECT/f'data/g2/frozen/references/{split.lower()}.jsonl')}
  rows=[load(OUT/x['path']) for x in seal['files'] if x['path'].split('/')[1]==split.lower()];groups=[r['group_id'] for r in rows]
  c=np.array([[r['scores'][n]['answer']==refs[r['sample_id']]['reference'] for n in CONDITIONS] for r in rows],float)
  c=np.c_[c,c[:,[idx[f'R_SHUFFLE_{s}'] for s in SEEDS]].mean(1),c[:,[idx[f'ROI_RANDOM_{s}'] for s in SEEDS]].mean(1)]
  draws=bootstrap_matrix(c,groups);results={};n=len(rows)
  for name,j in idx.items():
   delta=c[:,j]-c[:,0];fail=sum(r['scores'].get(name,{}).get('status')=='failed_fallback_E' for r in rows)
   row=dict(split=split,condition=name,qa=n,groups=len(set(groups)),correct_sum=float(c[:,j].sum()),accuracy=float(c[:,j].mean()),delta_vs_E=float(delta.mean()),ci95_vs_E=np.percentile(draws[:,j]-draws[:,0],[2.5,97.5]).tolist(),rescue=float(np.maximum(delta,0).sum()),harm=float(np.maximum(-delta,0).sum()),failure_qa=fail)
   summaries.append(row);results[name]=row
  contrasts=list(PRIMARY)+[('R_IQ','R_IMAGE'),('R_IQG','R_IQ'),('R_IQG','R_Q'),('R_IQG','R_IQG_NO_ANSWER'),('ROI_HIGH','OLD_Z'),('ROI_HIGH','ROI_DUPLICATE'),('ROI_LOW','E')]
  split_con=[]
  for a,b in contrasts:
   v=draws[:,idx[a]]-draws[:,idx[b]];row=dict(split=split,contrast=a+'-'+b,estimate=float((c[:,idx[a]]-c[:,idx[b]]).mean()),ci95=np.percentile(v,[2.5,97.5]).tolist(),ci_adjusted=np.percentile(v,plan['statistical']['percentiles']).tolist() if (a,b) in PRIMARY else None,required=(a,b) in PRIMARY,qa=n,groups=len(set(groups)))
   comparisons.append(row);split_con.append(row)
  for i,r in enumerate(rows):
   sid=r['sample_id'];fam=r['observations']['family']['predicted'];roi=r['observations']['roi'];perqa.append(dict(split=split,sample_id=sid,group_id=r['group_id'],predicted_family=fam,native_gt512=roi['native_gt512'],native_gt1024=roi['native_gt1024'],**{name:float(c[i,j]) for name,j in idx.items()}))
  masks={f:np.array([r['observations']['family']['predicted']==f for r in rows]) for f in FAMILIES}
  masks.update({f'NATIVE_GT{k}':np.array([r['observations']['roi'][f'native_gt{k}'] for r in rows]) for k in (512,1024)})
  for label,mask in masks.items():
   if not mask.any():continue
   for name in ('E','R_IMAGE','R_IQ','R_IQG','R_SHUFFLE_MEAN','OLD_Z','ROI_HIGH','ROI_LOW','ROI_RANDOM_MEAN','ROI_DUPLICATE'):
    j=idx[name];d=c[mask,j]-c[mask,0];strata.append(dict(split=split,stratum=label,qa=int(mask.sum()),groups=len(set(np.array(groups)[mask])),condition=name,accuracy=float(c[mask,j].mean()),delta_vs_E=float(d.mean()),rescue=float(np.maximum(d,0).sum()),harm=float(np.maximum(-d,0).sum()),interpretation='descriptive, overlapping native-resolution strata; predicted image families are not annotated modalities'))
  dd=dict(split=split,qa=n,groups=len(set(groups)),native_gt512=sum(r['observations']['roi']['native_gt512'] for r in rows),native_gt1024=sum(r['observations']['roi']['native_gt1024'] for r in rows),family_distribution=dict(collections.Counter(r['observations']['family']['predicted'] for r in rows)),main_retrieval_empty=sum(r['observations']['R_IQG']['kept']==0 for r in rows),query_retrieval_truncation=sum(r['observations']['query_tokens']['retrieval_raw']>64 for r in rows),roi_query_truncation=sum(r['observations']['query_tokens']['roi_raw']>64 for r in rows),mean_family_max_probability=float(np.mean([max(r['observations']['family']['probabilities']) for r in rows])),family_confidence_lt025=sum(max(r['observations']['family']['probabilities'])<.25 for r in rows),main_vs_iq_same_neighbors=sum(r['observations']['R_IQG']['neighbor_ids']==r['observations']['R_IQ']['neighbor_ids'] for r in rows),roi_control_equal_image_tokens=all(r['scores']['ROI_HIGH']['image_tokens']==r['scores'][k]['image_tokens'] for r in rows for k in ('ROI_LOW','ROI_RANDOM_1','ROI_RANDOM_7','ROI_RANDOM_42','ROI_DUPLICATE')))
  diagnostics.append(dd);all_results[split]=dict(summary=results,contrasts={r['contrast']:r for r in split_con},diagnostics=dd)
  progress('SCORED',split=split,qa=n)
 train,dev=all_results['TRAIN'],all_results['DEV_FIT'];verdicts={}
 for tool,name in [('retrieval','R_IQG'),('roi','ROI_HIGH')]:
  pairs=PRIMARY[:3] if tool=='retrieval' else PRIMARY[3:]
  checks={'train_direction_positive':train['summary'][name]['delta_vs_E']>0,'dev_effect_ge_2pp':dev['summary'][name]['delta_vs_E']>=.02,'failure_le_1pct':dev['summary'][name]['failure_qa']/750<=.01}
  checks.update({a+'-'+b+'_adjusted_ci_positive':dev['contrasts'][a+'-'+b]['ci_adjusted'][0]>0 for a,b in pairs})
  checks['evidence_coverage']=dev['diagnostics']['main_retrieval_empty']/750<=.05 if tool=='retrieval' else dev['diagnostics']['native_gt512']>=100
  verdicts[tool]=dict(verdict='GO_TO_FRESH_VALIDATION' if all(checks.values()) else 'NO_GO_FOR_THIS_IMPLEMENTATION',checks=checks)
 before=load(OUT/'preservation_before.json');after=preserve();assert before==after;dump('preservation_after_scoring.json',after)
 csvout('summary.csv',summaries);csvout('contrasts.csv',comparisons);csvout('strata.csv',strata);csvout('per_qa_scored.csv',perqa)
 dump('results.json',dict(status='PASS',summary=summaries,contrasts=comparisons,diagnostics=diagnostics,tool_verdicts=verdicts,any_tool_passes=any(x['verdict']=='GO_TO_FRESH_VALIDATION' for x in verdicts.values()),protocol_sha256=sha(OUT/'protocol_frozen.json'),prediction_seal_sha256=sha(OUT/'prediction_seal.json'),test_analysis=False,g5_preserved=True,at_kst=now()))
 progress('SCORING_COMPLETE',tool_verdicts=verdicts)

if __name__=='__main__':main()
