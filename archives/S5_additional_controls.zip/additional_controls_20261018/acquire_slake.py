from pathlib import Path
import urllib.request,json,hashlib,datetime,zipfile
E=Path(__file__).resolve().parent;S=E/'sources';S.mkdir(exist_ok=True)
def get(url,path):
 if path.exists():return
 req=urllib.request.Request(url,headers={'User-Agent':'Academic reproducibility research'})
 with urllib.request.urlopen(req,timeout=120) as r,path.open('wb') as f:
  while b:=r.read(1024*1024):f.write(b)
get('https://huggingface.co/api/datasets/BoKelvin/SLAKE',S/'dataset_api.json')
meta=json.loads((S/'dataset_api.json').read_text());rev=meta['sha']
get(f'https://huggingface.co/api/datasets/BoKelvin/SLAKE/tree/{rev}',S/'tree.json')
tree=json.loads((S/'tree.json').read_text());print(json.dumps(tree),flush=True)
files=[]
for x in tree:
 name=x['path']
 if name in ['README.md','train.json','validation.json','validate.json','test.json','mask.txt','imgs.zip']:
  url=f'https://huggingface.co/datasets/BoKelvin/SLAKE/resolve/{rev}/{name}'
  get(url,S/name);p=S/name
  files.append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'url':url})
  print('DOWNLOADED',name,p.stat().st_size,flush=True)
receipt={'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'official_landing':'https://www.med-vqa.com/slake/','official_linked_repo':'BoKelvin/SLAKE','revision':rev,'files':files}
(S/'acquisition_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
with zipfile.ZipFile(S/'imgs.zip') as z:
 names=z.namelist();print('ZIP_FILES',len(names),'FIRST',names[:10],flush=True)
 dest=(E/'slake').resolve();dest.mkdir(exist_ok=True)
 for info in z.infolist():
  if info.is_dir():continue
  target=(dest/info.filename).resolve()
  assert target.is_relative_to(dest)
  if not target.exists():
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(info))
print('DONE',flush=True)
