"""Post-outcome same-class exclusion sensitivity; original frozen assay is unchanged."""
from pathlib import Path
import sys,json,hashlib
E=Path(__file__).resolve().parent;sys.path.insert(0,str(E.parent/'dependencies'))
import numpy as np
P=E/'positive_control';audit=json.loads((P/'control_anatomy_audit.json').read_text());meta={r['sample_id']:r for r in audit['rows']};refs=[json.loads(s) for s in (P/'main/references.jsonl').read_text().splitlines()];groups=json.loads((P/'annotation_audit.json').read_text())['groups']
J=json.loads((E/'results.json').read_text());out={'role':audit['role'],'geometry_summary':{k:v for k,v in audit.items() if k!='rows'},'models':{}}
def interval(values,seed=2026101805):
 values=np.array(values,float);rng=np.random.default_rng(seed);b=values[rng.integers(0,len(values),(20000,len(values)))].mean(1);return {'n':len(values),'estimate':float(values.mean()),'ci95':np.quantile(b,[.025,.975]).tolist()}
for m in ['2b','4b']:
 if not (P/m/'main_seal.json').exists():continue
 for f in json.loads((P/m/'main_seal.json').read_text())['files']:assert hashlib.sha256((P/m/f['path'].replace('\\','/')).read_bytes()).hexdigest()==f['sha256']
 answer={r['sample_id']:json.loads((P/m/'main'/(r['sample_id']+'.json')).read_text())['scores'] for r in refs};out['models'][m.upper()]={}
 for setting,pref,base in [('native','N','E_NATIVE'),('degraded','D','E_DEGRADED')]:
  items=[];old=[]
  for r in refs:
   info=meta[r['sample_id']];s=answer[r['sample_id']];gold=r['reference'];e=s[base]['answer']==gold;g=s[pref+'_POSITIVE']['answer']==gold
   controls={str(z):int(e or s[pref+'_CONTROL_'+str(z)]['answer']==gold) for z in [1,7,42]}
   if info['eligible_seeds']:items.append((r['image_id'],int(e or g)-sum(controls[z] for z in info['eligible_seeds'])/len(info['eligible_seeds'])))
   old.append((r['image_id'],int(e or g)-sum(controls.values())/3))
  ids=sorted(set(i for i,v in items));means=np.array([np.mean([v for i,v in items if i==iid]) for iid in ids]);oldmeans=np.array([np.mean([v for i,v in old if i==iid]) for iid in ids])
  assert len(ids)==82 and len(items)==114
  assert abs(float(oldmeans.mean())-J['positive_control'][m.upper()]['comparisons'][setting]['oracle']['estimate'])<1e-12
  estimate=interval(means);estimate['change_from_original']=interval(means-oldmeans);estimate['questions']=len(items)
  labs=sorted({groups[str(i)] for i in ids});sums=np.array([sum(v for i,v in zip(ids,means) if groups[str(i)]==g) for g in labs]);counts=np.array([sum(groups[str(i)]==g for i in ids) for g in labs]);w=np.random.default_rng(2026101805).multinomial(len(labs),np.full(len(labs),1/len(labs)),size=20000);b=w@sums/(w@counts)
  estimate['cluster_ci95']=np.quantile(b,[.025,.975]).tolist();out['models'][m.upper()][setting]=estimate
out['status']='COMPLETE' if len(out['models'])==2 else 'PARTIAL'
(E/'anatomy_sensitivity.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
