from pathlib import Path
import sys,json,csv,hashlib,datetime,collections
E=Path(__file__).resolve().parent;R=E.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
from scipy.stats import binomtest
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def boot(x,seed=2026101801):
 x=np.asarray(x,float);v,c=np.unique(x,return_counts=True);rng=np.random.default_rng(seed);b=rng.multinomial(len(x),c/len(x),size=20000)@v/len(x)
 return {'n':len(x),'estimate':float(x.mean()),'ci95':np.quantile(b,[.025,.975]).tolist()}
def paired(x,y):
 d=np.asarray(x,float)-np.asarray(y,float);r=boot(d);plus=int((d>0).sum());minus=int((d<0).sum());r.update(improved=plus,worsened=minus,p_exact=float(binomtest(plus,plus+minus).pvalue) if plus+minus else 1.0);return r
def holm(values):
 order=np.argsort(values);out=np.zeros(len(values));prior=0
 for rank,i in enumerate(order):prior=max(prior,min(1,(len(values)-rank)*values[i]));out[i]=prior
 return out.tolist()
def sealed(o,split='main'):
 seal=json.loads((o/(split+'_seal.json')).read_text(encoding='utf-8'))
 for f in seal['files']:assert sha(o/f['path'].replace('\\','/'))==f['sha256']
 return seal
def jsonout(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'analysis_role':'Exploratory prospective controls added after original manuscript','no_image':{},'positive_control':{}}
flat=[]
for model in ['2b','4b']:
 o=E/'no_image'/model
 if not (o/'main_seal.json').exists():continue
 seal=sealed(o)
 for cohort,folder in [('primary','controlled_replication'),('curated','curated_replication_2b')]:
  oldfolder=folder if model=='2b' else ('controlled_replication_4b' if cohort=='primary' else 'curated_replication_4b')
  refs={r['sample_id']:r['reference'] for r in read(R/folder/'main/references.jsonl')}
  records=[json.loads((o/'main'/cohort/(sid+'.json')).read_text(encoding='utf-8')) for sid in refs]
  gold=[refs[r['sample_id']] for r in records]
  C={name:np.array([r['scores'][name]['answer']==a for r,a in zip(records,gold)],float) for name in ['E_REPEAT','Q_MATCHED','Q_NEUTRAL']}
  old=[json.loads((R/oldfolder/'main/predictions'/(r['sample_id']+'.json')).read_text(encoding='utf-8')) for r in records]
  correct=lambda name:np.array([r['scores'][name]['answer']==a for r,a in zip(old,gold)],float)
  base=correct('E');guided=correct('ROI_HIGH');controls=np.array([correct('ROI_RANDOM_'+str(s)) for s in [1,7,42]]).T
  delta=np.maximum(base,guided)-np.maximum(base[:,None],controls).mean(1)
  label=cohort.title()+'/'+model.upper();result={'n':len(gold),'accuracy':{k:boot(v) for k,v in C.items()},'image_minus_matched':paired(C['E_REPEAT'],C['Q_MATCHED']),'image_minus_neutral':paired(C['E_REPEAT'],C['Q_NEUTRAL']),'neutral_minus_matched':paired(C['Q_NEUTRAL'],C['Q_MATCHED']),
  'repeat_answer_agreement':float(np.mean([a['scores']['E_REPEAT']['answer']==b['scores']['E']['answer'] for a,b in zip(records,old)])),'repeat_max_probability_error':max(abs(a-b) for n,oldr in zip(records,old) for a,b in zip(n['scores']['E_REPEAT']['option_probs'],oldr['scores']['E']['option_probs'])),
  'crop_oracle_by_text_correctness':{}}
  for status in [0,1]:
   mask=C['Q_MATCHED']==status;result['crop_oracle_by_text_correctness']['text_correct' if status else 'text_error']={'contrast':boot(delta[mask]),'image_baseline_accuracy':float(base[mask].mean()),'guided_headroom':float(((1-base[mask])*guided[mask]).mean()),'control_headroom':float(((1-base[mask,None])*controls[mask]).mean())}
  out['no_image'][label]=result
  for j,r in enumerate(records):
   flat.append({'experiment':'no_image','model':model,'cohort':cohort,'sample_id':r['sample_id'],'image_id':r['sample_id'],'reference':gold[j],**{f'{k}_answer':r['scores'][k]['answer'] for k in C},'original_crop_oracle_delta':delta[j]})
if out['no_image']:
 vals=list(out['no_image'].values())
 for v,p in zip(vals,holm([v['image_minus_matched']['p_exact'] for v in vals])):v['image_minus_matched']['p_holm']=p

def image_aggregate(vals,iids):
 unique=sorted(set(iids));return np.array([np.asarray(vals)[np.asarray(iids)==i].mean() for i in unique]),unique
def cluster_interval(image_values,iids,groups):
 labs=sorted({groups[str(i)] for i in iids});sums=np.array([sum(v for v,i in zip(image_values,iids) if groups[str(i)]==g) for g in labs]);counts=np.array([sum(groups[str(i)]==g for i in iids) for g in labs]);rng=np.random.default_rng(2026101802);weights=rng.multinomial(len(labs),np.full(len(labs),1/len(labs)),size=20000);b=(weights@sums)/(weights@counts)
 return {'clusters':len(labs),'estimate':float(np.mean(image_values)),'ci95':np.quantile(b,[.025,.975]).tolist()}
audit=json.loads((E/'positive_control/annotation_audit.json').read_text());groups=audit['groups']
for model in ['2b','4b']:
 o=E/'positive_control'/model
 if not (o/'main_seal.json').exists():continue
 sealed(o);rows=read(E/'positive_control/main/references.jsonl');iids=[r['image_id'] for r in rows]
 records=[json.loads((o/'main'/(r['sample_id']+'.json')).read_text()) for r in rows];conditions=list(records[0]['scores'])
 C={name:np.array([r['scores'][name]['answer']==gold['reference'] for r,gold in zip(records,rows)],float) for name in conditions}
 result={'questions':len(rows),'images':len(set(iids)),'accuracy':{name:boot(image_aggregate(v,iids)[0],2026101802) for name,v in C.items()},'comparisons':{},'class_accuracy':{}}
 for setting,prefix,baseline in [('degraded','D','E_DEGRADED'),('native','N','E_NATIVE')]:
  e=C[baseline];p=C[prefix+'_POSITIVE'];c=np.array([C[prefix+'_CONTROL_'+str(s)] for s in [1,7,42]]).T
  series={'oracle':np.maximum(e,p)-np.maximum(e[:,None],c).mean(1),'direct':p-c.mean(1),'positive_vs_baseline':p-e,'positive_headroom':np.maximum(e,p)-e,'control_headroom':np.maximum(e[:,None],c).mean(1)-e,'excess_harm':(e*(1-p))-(e[:,None]*(1-c)).mean(1)}
  comp={}
  for name,values in series.items():
   avg,ids=image_aggregate(values,iids);comp[name]=boot(avg,2026101802);comp[name]['cluster_sensitivity']=cluster_interval(avg,ids,groups)
   if name=='oracle':
    rng=np.random.default_rng(2026101802);null=(rng.choice([-1,1],size=(20000,len(avg)))*avg).mean(1);comp[name]['p_signflip']=(1+int((np.abs(null)>=abs(avg.mean())-1e-12).sum()))/20001
  result['comparisons'][setting]=comp
 for cl in sorted({r['answer_text'] for r in rows}):
  mask=np.array([r['answer_text']==cl for r in rows]);result['class_accuracy'][cl]={'questions':int(mask.sum()),'accuracy':{k:float(v[mask].mean()) for k,v in C.items()}}
  result['class_accuracy'][cl]['oracle_contrast']={}
  for setting,pref,base in [('native','N','E_NATIVE'),('degraded','D','E_DEGRADED')]:
   b=C[base];p=C[pref+'_POSITIVE'];cs=np.array([C[pref+'_CONTROL_'+str(s)] for s in [1,7,42]]).T
   result['class_accuracy'][cl]['oracle_contrast'][setting]=float((np.maximum(b,p)-np.maximum(b[:,None],cs).mean(1))[mask].mean())
 out['positive_control'][model.upper()]=result
 for r,gold in zip(records,rows):flat.append({'experiment':'positive_control','model':model,'cohort':'main','sample_id':gold['sample_id'],'image_id':gold['image_id'],'reference':gold['reference'],**{f'{k}_answer':r['scores'][k]['answer'] for k in C}})
if out['positive_control']:
 vals=list(out['positive_control'].values())
 for v,p in zip(vals,holm([v['comparisons']['degraded']['oracle']['p_signflip'] for v in vals])):v['comparisons']['degraded']['oracle']['p_holm']=p
out['status']='COMPLETE' if len(out['no_image'])==4 and len(out['positive_control'])==2 else 'PARTIAL_COLLECTION'
jsonout(E/'results.json',out)
if flat:
 keys=list(dict.fromkeys(k for r in flat for k in r))
 with (E/'question_level_results.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(flat)
print(json.dumps({'status':out['status'],'no_image':{k:{'accuracy':{c:round(v['estimate']*100,3) for c,v in r['accuracy'].items()},'image_difference_pp':r['image_minus_matched']['estimate']*100} for k,r in out['no_image'].items()},'positive_control':{k:{s:r['comparisons'][s]['oracle'] for s in ['native','degraded']} for k,r in out['positive_control'].items()}},indent=2))
