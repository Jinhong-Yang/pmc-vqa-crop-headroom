from pathlib import Path
import json,sys,hashlib
E=Path(__file__).resolve().parent;R=E.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines()]
def boot(x):
 x=np.array(x,float);v,c=np.unique(x,return_counts=True);b=np.random.default_rng(2026101803).multinomial(len(x),c/len(x),20000)@v/len(x)
 return {'n':len(x),'estimate':float(x.mean()),'ci95':np.quantile(b,[.025,.975]).tolist()}
O=E/'prompt_controls/2b';seal=json.loads((O/'main_seal.json').read_text())
for f in seal['files']:assert hashlib.sha256((O/f['path'].replace('\\','/')).read_bytes()).hexdigest()==f['sha256']
refs=read(R/'controlled_replication/main/references.jsonl');rows=[json.loads((O/'main'/(r['sample_id']+'.json')).read_text()) for r in refs];old=[json.loads((R/'controlled_replication/main/predictions'/(r['sample_id']+'.json')).read_text()) for r in refs]
C={k:np.array([a['scores'][k]['answer']==b['reference'] for a,b in zip(rows,refs)],float) for k in rows[0]['scores']};B={k:np.array([a['scores'][k]['answer']==b['reference'] for a,b in zip(old,refs)],float) for k in ['E','ROI_HIGH','ROI_RANDOM_1','ROI_RANDOM_7','ROI_RANDOM_42']}
def oracle(e,g,c):return np.maximum(e,g)-np.maximum(e[:,None],c).mean(1)
c=np.array([C['ROI_RANDOM_'+str(s)+'_NEUTRAL'] for s in [1,7,42]]).T;oldc=np.array([B['ROI_RANDOM_'+str(s)] for s in [1,7,42]]).T
d=oracle(C['E_NEUTRAL'],C['ROI_HIGH_NEUTRAL'],c);d0=oracle(B['E'],B['ROI_HIGH'],oldc)
out={'status':'COMPLETE','n':len(rows),'accuracy':{k:boot(v) for k,v in C.items()},'neutral_oracle_contrast':boot(d),'change_from_original_contrast':boot(d-d0),'original_image_minus_blank':boot(B['E']-C['BLANK_MATCHED']),'neutral_baseline_minus_original':boot(C['E_NEUTRAL']-B['E']),'neutral_direct_guided_minus_control':boot(C['ROI_HIGH_NEUTRAL']-c.mean(1)),'role':'Exploratory primary 2B sensitivity; 95% intervals unadjusted.'}
(E/'prompt_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
