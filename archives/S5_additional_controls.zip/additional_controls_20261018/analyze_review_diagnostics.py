from pathlib import Path
import sys,json,datetime
E=Path(__file__).resolve().parent;R=E.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
from scipy.stats import ttest_1samp
def read(p):return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines()]
def boot(x):
 x=np.array(x,float);v,c=np.unique(x,return_counts=True);b=np.random.default_rng(2026101804).multinomial(len(x),c/len(x),size=20000)@v/len(x)
 return {'n':len(x),'estimate':float(x.mean()),'ci95':np.quantile(b,[.025,.975]).tolist()}
def bh(p):
 order=np.argsort(p);out=np.ones(len(p));v=1
 for rank in range(len(p)-1,-1,-1):i=order[rank];v=min(v,p[i]*len(p)/(rank+1));out[i]=v
 return out.tolist()
out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'role':'Post-outcome exploratory diagnostics. Position strata are descriptive; t-reference p values and BH across 36 selector differences are additional approximate multiplicity checks, not confirmatory tests.','runs':{}}
alltests=[]
prior=json.loads((R/'presubmission_20261018/additional_results.json').read_text(encoding='utf-8'))
for label,folder in [('Primary/2B','controlled_replication'),('Primary/4B','controlled_replication_4b'),('Curated/2B','curated_replication_2b'),('Curated/4B','curated_replication_4b')]:
 refs=read(R/folder/'main/references.jsonl');raw=[json.loads((R/folder/'main/predictions'/(r['sample_id']+'.json')).read_text(encoding='utf-8')) for r in refs]
 gold=np.array(['ABCD'.index(r['reference']) for r in refs]);probs={k:np.array([r['scores'][k]['option_probs'] for r in raw]) for k in raw[0]['scores']};answers={k:np.argmax(v,axis=1) for k,v in probs.items()};C={k:(v==gold).astype(float) for k,v in answers.items()}
 e=C['E'];g=C['ROI_HIGH'];c=np.array([C['ROI_RANDOM_'+str(s)] for s in [1,7,42]]).T;delta=(1-e)*(g-c.mean(1));pos=np.array([r['observations']['roi']['chosen'] for r in raw]);res={'positions':{},'headroom':{},'diversity':{},'selector_tests':[]}
 for j in range(9):
  m=pos==j;res['positions'][str(j)]={'contrast':boot(delta[m]),'baseline_accuracy':float(e[m].mean()),'guided_headroom':float(((1-e[m])*g[m]).mean())}
 for k in ['ROI_HIGH','ROI_DUPLICATE','ROI_LOW']:
  res['headroom'][k]=boot((1-e)*C[k]);res['diversity'][k]={'answer_disagreement':float((answers[k]!=answers['E']).mean()),'correctness_disagreement':float((C[k]!=e).mean())}
 res['headroom']['CONTROL_MEAN']=boot((1-e)*c.mean(1))
 def select(names,rule):
  p=np.stack([probs[k] for k in names],axis=1)
  if rule=='Avg':return p.mean(1).argmax(1)
  quality=p.max(2) if rule=='Conf' else (p*np.log(np.clip(p,1e-30,1))).sum(2)
  best=quality.argmax(1);return p[np.arange(len(p)),best].argmax(1)
 for pool,gn,cn in [('Crop',['E','ROI_HIGH'],[['E','ROI_RANDOM_'+str(s)] for s in [1,7,42]]),('Retrieval',['E','R_IQG'],[['E','R_SHUFFLE_'+str(s)] for s in [1,7,42]]),('Combined',['E','R_IQG','ROI_HIGH'],[['E','R_SHUFFLE_'+str(s),'ROI_RANDOM_'+str(s)] for s in [1,7,42]])]:
  for rule in ['Conf','Entropy','Avg']:
   a=(select(gn,rule)==gold).astype(float);b=np.array([(select(n,rule)==gold).astype(float) for n in cn]).mean(0);d=a-b;t=boot(d);t.update(pool=pool,rule=rule,p_t_reference=float(ttest_1samp(d,0).pvalue),run=label)
   res['selector_tests'].append(t);alltests.append(t)
 for a,b in zip(res['selector_tests'],prior['runs'][label]['selectors']):
  assert abs(a['estimate']-b['guided_minus_control']['estimate'])<1e-12
  a['independent_seed_ci95']=a['ci95'];a['ci95']=b['guided_minus_control']['ci95']
 out['runs'][label]=res
for t,q in zip(alltests,bh([t['p_t_reference'] for t in alltests])):t['q_bh_36']=q
out['selector_summary']={'tests':36,'ci_excludes_zero_positive':sum(t['ci95'][0]>0 for t in alltests),'ci_excludes_zero_negative':sum(t['ci95'][1]<0 for t in alltests),'bh_q_below_05':sum(t['q_bh_36']<.05 for t in alltests)}
(E/'review_diagnostics.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out['selector_summary']))
