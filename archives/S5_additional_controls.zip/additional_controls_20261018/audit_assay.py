from pathlib import Path
import sys,json,hashlib,datetime,collections,itertools
E=Path(__file__).resolve().parent;sys.path.insert(0,str(E.parent/'dependencies'))
import numpy as np
from PIL import Image
from scipy.fft import dctn
P=E/'positive_control'
def read(p):return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines()]
rows=[x for split in ['pilot','main'] for x in read(P/split/'annotation_metadata.jsonl')]
inputs={x['sample_id']:x for split in ['pilot','main'] for x in read(P/split/'inputs.jsonl')}
refs={x['sample_id']:x for split in ['pilot','main'] for x in read(P/split/'references.jsonl')}
values={'Liver':70,'Left Kidney':135,'Right Kidney':155,'Spleen':230,'Spinal Cord':145}
checks=[];features={}
for r in rows:
 sid=r['sample_id'];x=inputs[sid];mask=np.asarray(Image.open(Path(r['image_path']).with_name('mask.png')));mask=mask[:,:,0] if mask.ndim==3 else mask
 target=mask==values[r['target_label']];total=target.sum();assert total==r['target_pixels']
 recalls=[]
 for b in [x['positive_box']]+list(x['control_boxes'].values()):
  l,t,rr,bb=b;recalls.append(float(target[t:bb,l:rr].sum()/total))
 assert recalls[0]>=.95 and max(recalls[1:])<=.01
 dims=[(b[2]-b[0],b[3]-b[1]) for b in [x['positive_box']]+list(x['control_boxes'].values())]
 assert len(set(dims))==1
 assert x['options']['ABCD'.index(refs[sid]['reference'])]==r['canonical']
 assert 'reference' not in x and 'answer_text' not in x and 'target_label' not in x
 checks.append({'sample_id':sid,'positive_recall':recalls[0],'max_control_recall':max(recalls[1:]),'same_native_size':True})
 iid=x['image_id']
 if iid not in features:
  im=Image.open(x['image_path']).convert('L');a=np.asarray(im.resize((32,32),Image.Resampling.LANCZOS),float);f=dctn(a,norm='ortho')[:8,:8];bits=f>np.median(f.flat[1:]);bits[0,0]=False
  d=np.asarray(im.resize((9,8),Image.Resampling.LANCZOS),int);dbits=d[:,1:]>d[:,:-1]
  features[iid]={'phash':bits.ravel(),'dhash':dbits.ravel(),'ratio':im.width/im.height}
parents={i:i for i in features}
def root(i):
 while parents[i]!=i:parents[i]=parents[parents[i]];i=parents[i]
 return i
edges=[]
for a,b in itertools.combinations(sorted(features),2):
 fa,fb=features[a],features[b]
 hp=int(np.count_nonzero(fa['phash']!=fb['phash']));hd=int(np.count_nonzero(fa['dhash']!=fb['dhash']))
 if hp<=6 and hd<=8 and .85<=fa['ratio']/fb['ratio']<=1/.85:
  parents[root(b)]=root(a);edges.append({'a':a,'b':b,'phash_hamming':hp,'dhash_hamming':hd})
groups={str(i):root(i) for i in features};sizes=collections.Counter(groups.values())
mainids={x['image_id'] for x in read(P/'main/inputs.jsonl')};pilotids={x['image_id'] for x in read(P/'pilot/inputs.jsonl')}
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','questions':len(rows),'geometry_checks':checks,'group_rule':'AND: pHash Hamming <=6, dHash <=8, aspect ratio within [.85,1/.85]. Pixel-based similarity groups, not known patients.','groups':groups,'edges':edges,'all_groups':len(sizes),'max_group_images':max(sizes.values()),'main_groups':len({groups[str(i)] for i in mainids}),'pilot_main_shared_similarity_groups':len({groups[str(i)] for i in mainids}&{groups[str(i)] for i in pilotids})}
(P/'annotation_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
original=P/'protocol.json';saved=P/'protocol_initial.json'
assert not saved.exists();saved.write_bytes(original.read_bytes());protocol=json.loads(original.read_text(encoding='utf-8'))
protocol['preflight_amendment']={'at':report['at'],'reason':'Prespecify an additional image-similarity-cluster sensitivity interval before any assay inference. Main image-level estimand and all selected inputs unchanged.','initial_protocol_sha256':hashlib.sha256(saved.read_bytes()).hexdigest(),'rule':report['group_rule'],'main_groups':report['main_groups'],'pilot_main_shared_similarity_groups':report['pilot_main_shared_similarity_groups'],'interpretation':'Pilot is technical only; no efficacy selection. Similarity grouping does not establish patient identity.'}
protocol['analysis']['additional_sensitivity']='Resample main perceptual-similarity clusters, preserving all questions/images in each cluster; recompute equal-image average with sampled image multiplicities. Report alongside image-level CI.'
original.write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ['geometry_checks','groups','edges']},ensure_ascii=True))
