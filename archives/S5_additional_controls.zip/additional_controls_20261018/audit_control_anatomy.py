"""Post-outcome audit of same-class tissue in annotation controls; no sample or prediction edits."""
from pathlib import Path
import sys,json,datetime,collections
E=Path(__file__).resolve().parent;sys.path.insert(0,str(E.parent/'dependencies'))
import numpy as np
from PIL import Image
P=E/'positive_control'
rows=[json.loads(s) for s in (P/'main/annotation_metadata.jsonl').read_text(encoding='utf-8').splitlines()]
codes={'Liver':[70],'Kidney':[135,155],'Spleen':[230],'Spinal cord':[145]}
out=[]
for r in rows:
 a=np.asarray(Image.open(Path(r['image_path']).with_name('mask.png')));a=a[:,:,0] if a.ndim==3 else a
 mask=np.isin(a,codes[r['canonical']]);total=int(mask.sum());recalls={}
 for seed,control in r['controls'].items():
  l,t,rr,b=control['box'];recalls[seed]=float(mask[t:b,l:rr].sum()/total)
 out.append({'sample_id':r['sample_id'],'image_id':r['img_id'],'class':r['canonical'],'annotated_side':r['target_label'],'same_class_control_recall':recalls,'eligible_seeds':[s for s,v in recalls.items() if v<=.01]})
bad=[r for r in out if len(r['eligible_seeds'])<3]
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'role':'Post-outcome descriptive control audit, added after 2B assay completion. Original eligibility, conditions and primary results unchanged.','criterion':'For sensitivity, retain controls with <=1% of the union of masks sharing the answer class. Kidney union includes left and right.','questions':len(out),'questions_with_any_same_class_contamination':len(bad),'contaminated_control_pairs':sum(3-len(r['eligible_seeds']) for r in out),'questions_retained_at_least_one_control':sum(bool(r['eligible_seeds']) for r in out),'classes_affected':dict(collections.Counter(r['class'] for r in bad)),'rows':out}
(P/'control_anatomy_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='rows'}))
