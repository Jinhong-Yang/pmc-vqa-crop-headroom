from pathlib import Path
import json,hashlib,datetime,collections,math
import numpy as np
from PIL import Image,ImageOps,ImageDraw,ImageFont
E=Path(__file__).resolve().parent;P=E/'positive_control';P.mkdir(exist_ok=True)
def stable(s):return hashlib.sha256(('annotation-assay-20261018|'+s).encode()).hexdigest()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def jsonl(p,x):p.write_text(''.join(json.dumps(t,ensure_ascii=False)+'\n' for t in x),encoding='utf-8')
canonical={'Liver':('Liver',70),'Left Kidney':('Kidney',135),'Right Kidney':('Kidney',155),'Spleen':('Spleen',230),'Spinal Cord':('Spinal cord',145)}
options=['Liver','Kidney','Spleen','Spinal cord']
sources={};source_splits={}
for split in ['train','validation','test']:
 for row in json.loads((E/'sources'/f'{split}.json').read_text(encoding='utf-8')):
  if row['q_lang']!='en':continue
  sid=row['img_id'];source_splits.setdefault(sid,set()).add(split);sources.setdefault(sid,row)
assert all(len(x)==1 for x in source_splits.values())
exclude=collections.Counter();candidates=[];seen_pixels={};pixel_duplicates=[]
for iid in sorted(sources):
 d=E/'slake/imgs'/f'xmlab{iid}';im=Image.open(d/'source.jpg').convert('RGB');w,h=im.size
 pixels=hashlib.sha256(im.tobytes()).hexdigest()
 if pixels in seen_pixels:pixel_duplicates.append([iid,seen_pixels[pixels]]);continue
 seen_pixels[pixels]=iid
 arr=np.array(Image.open(d/'mask.png'));arr=arr[:,:,0] if arr.ndim==3 else arr;assert arr.shape==(h,w)
 gray=np.asarray(im.convert('L'));anns=json.loads((d/'detection.json').read_text());byclass={}
 for a in anns:
  for label,bb in a.items():
   if label not in canonical:continue
   name,value=canonical[label];x,y,bw,bh=bb
   if min(bw,bh)<16:exclude['box_short_edge_below16']+=1;continue
   side=int(math.ceil(max(bw,bh)*1.10))
   if side>.55*min(w,h):exclude['square_over_55_percent_short_edge']+=1;continue
   x0=int(round(x+bw/2-side/2));y0=int(round(y+bh/2-side/2));x0=max(0,min(w-side,x0));y0=max(0,min(h-side,y0));pos=[x0,y0,x0+side,y0+side]
   mask=arr==value;total=int(mask.sum())
   if total<64:exclude['target_mask_below64_pixels']+=1;continue
   coverage=float(mask[y0:y0+side,x0:x0+side].sum()/total)
   if coverage<.95:exclude['positive_mask_recall_below95_percent']+=1;continue
   choices=[]
   for cy in sorted(set(round(j*(h-side)/16) for j in range(17))):
    for cx in sorted(set(round(j*(w-side)/16) for j in range(17))):
     box=[cx,cy,cx+side,cy+side];m=float(mask[cy:cy+side,cx:cx+side].sum()/total);patch=gray[cy:cy+side,cx:cx+side]
     if m<=.01 and float(patch.std())>=8 and float((patch>10).mean())>=.25:choices.append((box,m))
   if len(choices)<3:exclude['fewer_than_three_valid_controls']+=1;continue
   controls={};used=set()
   for seed in [1,7,42]:
    valid=[z for z in choices if tuple(z[0]) not in used]
    box,recall=min(valid,key=lambda z:stable(f'{iid}|{name}|{seed}|{z[0]}'));used.add(tuple(box));controls[str(seed)]={'box':box,'target_mask_recall':recall}
   obj={'img_id':iid,'target_label':label,'canonical':name,'target_pixels':total,'annotation_box_xywh':bb,'positive_box':pos,'positive_mask_recall':coverage,'controls':controls,'image_path':str((d/'source.jpg').resolve()),'image_sha256':sha(d/'source.jpg'),'pixel_sha256':pixels,'mask_sha256':sha(d/'mask.png'),'source_split':next(iter(source_splits[iid]))}
   # One target per image and canonical structure, chosen by annotated mask size.
   if name not in byclass or (total,label)>(byclass[name]['target_pixels'],byclass[name]['target_label']):byclass[name]=obj
 candidates.extend(byclass.values())
images=sorted({x['img_id'] for x in candidates},key=lambda i:stable(f'pilot|{i}'))
pilotids=set([i for i in images if source_splits[i]=={'train'}][:32]);assert len(pilotids)==32
inputs={'pilot':[],'main':[]};refs={'pilot':[],'main':[]};meta={'pilot':[],'main':[]}
for row in sorted(candidates,key=lambda r:stable(f"item|{r['img_id']}|{r['canonical']}")):
 split='pilot' if row['img_id'] in pilotids else 'main';sid=f"slake-{row['img_id']}-{row['canonical'].lower().replace(' ','-')}"
 opts=sorted(options,key=lambda s:stable(sid+'|option|'+s))
 x={'sample_id':sid,'image_id':row['img_id'],'question':'Which anatomical structure is enclosed by the red box in the first image?','options':opts,'image_path':row['image_path'],'annotation_box_xywh':row['annotation_box_xywh'],'positive_box':row['positive_box'],'control_boxes':{s:z['box'] for s,z in row['controls'].items()}}
 inputs[split].append(x);refs[split].append({'sample_id':sid,'image_id':row['img_id'],'reference':'ABCD'[opts.index(row['canonical'])],'answer_text':row['canonical']});meta[split].append({'sample_id':sid,**row})
for split in inputs:
 (P/split).mkdir(exist_ok=True);jsonl(P/split/'inputs.jsonl',inputs[split]);jsonl(P/split/'references.jsonl',refs[split]);jsonl(P/split/'annotation_metadata.jsonl',meta[split])
profile={'all_source_images':len(sources),'exact_pixel_duplicates_removed':pixel_duplicates,'annotation_exclusions':dict(exclude),'counts':{s:{'questions':len(v),'images':len({x['image_id'] for x in v}),'classes':dict(collections.Counter(r['answer_text'] for r in refs[s])),'source_splits':dict(collections.Counter(x['source_split'] for x in meta[s]))} for s,v in inputs.items()}}
write(P/'cohort_profile.json',profile)
conditions=['E_NATIVE','E_DEGRADED','D_POSITIVE','D_CONTROL_1','D_CONTROL_7','D_CONTROL_42','N_POSITIVE','N_CONTROL_1','N_CONTROL_7','N_CONTROL_42','Q_MATCHED']
protocol={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'FROZEN_BEFORE_PILOT_INFERENCE','role':'Annotation-derived anatomical recognition positive-control assay; not original SLAKE VQA accuracy and not PMC-VQA clinical localization validation.',
'source':json.loads((E/'sources/acquisition_receipt.json').read_text()),'classes':options,'question':inputs['main'][0]['question'],'sample_selection':'Every qualifying image/structure from official SLAKE; one target per image/canonical structure. 32 hash-selected official-training images reserved for technical pilot; all other qualifying images form main. No model-outcome-based exclusion or tuning.',
'eligibility':'Source organ bounding box min edge16; 10%-padded square side <=55% of shorter image edge; >=64 annotated pixels; >=95% target mask recall; three distinct area-matched control squares with <=1% target mask recall, grayscale SD>=8 and >=25% pixels above10. Exact decoded-image duplicates removed.',
'conditions':conditions,'rendering':{'E_NATIVE':'Source RGB thumbnail longest edge512, red rectangle marking source annotated bounding box.','E_DEGRADED':'Source thumbnail longest edge64, enlarged to native-baseline rendered size; same red rectangle added afterwards.','D_POSITIVE':'Degraded baseline plus annotated square crop at512x512.','D_CONTROL_s':'Degraded baseline plus hash-chosen target-excluding square of identical side and rendered size.','N_POSITIVE':'Native baseline plus same annotated crop.','N_CONTROL_s':'Native baseline plus same target-excluding crop.','Q_MATCHED':'Identical question/options/instruction without images; prior-only diagnostic.'},
'estimands':{'primary':'Within-image mean of max(E_DEGRADED,D_POSITIVE) minus mean_s max(E_DEGRADED,D_CONTROL_s), then average over main images.','secondary':['Analogous native-image contrast','Direct positive-minus-control accuracy and rescue/harm in both baseline conditions','Image-averaged accuracies and per-class results','Positive-versus-control target-mask coverage and identical extra-image tokens']},
'analysis':{'bootstrap':20000,'seed':2026101802,'unit':'source image; all structures from a sampled image kept together','intervals':'95% paired image bootstrap; both model-size primary p-values Holm-adjusted with sign-flip randomization. All extension analyses exploratory relative to original study.','patient_identity':'Unavailable; no independent-patient sampling or clinical generalisation claim.'},
'pilot_gate':'All records complete; finite probabilities; same image tokens among positive/control candidates; >=95% vs <=1% mask coverage; official/optimized scoring agreement. No positive or significant efficacy required to proceed.',
'failure':'Stop on technical failure; no silent imputation or post-outcome exclusions.',
'bindings':{str(P/s/'inputs.jsonl'):sha(P/s/'inputs.jsonl') for s in ['pilot','main']},'preparation_sha256':sha(Path(__file__))}
assert not (P/'protocol.json').exists();write(P/'protocol.json',protocol)
print(json.dumps(profile),flush=True)
# Visual audit sheet: unaltered source and annotated square/controls, without generated imagery.
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',16)
preview=Image.new('RGB',(1200,240*min(6,len(inputs['pilot']))),'white');draw=ImageDraw.Draw(preview)
for k,x in enumerate(inputs['pilot'][:6]):
 src=Image.open(x['image_path']).convert('RGB');marked=src.copy();ImageDraw.Draw(marked).rectangle(tuple(x['positive_box']),outline='red',width=max(1,src.width//180))
 panels=[marked,src.crop(x['positive_box'])]+[src.crop(x['control_boxes'][str(s)]) for s in [1,7,42]]
 for j,im in enumerate(panels):
  im.thumbnail((224,200));preview.paste(im,(j*240,k*240+30));draw.text((j*240,k*240+4),[x['sample_id'],'Annotated','Control1','Control7','Control42'][j],fill='black',font=font)
preview.save(P/'pilot_geometry_preview.png')
