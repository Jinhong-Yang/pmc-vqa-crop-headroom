from pathlib import Path
import json,hashlib,datetime
E=Path(__file__).resolve().parent;R=E.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf-8')
P=E/'no_image';P.mkdir(exist_ok=True)
protocol={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'FIXED_BEFORE_ADDITIONAL_INFERENCE','analysis_role':'Additional prospective interventions on previously analysed cohorts; exploratory, not a new confirmatory test.',
'models':['Qwen3-VL-2B-Instruct','Qwen3-VL-4B-Instruct'],'conditions':['E_REPEAT','Q_MATCHED','Q_NEUTRAL'],
'definitions':{'E_REPEAT':'Recompute the original global-image baseline with identical prompt, options, pixels and cap.','Q_MATCHED':'Remove all image content and image tokens while keeping original text exactly.','Q_NEUTRAL':'No image and replace first instruction with Answer the multiple-choice question. Keep question, choices and final response instruction.'},
'pilot':{'primary':128,'curated':64,'pool_with_main':False,'gate':'No failed records, finite normalised probabilities, no image tensors/tokens in Q conditions, 3072-token limit. Compare official vs last-position scoring. E_REPEAT answer concordance with original >=99% and maximum option probability deviation <=0.02; otherwise stop and investigate before main.'},
'main':{'primary':2048,'curated':825,'sampling':'Every original main question; no outcome-based filtering or subsampling.'},
'outcomes':['paired E_REPEAT minus Q_MATCHED accuracy, 95% question bootstrap CI','Q_MATCHED and Q_NEUTRAL accuracy and their paired difference','Original guided-minus-control crop oracle stratified by correctness of Q_MATCHED (descriptive, not causal visual-dependence identification)','Original vs E_REPEAT answer/probability concordance'],
'statistics':{'bootstrap_replicates':20000,'seed':2026101801,'unit':'one original question per linked group','multiplicity':'All new analyses exploratory; four model/cohort image-minus-text primary comparisons additionally receive Holm-adjusted paired McNemar p-values.'},
'model_runtime':{'dtype':'bfloat16','attention':'sdpa','training':False,'quantization':False,'seed':2026101801,'cpu_threads':6,'placement':'Full CUDA when sufficient memory; otherwise unchanged BF16 weights partly on CPU with Accelerate, recorded per run. E_REPEAT supplies an internally paired baseline.','minimum_free_device_gib':1.25},
'failure':'Stop on failed inference rather than silently replace or drop cases. Preserve completed records; rerun only incomplete records with unchanged protocol.',
'bindings':{str(R/folder/split/'inputs.jsonl'):sha(R/folder/split/'inputs.jsonl') for folder in ['controlled_replication','curated_replication_2b'] for split in ['pilot','main']}}
assert not (P/'protocol.json').exists()
write(P/'protocol.json',protocol)
print(json.dumps({'status':'FROZEN','sha256':sha(P/'protocol.json')}))
