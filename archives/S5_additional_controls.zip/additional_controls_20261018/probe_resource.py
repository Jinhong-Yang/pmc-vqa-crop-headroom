from inference_common import *
# Technical-only memory probe on an already used pilot item; no reference labels.
torch.set_num_threads(6)
p=AutoProcessor.from_pretrained(MODEL4,local_files_only=True);p.image_processor.size={'shortest_edge':1024,'longest_edge':512**2}
m=Qwen3VLForConditionalGeneration.from_pretrained(MODEL4,local_files_only=True,dtype=torch.bfloat16,attn_implementation='sdpa',device_map={'':'cuda'}).eval()
def memory():return {'allocated':torch.cuda.memory_allocated()/GIB,'reserved':torch.cuda.memory_reserved()/GIB,'free':torch.cuda.mem_get_info()[0]/GIB}
xs=read(R/'controlled_replication/pilot/inputs.jsonl');out=[]
with torch.inference_mode():
 for x in xs[:3]:
  for ims in [image(x['image_path']),None]:
   content=([{'type':'image','image':ims}] if ims else [])+[{'type':'text','text':prompt(x)}]
   b=p.apply_chat_template([{'role':'user','content':content}],tokenize=True,add_generation_prompt=True,return_dict=True,return_tensors='pt').to('cuda')
   tick=time.perf_counter();o=m.model(**b,use_cache=False,return_dict=True);logits=m.lm_head(o.last_hidden_state[:,-1,:])[0].float();ids=[p.tokenizer.encode(c,add_special_tokens=False)[0] for c in 'ABCD'];pr=torch.softmax(logits[ids],0).cpu().tolist();before=memory();del o,logits,b;torch.cuda.empty_cache();rec={'sample_id':x['sample_id'],'image':ims is not None,'seconds':time.perf_counter()-tick,'before':before,'after':memory(),'probabilities':pr};out.append(rec);print(json.dumps(rec),flush=True)
dump(E/'resource_probe.json',out)
