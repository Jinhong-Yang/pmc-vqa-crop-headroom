from inference_common import *
torch.set_num_threads(6)
p=AutoProcessor.from_pretrained(MODEL4,local_files_only=True);p.image_processor.size={'shortest_edge':1024,'longest_edge':512**2}
m=Qwen3VLForConditionalGeneration.from_pretrained(MODEL4,local_files_only=True,dtype=torch.bfloat16,attn_implementation='sdpa',device_map={'':'cpu'}).eval()
from accelerate import cpu_offload
m.model.visual.to('cuda')
for block in m.model.visual.blocks:cpu_offload(block,execution_device=torch.device('cuda'),offload_buffers=True,preload_module_classes=['Qwen3VLVisionBlock'])
for name,child in m.model.language_model.named_children():
 if name!='embed_tokens':child.to('cuda')
for module in [m.model.language_model.embed_tokens,m.lm_head]:
 module.register_forward_pre_hook(lambda mod,args:tuple(v.to('cpu') if torch.is_tensor(v) else v for v in args))
 module.register_forward_hook(lambda mod,args,out:out.to('cuda'))
def memory():return {'allocated':torch.cuda.memory_allocated()/GIB,'reserved':torch.cuda.memory_reserved()/GIB,'free':torch.cuda.mem_get_info()[0]/GIB}
out=[]
with torch.inference_mode():
 for x in read(R/'controlled_replication/pilot/inputs.jsonl')[:8]:
  for ims in [image(x['image_path']),None]:
   content=([{'type':'image','image':ims}] if ims else [])+[{'type':'text','text':prompt(x)}];b=p.apply_chat_template([{'role':'user','content':content}],tokenize=True,add_generation_prompt=True,return_dict=True,return_tensors='pt').to('cuda')
   tick=time.perf_counter();o=m.model(**b,use_cache=False,return_dict=True);logits=m.lm_head(o.last_hidden_state[:,-1,:])[0].float();ids=[p.tokenizer.encode(c,add_special_tokens=False)[0] for c in 'ABCD'];pr=torch.softmax(logits[ids],0).cpu().tolist()
   error=None
   if ims:
    old=json.loads((R/'controlled_replication_4b/pilot/predictions'/(x['sample_id']+'.json')).read_text())['scores']['E'];error=max(abs(a-b) for a,b in zip(pr,old['option_probs']))
   del o,logits,b;torch.cuda.empty_cache();rec={'sample_id':x['sample_id'],'image':ims is not None,'seconds':time.perf_counter()-tick,'memory':memory(),'old_E_probability_error':error};out.append(rec);print(json.dumps(rec),flush=True)
dump(E/'targeted_offload_probe.json',out)
