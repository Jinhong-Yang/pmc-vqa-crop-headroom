from pathlib import Path
import json,collections,re,sys
from PIL import Image
import numpy as np
E=Path(__file__).resolve().parent
allsets={}
for split in ['train','validation','test']:
 rows=json.loads((E/'sources'/f'{split}.json').read_text(encoding='utf-8'))
 rows=[x for x in rows if x['q_lang']=='en'];allsets[split]={x['img_id'] for x in rows}
 selected=[]
 for r in rows:
  q=r['question'].lower()
  if r['base_type']!='vqa' or r['content_type']!='Abnormality' or r['answer'].lower() not in ['yes','no']:continue
  organs=[o for o in ['liver','kidney','spleen','lung','heart','brain'] if o in q]
  if len(organs)!=1:continue
  d=E/'slake/imgs'/Path(r['img_name']).parent
  ann=json.loads((d/'detection.json').read_text())
  matches=[(key,box) for a in ann for key,box in a.items() if organs[0] in key.lower() and not any(s in key.lower() for s in ['cancer','tumor','edema'])]
  if not matches:continue
  selected.append((r['img_id'],r['qid'],q,r['answer'],matches))
 print(split,'english',len(rows),'images',len(allsets[split]),'targeted-binary',len(selected),'images',len({x[0] for x in selected}),'answers',dict(collections.Counter(x[3] for x in selected)),flush=True)
 print(json.dumps(selected[:8],ensure_ascii=True),flush=True)
for a in allsets:
 for b in allsets:
  if a<b:print('shared_images',a,b,len(allsets[a]&allsets[b]))
for d in list((E/'slake/imgs').iterdir())[:3]:
 print('FILES',d.name,[p.name for p in d.iterdir()])
 if (d/'mask.png').exists():
  arr=np.array(Image.open(d/'mask.png'));print('MASK',arr.shape,dict(zip(*[x.tolist() for x in np.unique(arr,return_counts=True)])))
