from inference_common import *
from PIL import ImageDraw
import argparse

def views(x):
 with Image.open(x['image_path']) as im:full=ImageOps.exif_transpose(im).convert('RGB')
 native=full.copy();native.thumbnail((512,512),Image.Resampling.LANCZOS)
 degraded=full.copy();degraded.thumbnail((64,64),Image.Resampling.LANCZOS);degraded=degraded.resize(native.size,Image.Resampling.LANCZOS)
 x0,y0,bw,bh=x['annotation_box_xywh'];sx=native.width/full.width;sy=native.height/full.height
 box=[round(x0*sx),round(y0*sy),round((x0+bw)*sx),round((y0+bh)*sy)]
 for im in [native,degraded]:ImageDraw.Draw(im).rectangle(box,outline=(255,0,0),width=max(2,round(native.width/256)))
 crops={'POSITIVE':full.crop(x['positive_box']).resize((512,512),Image.Resampling.LANCZOS)}
 crops.update({'CONTROL_'+s:full.crop(b).resize((512,512),Image.Resampling.LANCZOS) for s,b in x['control_boxes'].items()})
 return native,degraded,crops

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--model',choices=['2b','4b'],required=True);args=ap.parse_args()
 P=E/'positive_control';protocol=json.loads((P/'protocol.json').read_text(encoding='utf-8'));ph=sha(P/'protocol.json')
 for p,h in protocol['bindings'].items():assert sha(Path(p))==h
 O=P/args.model;O.mkdir(exist_ok=True);lock=E/'gpu.lock'
 with lock.open('x') as f:json.dump({'pid':os.getpid(),'model':args.model,'stage':'positive_control','started':now()},f)
 start=time.perf_counter()
 try:
  scorer=Scorer(args.model);dump(O/'runtime.json',scorer.meta)
  xs=read(P/'pilot/inputs.jsonl');dump(O/'interface.json',scorer.validate(xs[0]))
  for split in ['pilot','main']:
   if split=='main':assert json.loads((O/'pilot_gate.json').read_text())['pass']
   files=[];xs=read(P/split/'inputs.jsonl');count=0
   for i,x in enumerate(xs):
    p=O/split/(x['sample_id']+'.json')
    if p.exists():
     rec=json.loads(p.read_text());assert rec['protocol_sha256']==ph
    else:
     tick=time.perf_counter();native,degraded,crops=views(x);scores={};text=prompt(x)
     pairtext='The first image is the global view. The second image is an additional view of the same figure; it may or may not contain useful detail.\n'+text
     for condition in protocol['conditions']:
      if condition=='Q_MATCHED':ims=None;pt=text
      elif condition=='E_NATIVE':ims=native;pt=text
      elif condition=='E_DEGRADED':ims=degraded;pt=text
      else:
       ims=[degraded if condition.startswith('D_') else native,crops[condition[2:]]];pt=pairtext
      scores[condition]=scorer.score(ims,pt)
     for prefix in ['D','N']:
      assert len({scores[prefix+'_'+key]['image_tokens'] for key in crops})==1
     rec={'sample_id':x['sample_id'],'image_id':x['image_id'],'split':split,'protocol_sha256':ph,'input_sha256':hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest(),'scores':scores,'wall_s':time.perf_counter()-tick,'at':now()}
     dump(p,rec)
    files.append({'path':str(p.relative_to(O)),'sha256':sha(p)});count+=1
    assert torch.cuda.mem_get_info()[0]/GIB>=1.25,'Resource gate; complete records retained'
    if (i+1)%16==0 or i==len(xs)-1:
     state={'model':args.model,'experiment':'positive_control','split':split,'done':i+1,'total':len(xs),'wall_s':time.perf_counter()-start,'at':now()};dump(O/'progress.json',state);print(json.dumps(state),flush=True)
   dump(O/(split+'_seal.json'),{'status':'SEALED_BEFORE_REFERENCE_SCORING','files':files,'protocol_sha256':ph,'at':now()})
   if split=='pilot':dump(O/'pilot_gate.json',{'pass':count==len(xs),'questions':count,'images':len({x['image_id'] for x in xs}),'criterion':'completeness and matched tokens; no efficacy gating','at':now()})
  print('COMPLETE_POSITIVE_CONTROL',args.model,flush=True)
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':main()
