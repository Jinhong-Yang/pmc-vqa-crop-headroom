from inference_common import *
import argparse
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--model',choices=['2b','4b'],required=True);args=ap.parse_args()
 P=E/'no_image';ph=sha(P/'protocol.json');protocol=json.loads((P/'protocol.json').read_text())
 for p,h in protocol['bindings'].items():assert sha(Path(p))==h
 O=P/args.model;O.mkdir(exist_ok=True);lock=E/'gpu.lock'
 with lock.open('x') as f:json.dump({'pid':os.getpid(),'model':args.model,'started':now()},f)
 started=time.perf_counter()
 try:
  scorer=Scorer(args.model);dump(O/'runtime.json',scorer.meta)
  check_x=read(R/'controlled_replication/pilot/inputs.jsonl')[0];dump(O/'interface.json',scorer.validate(check_x))
  for split in ['pilot','main']:
   if split=='main':assert json.loads((O/'pilot_gate.json').read_text())['pass']
   comparisons=[];files=[]
   for cohort,folder in [('primary','controlled_replication'),('curated','curated_replication_2b')]:
    xs=read(R/folder/split/'inputs.jsonl')
    old_folder=folder if args.model=='2b' else ('controlled_replication_4b' if cohort=='primary' else 'curated_replication_4b')
    for i,x in enumerate(xs):
     p=O/split/cohort/(x['sample_id']+'.json')
     if p.exists():
      rec=json.loads(p.read_text(encoding='utf-8'));assert rec['protocol_sha256']==ph
     else:
      tick=time.perf_counter();scores={}
      for condition in protocol['conditions']:
       ims=image(x['image_path']) if condition=='E_REPEAT' else None
       text=prompt(x,condition=='Q_NEUTRAL');scores[condition]=scorer.score(ims,text)
       if condition!='E_REPEAT':assert scores[condition]['image_tokens']==0
      rec={'sample_id':x['sample_id'],'cohort':cohort,'split':split,'protocol_sha256':ph,'input_sha256':hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest(),'scores':scores,'wall_s':time.perf_counter()-tick,'free_gpu_gib':torch.cuda.mem_get_info()[0]/GIB,'at':now()}
      dump(p,rec)
     old=json.loads((R/old_folder/split/'predictions'/(x['sample_id']+'.json')).read_text(encoding='utf-8'))['scores']['E']
     new=rec['scores']['E_REPEAT'];comparisons.append({'same_answer':old['answer']==new['answer'],'max_probability_difference':max(abs(a-b) for a,b in zip(old['option_probs'],new['option_probs']))})
     files.append({'path':str(p.relative_to(O)),'sha256':sha(p)})
     assert torch.cuda.mem_get_info()[0]/GIB>=1.25,'GPU resource gate; retained records for resume'
     if (i+1)%32==0 or i==len(xs)-1:
      progress={'model':args.model,'split':split,'cohort':cohort,'done':i+1,'total':len(xs),'wall_s':time.perf_counter()-started,'at':now()};dump(O/'progress.json',progress);print(json.dumps(progress),flush=True)
   concordance=sum(c['same_answer'] for c in comparisons)/len(comparisons);maxerr=max(c['max_probability_difference'] for c in comparisons)
   dump(O/(split+'_seal.json'),{'status':'SEALED_BEFORE_NEW_REFERENCE_SCORING','files':files,'protocol_sha256':ph,'at':now(),'baseline_answer_concordance':concordance,'max_probability_difference':maxerr})
   if split=='pilot':
    gate={'pass':concordance>=.99 and maxerr<=.02,'n':len(comparisons),'baseline_concordance':concordance,'max_probability_difference':maxerr,'criterion':'technical and reproduction; not efficacy','at':now()};dump(O/'pilot_gate.json',gate);assert gate['pass'],gate
  print('COMPLETE',args.model,flush=True)
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':main()
