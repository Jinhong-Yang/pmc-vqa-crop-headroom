from inference_common import *

def main():
 P=E/'prompt_controls';protocol=json.loads((P/'protocol.json').read_text());ph=sha(P/'protocol.json');O=P/'2b';O.mkdir(exist_ok=True)
 for p,h in protocol['bindings'].items():assert sha(Path(p))==h
 with (E/'gpu.lock').open('x') as f:json.dump({'pid':os.getpid(),'stage':'prompt_controls','started':now()},f)
 try:
  scorer=Scorer('2b');dump(O/'runtime.json',scorer.meta)
  for split in ['pilot','main']:
   if split=='main':assert json.loads((O/'pilot_gate.json').read_text())['pass']
   xs=read(R/'controlled_replication'/split/'inputs.jsonl');files=[];checks=[]
   for i,x in enumerate(xs):
    p=O/split/(x['sample_id']+'.json');old=json.loads((R/'controlled_replication'/split/'predictions'/(x['sample_id']+'.json')).read_text(encoding='utf-8'))
    if p.exists():rec=json.loads(p.read_text());assert rec['protocol_sha256']==ph
    else:
     tick=time.perf_counter()
     with Image.open(x['image_path']) as im:full=ImageOps.exif_transpose(im).convert('RGB')
     base=image(x['image_path']);geom=old['observations']['roi'];size=tuple(geom['rendered_size'])
     crops={'ROI_HIGH_NEUTRAL':full.crop(geom['boxes'][geom['chosen']]).resize(size,Image.Resampling.LANCZOS)}
     crops.update({'ROI_RANDOM_'+s+'_NEUTRAL':full.crop(geom['boxes'][j]).resize(size,Image.Resampling.LANCZOS) for s,j in geom['random_indices'].items()})
     neutral=prompt(x).replace(' The additional observations may be helpful or misleading.','')
     pair='The first image is the global view. The second image is an additional view of the same figure.\n'
     scores={'E_NEUTRAL':scorer.score(base,neutral),'BLANK_MATCHED':scorer.score(Image.new('RGB',base.size,(128,128,128)),prompt(x))}
     scores.update({k:scorer.score([base,c],pair+neutral) for k,c in crops.items()})
     assert len({scores[k]['image_tokens'] for k in crops})==1
     if split=='pilot':
      scores['E_REPEAT']=scorer.score(base,prompt(x))
      scores['ROI_REPEAT']=scorer.score([base,crops['ROI_HIGH_NEUTRAL']],'The first image is the global view. The second image is an additional view of the same figure; it may or may not contain useful detail.\n'+prompt(x))
     rec={'sample_id':x['sample_id'],'protocol_sha256':ph,'split':split,'scores':scores,'at':now(),'wall_s':time.perf_counter()-tick};dump(p,rec)
    if split=='pilot':
     for a,b in [('E_REPEAT','E'),('ROI_REPEAT','ROI_HIGH')]:checks.append({'same':rec['scores'][a]['answer']==old['scores'][b]['answer'],'error':max(abs(u-v) for u,v in zip(rec['scores'][a]['option_probs'],old['scores'][b]['option_probs']))})
    files.append({'path':str(p.relative_to(O)),'sha256':sha(p)})
    assert torch.cuda.mem_get_info()[0]/GIB>=1.25
    if (i+1)%32==0 or i==len(xs)-1:dump(O/'progress.json',{'split':split,'done':i+1,'total':len(xs),'at':now()});print(split,i+1,len(xs),flush=True)
   dump(O/(split+'_seal.json'),{'status':'SEALED_BEFORE_REFERENCE_SCORING','protocol_sha256':ph,'files':files,'at':now()})
   if split=='pilot':
    gate={'pass':all(c['same'] for c in checks) and max(c['error'] for c in checks)<=.02,'n_checks':len(checks),'max_probability_error':max(c['error'] for c in checks),'criterion':'reproduction and geometry only','at':now()};dump(O/'pilot_gate.json',gate);assert gate['pass'],gate
 finally:(E/'gpu.lock').unlink(missing_ok=True)
if __name__=='__main__':main()
