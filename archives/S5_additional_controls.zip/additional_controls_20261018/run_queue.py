from pathlib import Path
import subprocess,time,sys,json,datetime
E=Path(__file__).resolve().parent;PY=Path('D:/Codex Research/MedVQA_SCIE_Local_20261016/.venv/Scripts/python.exe')
log=E/'logs';log.mkdir(exist_ok=True)
print('Waiting for running 2B no-image collection to finish.',flush=True)
while (E/'gpu.lock').exists():time.sleep(5)
assert (E/'no_image/2b/main_seal.json').exists(),'Initial no-image run did not finish.'
for script,model in [('run_assay.py','2b'),('run_no_image.py','4b'),('run_assay.py','4b')]:
 stage='positive_control' if script=='run_assay.py' else 'no_image'
 if (E/stage/model/'main_seal.json').exists():print('ALREADY_SEALED',stage,model,flush=True);continue
 task=f'{script[:-3]}_{model}';print('START',task,flush=True)
 with (log/(task+'.log')).open('a',encoding='utf-8') as f:
  result=subprocess.run([str(PY),'-X','utf8',str(E/script),'--model',model],stdout=f,stderr=subprocess.STDOUT)
 if result.returncode:print('FAILED',task,result.returncode,flush=True);sys.exit(result.returncode)
 print('DONE',task,flush=True)
print('ALL_EXPERIMENTS_COMPLETE',flush=True)
