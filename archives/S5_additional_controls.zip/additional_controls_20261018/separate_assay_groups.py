from pathlib import Path
import json,hashlib,datetime,collections
E=Path(__file__).resolve().parent;P=E/'positive_control'
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines()]
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
audit=json.loads((P/'annotation_audit.json').read_text());groups=audit['groups'];pilotgroups={groups[str(x['image_id'])] for x in read(P/'pilot/inputs.jsonl')}
current=read(P/'main/inputs.jsonl');excluded={x['sample_id'] for x in current if groups[str(x['image_id'])] in pilotgroups}
backup=P/'preflight_before_group_separation';backup.mkdir(exist_ok=False)
for name in ['inputs.jsonl','references.jsonl','annotation_metadata.jsonl']:
 path=P/'main'/name;(backup/name).write_bytes(path.read_bytes());rows=read(path);keep=[r for r in rows if r['sample_id'] not in excluded];path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in keep),encoding='utf-8')
protocol=json.loads((P/'protocol.json').read_text(encoding='utf-8'));(P/'protocol_before_group_separation.json').write_bytes((P/'protocol.json').read_bytes())
at=datetime.datetime.now(datetime.timezone.utc).isoformat();retained=read(P/'main/inputs.jsonl')
protocol['group_separation_amendment']={'at':at,'status':'BEFORE_ANY_ASSAY_MODEL_INFERENCE','reason':'Remove all main images in a perceptual-similarity component containing a technical-pilot image. No outcome or model prediction used.','excluded_questions':len(excluded),'excluded_sample_ids':sorted(excluded),'retained_questions':len(retained),'retained_images':len({x['image_id'] for x in retained}),'retained_similarity_groups':len({groups[str(x['image_id'])] for x in retained})}
protocol['bindings']={str(P/s/'inputs.jsonl'):sha(P/s/'inputs.jsonl') for s in ['pilot','main']};write(P/'protocol.json',protocol)
(P/'annotation_audit_initial.json').write_bytes((P/'annotation_audit.json').read_bytes());audit['final_main_group_separation']=protocol['group_separation_amendment'];audit['main_groups']=protocol['group_separation_amendment']['retained_similarity_groups'];audit['pilot_main_shared_similarity_groups']=0;write(P/'annotation_audit.json',audit)
profile=json.loads((P/'cohort_profile.json').read_text());profile['initial_counts']=profile['counts'].copy();refs=read(P/'main/references.jsonl');meta=read(P/'main/annotation_metadata.jsonl')
profile['counts']['main']={'questions':len(retained),'images':len({x['image_id'] for x in retained}),'similarity_groups':audit['main_groups'],'classes':dict(collections.Counter(x['answer_text'] for x in refs)),'source_splits':dict(collections.Counter(x['source_split'] for x in meta))};profile['pilot_linked_excluded_questions']=len(excluded);write(P/'cohort_profile.json',profile)
print(json.dumps(profile['counts'],ensure_ascii=True))
