"""Independent arithmetic from the released flat table, plus raw-record integrity checks."""
from pathlib import Path
import json,csv,sys,math,hashlib,collections
E=Path(__file__).resolve().parent;R=E.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
J=json.loads((E/'results.json').read_text());P=json.loads((E/'prompt_results.json').read_text());assert J['status']==P['status']=='COMPLETE'
flat=list(csv.DictReader((E/'question_level_results.csv').open(encoding='utf-8-sig')));receipt=[]
def close(a,b):assert abs(a-b)<1e-12,(a,b)
def independent_ci(values,reported,tolerance):
 # Ordinary case resampling; differs from the production unique-value multinomial implementation.
 x=np.asarray(values,float);rng=np.random.default_rng(803171);bs=[]
 for _ in range(100):bs.extend(x[rng.integers(0,len(x),(200,len(x)))].mean(1))
 ci=np.quantile(bs,[.025,.975]);err=max(abs(ci-np.array(reported)));assert err<tolerance,(err,tolerance)
 return {'ci95':ci.tolist(),'max_deviation':float(err)}
for key,v in J['no_image'].items():
 cohort,model=key.split('/');rows=[r for r in flat if r['experiment']=='no_image' and r['model']==model.lower() and r['cohort']==cohort.lower()];assert len(rows)==v['n'];delta=[]
 for cond,a in v['accuracy'].items():close(sum(r[cond+'_answer']==r['reference'] for r in rows)/len(rows),a['estimate'])
 for r in rows:delta.append(int(r['E_REPEAT_answer']==r['reference'])-int(r['Q_MATCHED_answer']==r['reference']))
 close(sum(delta)/len(delta),v['image_minus_matched']['estimate']);assert sum(x==1 for x in delta)==v['image_minus_matched']['improved'];assert sum(x==-1 for x in delta)==v['image_minus_matched']['worsened']
 check=independent_ci(delta,v['image_minus_matched']['ci95'],.0016)
 for status in [False,True]:
  ss=[r for r in rows if (r['Q_MATCHED_answer']==r['reference'])==status];a=v['crop_oracle_by_text_correctness']['text_correct' if status else 'text_error']['contrast'];assert len(ss)==a['n'];close(sum(float(r['original_crop_oracle_delta']) for r in ss)/len(ss),a['estimate'])
 receipt.append({'experiment':key,'n':len(rows),'independent_interval':check})
for model,v in J['positive_control'].items():
 rows=[r for r in flat if r['experiment']=='positive_control' and r['model']==model.lower()];assert len(rows)==114;grouped=collections.defaultdict(list)
 for r in rows:grouped[r['image_id']].append(r)
 assert len(grouped)==82
 classes={r['sample_id']:r['answer_text'] for r in [json.loads(s) for s in (E/'positive_control/main/references.jsonl').read_text().splitlines()]}
 for cl,a in v['class_accuracy'].items():
  subset=[r for r in rows if classes[r['sample_id']]==cl];assert len(subset)==a['questions']
  for setting,pref,base in [('native','N','E_NATIVE'),('degraded','D','E_DEGRADED')]:
   d=[]
   for r in subset:
    e=r[base+'_answer']==r['reference'];g=r[pref+'_POSITIVE_answer']==r['reference'];cs=[r[pref+'_CONTROL_'+str(z)+'_answer']==r['reference'] for z in [1,7,42]];d.append(int(e or g)-sum(int(e or c) for c in cs)/3)
   close(sum(d)/len(d),a['oracle_contrast'][setting])
 for setting,prefix,base in [('native','N','E_NATIVE'),('degraded','D','E_DEGRADED')]:
  vals=[];direct=[]
  for iid,items in sorted(grouped.items()):
   q=[];d=[]
   for r in items:
    e=r[base+'_answer']==r['reference'];p=r[prefix+'_POSITIVE_answer']==r['reference'];cs=[r[prefix+'_CONTROL_'+str(z)+'_answer']==r['reference'] for z in [1,7,42]]
    q.append(int(e or p)-sum(int(e or c) for c in cs)/3);d.append(int(p)-sum(map(int,cs))/3)
   vals.append(sum(q)/len(q));direct.append(sum(d)/len(d))
  a=v['comparisons'][setting];close(sum(vals)/82,a['oracle']['estimate']);close(sum(direct)/82,a['direct']['estimate']);check=independent_ci(vals,a['oracle']['ci95'],.0045)
  labels=json.loads((E/'positive_control/annotation_audit.json').read_text())['groups'];gs=collections.defaultdict(list)
  for iid,value in zip(sorted(grouped),vals):gs[labels[str(iid)]].append(value)
  assert len(gs)==68;cluster_values=list(gs.values());tot=np.array([sum(z) for z in cluster_values]);sizes=np.array([len(z) for z in cluster_values]);idx=np.random.default_rng(803172).integers(0,68,(20000,68));boot=tot[idx].sum(1)/sizes[idx].sum(1);gci=np.quantile(boot,[.025,.975]);assert max(abs(gci-np.array(a['oracle']['cluster_sensitivity']['ci95'])))<.0045
  receipt.append({'experiment':'SLAKE/'+model+'/'+setting,'questions':114,'images':82,'groups':68,'independent_interval':check,'independent_group_ci95':gci.tolist()})
raw_count=0
anatomy=json.loads((E/'anatomy_sensitivity.json').read_text());assert anatomy['status']=='COMPLETE'
eligible={r['sample_id']:r['eligible_seeds'] for r in json.loads((E/'positive_control/control_anatomy_audit.json').read_text())['rows']}
for model,settings in anatomy['models'].items():
 for setting,a in settings.items():
  prefix='N' if setting=='native' else 'D';base='E_NATIVE' if setting=='native' else 'E_DEGRADED';grp=collections.defaultdict(list)
  for r in flat:
   if r['experiment']!='positive_control' or r['model']!=model.lower():continue
   e=r[base+'_answer']==r['reference'];p=r[prefix+'_POSITIVE_answer']==r['reference'];seeds=eligible[r['sample_id']]
   grp[r['image_id']].append(int(e or p)-sum(int(e or r[prefix+'_CONTROL_'+z+'_answer']==r['reference']) for z in seeds)/len(seeds))
  values=[sum(v)/len(v) for v in grp.values()];close(sum(values)/82,a['estimate']);check=independent_ci(values,a['ci95'],.0045)
  receipt.append({'experiment':'SLAKE_same_class/'+model+'/'+setting,'independent_interval':check})
for stage,models,conditions in [('no_image',['2b','4b'],3),('positive_control',['2b','4b'],11),('prompt_controls',['2b'],6)]:
 for m in models:
  for split in ['pilot','main']:
   O=E/stage/m;seal=json.loads((O/(split+'_seal.json')).read_text());expected=8 if stage=='prompt_controls' and split=='pilot' else conditions
   for f in seal['files']:
    p=O/f['path'].replace('\\','/');assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'];r=json.loads(p.read_text());assert len(r['scores'])==expected
    for c,a in r['scores'].items():
     raw_count+=1;assert a['answer'] in 'ABCD' and len(a['answer'])==1;assert all(math.isfinite(x) for x in a['option_probs']);assert abs(sum(a['option_probs'])-1)<1e-5;assert a['answer']=='ABCD'[max(range(4),key=lambda k:a['option_probs'][k])]
     if c.startswith('Q_'):assert a['image_tokens']==0 and 'pixel_values' not in a['input_keys'] and 'image_grid_thw' not in a['input_keys']
    if stage=='positive_control':
     for pref in ['D','N']:assert len({r['scores'][pref+'_'+k]['image_tokens'] for k in ['POSITIVE','CONTROL_1','CONTROL_7','CONTROL_42']})==1
assert raw_count==35310,raw_count
# Neutral prompt effects from raw labels, independently of the production functions.
refs=[json.loads(s) for s in (R/'controlled_replication/main/references.jsonl').read_text(encoding='utf-8').splitlines()];ds=[];db=[]
for r in refs:
 n=json.loads((E/'prompt_controls/2b/main'/(r['sample_id']+'.json')).read_text());o=json.loads((R/'controlled_replication/main/predictions'/(r['sample_id']+'.json')).read_text());gold=r['reference']
 assert n['scores']['BLANK_MATCHED']['image_tokens']==n['scores']['E_NEUTRAL']['image_tokens']==o['scores']['E']['image_tokens']
 for new,original in [('ROI_HIGH_NEUTRAL','ROI_HIGH')]+[('ROI_RANDOM_'+str(z)+'_NEUTRAL','ROI_RANDOM_'+str(z)) for z in [1,7,42]]:
  assert n['scores'][new]['image_tokens']==o['scores'][original]['image_tokens']
 e=n['scores']['E_NEUTRAL']['answer']==gold;g=n['scores']['ROI_HIGH_NEUTRAL']['answer']==gold;cs=[n['scores']['ROI_RANDOM_'+str(z)+'_NEUTRAL']['answer']==gold for z in [1,7,42]];ds.append(int(e or g)-sum(int(e or c) for c in cs)/3);db.append(int(o['scores']['E']['answer']==gold)-int(n['scores']['BLANK_MATCHED']['answer']==gold))
close(sum(ds)/2048,P['neutral_oracle_contrast']['estimate']);close(sum(db)/2048,P['original_image_minus_blank']['estimate']);independent_ci(ds,P['neutral_oracle_contrast']['ci95'],.0016)
result={'status':'PASS','new_experimental_predictions_verified':raw_count,'checks':'Raw seals, options/answers, no image tensors, matched image tokens; independently recomputed accuracies/paired counts/strata/image-weighted contrasts and ordinary-case bootstrap with distinct seed; neutral controls independently derived from raw responses.','comparisons':receipt,'independent_bootstrap_tolerances_pp':{'PMC':.16,'SLAKE':.45}}
(E/'verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({'status':'PASS','predictions':raw_count,'independently_checked_comparisons':len(receipt)}))
