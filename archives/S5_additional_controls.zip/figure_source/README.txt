After extracting S2–S5 together, install NumPy, Matplotlib and Pillow,
and make an Arial font installation available to Matplotlib. Then run:
python figure_source/build_figures.py
PNG, EPS and 400 dpi RGB TIFF figures are written to figure_source/figures.
All numerical inputs are the released result files; no source-image pixels are
used in the figures. The script requires Arial to prevent silent font substitution.
