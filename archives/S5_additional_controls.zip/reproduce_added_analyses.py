"""Run from the directory into which S2--S5 are extracted. No network/GPU needed.
Creates a new rerun_controls directory. Requires NumPy and SciPy.
"""
from pathlib import Path
import shutil,subprocess,sys,json,hashlib
root=Path(__file__).resolve().parent;work=root/'rerun_controls';assert not work.exists(),'Choose a fresh extraction directory or preserve/rename the existing rerun_controls directory.'
extra=root/'additional_controls_20261018';bundle=root/'reproducibility_bundle'
shutil.copytree(extra,work/'additional_controls_20261018')
for folder in ['controlled_replication','controlled_replication_4b','curated_replication_2b','curated_replication_4b']:
 target=work/folder/'main';target.mkdir(parents=True)
 shutil.copy2(bundle/'run_evidence'/(folder+'__main')/'references.jsonl',target/'references.jsonl')
 shutil.copytree(bundle/'raw_predictions'/(folder+'__main'),target/'predictions')
(work/'presubmission_20261018').mkdir();shutil.copy2(root/'presubmission_20261018/additional_results.json',work/'presubmission_20261018/additional_results.json')
for script in ['analyze_controls.py','analyze_prompt_controls.py','analyze_review_diagnostics.py','analyze_anatomy_sensitivity.py','verify_controls.py']:
 subprocess.run([sys.executable,'-X','utf8',str(work/'additional_controls_20261018'/script)],check=True)
print('Completed numerical reanalysis and independent verification in',work)
