19 October 2026 complete-grid numerical supplement
Extract S2--S7 together into one new directory.
The earlier S2--S5 archives are byte-identical numerical/provenance records.
The current main manuscript and S1 File govern interpretation and supersede
earlier prose in archival records. S6 contains new methods, analyses, raw 2B
window records and the outcome matrix; S7 contains raw 4B window records.

CPU REANALYSIS (Python 3.11+, NumPy and SciPy; no GPU/network/source images):
python window_audit_20261019/analyze_windows.py
python window_audit_20261019/review_checks.py
python window_audit_20261019/verify_windows.py

FIGURES (add Matplotlib, Pillow and Arial fonts):
python revision_figures/build_figures.py
All five plots are rebuilt from the numerical release. No source image pixels
appear in the publication figures.

INFERENCE
The run script and protocol preserve executed local paths and exact original
crop geometry. Acquire upstream data/model revisions identified in S1, adapt
paths in a separate copy, and create a new protocol; do not overwrite frozen
records. Reused windows are identified by their original condition and source
SHA256. Only missing windows were newly inferred. Labels were used after seals
to compute reference-assisted diagnostics, never as query answers in inference.
The ideal-window result uses nine evaluations and reference labels. It is not
an executable same-cost policy. Technical checks are counted separately.

RIGHTS
No upstream PMC-VQA question or choice text, model weights, or source images are
included. Source reconstruction and licence notes remain in S2. SLAKE task
questions are study-defined from its CC BY 4.0 annotations.
