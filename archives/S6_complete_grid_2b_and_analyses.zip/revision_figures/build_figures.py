from pathlib import Path
import sys,json
V=Path(__file__).resolve().parent;R=V.parent;E=R/'additional_controls_20261018';sys.path.insert(0,str(R/'dependencies'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Rectangle
from matplotlib import font_manager
from PIL import Image
for font in ['C:/Windows/Fonts/arial.ttf','C:/Windows/Fonts/arialbd.ttf']:
 if Path(font).exists():font_manager.fontManager.addfont(font)
font_manager.findfont(font_manager.FontProperties(family='Arial'),fallback_to_default=False)
plt.rcParams.update({'font.family':'Arial','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','ps.fonttype':42,'pdf.fonttype':42,'savefig.facecolor':'white'})
teal='#007F89';orange='#C56321';gray='#727A85';blue='#3966A3';F=V/'figures'
F.mkdir(parents=True,exist_ok=True)
def save(fig,n):
 for ext in ['png','eps']:fig.savefig(F/f'Fig{n}.{ext}',dpi=400,bbox_inches='tight')
 with Image.open(F/f'Fig{n}.png') as im:im.convert('RGB').save(F/f'Fig{n}.tif',compression='tiff_lzw',dpi=(400,400))
 plt.close(fig)
fig=plt.figure(figsize=(7,6.4));ax=fig.add_axes([0,0,1,1]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
ax.text(.01,.98,'A  Evaluation sequence',weight='bold',size=11,va='top')
def box(x,y,w,h,text):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012',facecolor='#EDF4F5',edgecolor=teal));ax.text(x+w/2,y+h/2,text,ha='center',va='center',size=8.5)
box(.02,.76,.27,.15,'Historical discovery\n1,350 questions\n21,600 predictions')
box(.365,.76,.27,.15,'Technical pilots\n128 primary + 64 curated\nBoth model sizes')
box(.71,.76,.27,.15,'Original main evaluation\n2,048 primary + 825 curated\n2 models × 11 conditions')
for x,y in [(.30,.835),(.645,.835)]:ax.annotate('',(x+.055,y),(x,y),arrowprops={'arrowstyle':'->','lw':1.3})
ax.text(.02,.68,'Additional exploratory controls: frozen before their own inference',weight='bold',size=9)
box(.02,.46,.45,.17,'PMC-VQA: same main questions\nBoth models: image repeat + two no-image prompts\nPrimary 2B: blank image + neutral crop wording\nAll nine windows completed in both models\nOriginal pilot questions remain excluded')
box(.53,.46,.45,.17,'SLAKE annotation-defined recognition\nPilot: 50 questions / 32 images\nMain: 114 questions / 82 images / 68 groups\nNative and degraded global views')
ax.text(.02,.39,'B  Fixed crop geometry',weight='bold',size=11)
gx,gy,gw=.05,.055,.29
for j in range(9):
 x=(j%3)*.25;y=(j//3)*.25;ax.add_patch(Rectangle((gx+x*gw,gy+(1-y-.5)*gw),.5*gw,.5*gw,fill=False,edgecolor='#B8B8B8',lw=.7));ax.text(gx+(x+.02)*gw,gy+(1-y-.08)*gw,str(j),size=8)
for j,color,ls in [(6,teal,'-'),(0,orange,'--'),(3,orange,'--'),(8,orange,'--')]:
 x=(j%3)*.25;y=(j//3)*.25;ax.add_patch(Rectangle((gx+x*gw,gy+(1-y-.5)*gw),.5*gw,.5*gw,fill=False,edgecolor=color,lw=1.5,linestyle=ls))
ax.text(.43,.29,'Selected window: 6\nControl seeds 1, 7, 42: windows 0, 3, 8',size=9,va='top')
ax.text(.43,.17,'Every crop is paired with the same global image.\nAdditional-view dimensions and tokens are matched.\nDiagram contains no biomedical source-image pixels.',size=8.5,va='top')
save(fig,1)
d=json.loads((E/'review_diagnostics.json').read_text());labels=list(d['runs'])
fig,ax=plt.subplots(figsize=(7,3.5));x=np.arange(4);width=.2
for j,(k,label,color) in enumerate([('ROI_HIGH','Guided crop',teal),('CONTROL_MEAN','Non-selected crop mean',orange),('ROI_DUPLICATE','Duplicate global view',gray)]):
 vals=[d['runs'][l]['headroom'][k] for l in labels];m=np.array([v['estimate']*100 for v in vals]);ci=np.array([v['ci95'] for v in vals])*100
 ax.bar(x+(j-1)*width,m,width*.9,color=color,label=label);ax.errorbar(x+(j-1)*width,m,yerr=np.array([m-ci[:,0],ci[:,1]-m]),fmt='none',ecolor='#222222',capsize=2,lw=.8)
ax.set_xticks(x,labels);ax.set_ylabel('Oracle headroom (percentage points)');ax.set_ylim(0,8.5);ax.legend(frameon=False,ncol=3,fontsize=8,loc='upper center');fig.tight_layout();save(fig,3)
old=json.loads((R/'presubmission_20261018/additional_results.json').read_text())
fig,ax=plt.subplots(figsize=(7,3.8));ax.axvspan(-2,2,color='#F0F4F5');ax.axvline(0,color='#555555',lw=.8);ys=np.arange(4)[::-1]
for i,label in enumerate(labels):
 folder=['controlled_replication','controlled_replication_4b','curated_replication_2b','curated_replication_4b'][i];a=json.loads((R/'reproducibility_bundle/reported_results'/(folder+'__main.json')).read_text());v=next(v for v in a['oracle_contrasts'] if v['comparison']=='roi');b=old['runs'][label]['crop_overlap']['nonoverlap_oracle_contrast']
 for shift,t,c,nm in [(.11,{'estimate':v['difference'],'ci95':v['ci'],'n':v['n']},teal,'All controls'),(-.11,b,orange,'Zero overlap')]:
  m=t['estimate']*100;lo,hi=np.array(t['ci95'])*100;ax.errorbar(m,ys[i]+shift,xerr=[[m-lo],[hi-m]],fmt='o',color=c,capsize=3,label=nm if i==0 else None);ax.text(2.7,ys[i]+shift,f"n = {t['n']:,}",va='center',size=8)
ax.set_yticks(ys,labels);ax.set_xlim(-2.8,4);ax.set_xlabel('Guided − mean control oracle (percentage points)');ax.legend(frameon=False,ncol=2,loc='upper center',bbox_to_anchor=(.5,1.18));fig.tight_layout();save(fig,4)
if '--partial' in sys.argv:sys.exit()
j=json.loads((E/'results.json').read_text());assert j['status']=='COMPLETE'
fig,(a,b)=plt.subplots(1,2,figsize=(7,3.8),gridspec_kw={'width_ratios':[1,1.05]})
for ax in [a,b]:ax.axvline(0,color='#777777',lw=.8)
for i,l in enumerate(labels):
 t=j['no_image'][l]['image_minus_matched'];m=t['estimate']*100;lo,hi=np.array(t['ci95'])*100;a.errorbar(m,3-i,xerr=[[m-lo],[hi-m]],fmt='o',color=teal,capsize=3)
a.set_yticks(range(4),labels[::-1]);a.set_xlabel('Image − no image (pp)');a.set_title('A  PMC-VQA image contribution',loc='left',weight='bold',size=9);a.set_ylim(-.6,3.6)
labs=[]
for i,(model,setting) in enumerate([('2B','native'),('2B','degraded'),('4B','native'),('4B','degraded')]):
 t=j['positive_control'][model]['comparisons'][setting]['oracle'];m=t['estimate']*100;lo,hi=np.array(t['ci95'])*100;b.errorbar(m,3-i,xerr=[[m-lo],[hi-m]],fmt='o',color=orange if setting=='degraded' else blue,capsize=3);labs.append(model+' / '+setting)
b.set_yticks(range(4),labs[::-1]);b.set_xlabel('Annotated − control oracle (pp)');b.set_title('B  SLAKE region task',loc='left',weight='bold',size=9);b.set_ylim(-.6,3.6)
fig.tight_layout(w_pad=2);save(fig,5)

n=json.loads((R/'window_audit_20261019/results.json').read_text());assert n['status']=='COMPLETE'
fig,ax=plt.subplots(figsize=(7,4.3));ys=np.arange(4)[::-1]
colors=['#727A85','#007F89','#C56321','#774A95']
keys=['baseline','selected_pair_oracle','uniform_pair_oracle','best_window_pair_oracle']
names=['Baseline only','Selected-pair oracle','Uniform-pair oracle','Best-window oracle']
for offset,k,name,color in zip([.24,.08,-.08,-.24],keys,names,colors):
 for i,label in enumerate(labels):
  v=n['runs'][label][k];m=v['estimate']*100;lo,hi=np.array(v['ci95'])*100
  ax.errorbar(m,ys[i]+offset,xerr=[[m-lo],[hi-m]],fmt='o',color=color,capsize=2.5,label=name if i==0 else None)
ax.set_yticks(ys,labels);ax.set_ylim(-.6,3.6);ax.set_xlabel('Correct-answer coverage (%)')
ax.legend(frameon=False,ncol=2,fontsize=8,loc='upper center',bbox_to_anchor=(.5,1.20))
fig.tight_layout();save(fig,2)
