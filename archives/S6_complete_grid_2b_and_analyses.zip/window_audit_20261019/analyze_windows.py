from pathlib import Path
import json,sys,hashlib,csv,datetime
E=Path(__file__).resolve().parent;R=E.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
def jl(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources(folder):
 if (R/folder/'main/references.jsonl').exists():return R/folder/'main/references.jsonl',R/folder/'main/predictions'
 return R/'reproducibility_bundle/run_evidence'/(folder+'__main')/'references.jsonl',R/'reproducibility_bundle/raw_predictions'/(folder+'__main')
def boot(x):
 x=np.asarray(x,float);u,c=np.unique(x,return_counts=True);b=np.random.default_rng(2026101901).multinomial(len(x),c/len(x),20000)@u/len(x)
 return {'n':len(x),'estimate':float(x.mean()),'ci95':np.quantile(b,[.025,.975]).tolist()}
out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETE','role':'Exploratory reference-assisted diagnostic, not an executable selection policy. Nine windows are searched using labels; each best-window/baseline final pair has two candidates.','runs':{},'counts':{}};flat=[]
for model in ['2b','4b']:
 O=E/model
 if not (O/'main_seal.json').exists():out['status']='PARTIAL';continue
 for split in ['pilot','main']:
  seal=json.loads((O/(split+'_seal.json')).read_text());out['counts'][model+'/'+split]={k:seal[k] for k in ['new_grid_predictions','reused_grid_predictions','technical_repeat_predictions']}
  for f in seal['files']:assert sha(O/f['path'])==f['sha256']
 for cohort,folder in [('primary','controlled_replication' if model=='2b' else 'controlled_replication_4b'),('curated','curated_replication_2b' if model=='2b' else 'curated_replication_4b')]:
  reference_path,prediction_path=sources(folder);refs=jl(reference_path);records=[json.loads((O/'main'/cohort/(r['sample_id']+'.json')).read_text()) for r in refs];old=[json.loads((prediction_path/(r['sample_id']+'.json')).read_text()) for r in refs]
  e=np.array([r['baseline']['answer']==g['reference'] for r,g in zip(records,refs)],float);c=np.array([[r['scores'][str(j)]['answer']==g['reference'] for j in range(9)] for r,g in zip(records,refs)],float);g=np.array([c[i,int(r['selected_window'])] for i,r in enumerate(records)]);d=np.array([r['scores']['ROI_DUPLICATE']['answer']==y['reference'] for r,y in zip(old,refs)],float)
  best=c.max(1);uniform=c.mean(1);pairbest=np.maximum(e,best);pairuni=np.maximum(e[:,None],c).mean(1);pairg=np.maximum(e,g);pairdup=np.maximum(e,d);resc=(1-e)*best;gr=(1-e)*g
  label=cohort.title()+'/'+model.upper();v={'n':len(e),'baseline':boot(e),'selected_direct':boot(g),'uniform_direct':boot(uniform),'best_window_direct':boot(best),'selected_pair_oracle':boot(pairg),'uniform_pair_oracle':boot(pairuni),'best_window_pair_oracle':boot(pairbest),'best_minus_uniform_pair':boot(pairbest-pairuni),'best_minus_selected_pair':boot(pairbest-pairg),'selected_minus_uniform_pair':boot(pairg-pairuni),'best_minus_uniform_direct':boot(best-uniform),'selected_minus_duplicate_pair':boot(pairg-pairdup),'uniform_minus_duplicate_pair':boot(pairuni-pairdup),'available_rescues':int(resc.sum()),'selected_rescues':int(gr.sum()),'captured_rescue_fraction':float(gr.sum()/resc.sum()) if resc.sum() else None,'correct_window_counts':{str(j):int((c.sum(1)==j).sum()) for j in range(10)}}
  out['runs'][label]=v
  ranks=[]
  for i,r in enumerate(records):
   similarities=old[i]['observations']['roi']['scores'];order=sorted(range(9),key=lambda k:(-similarities[k],k));assert order[0]==r['selected_window'];rank=next((k+1 for k,jj in enumerate(order) if c[i,jj]),0);ranks.append(rank)
   flat.append({'cohort':cohort,'model':model,'sample_id':r['sample_id'],'reference':refs[i]['reference'],'baseline':int(e[i]),'selected_window':r['selected_window'],**{'window_'+str(j):int(c[i,j]) for j in range(9)},**{'siglip_score_'+str(j):similarities[j] for j in range(9)},'first_correct_rank':rank,'best_minus_uniform_pair':float(pairbest[i]-pairuni[i]),'best_minus_selected_pair':float(pairbest[i]-pairg[i])})
  v['first_correct_rank_on_baseline_errors']={str(k):sum(not bool(e[i]) and r==k for i,r in enumerate(ranks)) for k in range(10)}
  assert sum(v['first_correct_rank_on_baseline_errors'][str(k)] for k in range(1,10))==v['available_rescues']
  assert v['first_correct_rank_on_baseline_errors']['1']==v['selected_rescues']
(E/'results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
if flat:
 with (E/'window_outcomes.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
print(json.dumps({'status':out['status'],'runs':{k:{z:v[z] for z in ['n','best_minus_uniform_pair','best_minus_selected_pair','captured_rescue_fraction']} for k,v in out['runs'].items()}},indent=2))
