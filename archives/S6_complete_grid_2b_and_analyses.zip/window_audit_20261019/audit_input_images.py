"""Check every used local image against the original frozen source metadata."""
from pathlib import Path
import json,hashlib,datetime
E=Path(__file__).resolve().parent;R=E.parent;cache={};rows=[];bindings={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def jl(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
for folder in ['controlled_replication','controlled_replication_4b','curated_replication_2b','curated_replication_4b']:
 for split in ['pilot','main']:
  P=R/folder/split;metadata={r['sample_id']:r for r in jl(P/'metadata.jsonl')};bindings[folder+'/'+split+'/metadata.jsonl']=sha(P/'metadata.jsonl')
  for r in jl(P/'inputs.jsonl'):
   p=Path(r['image_path']);key=str(p.resolve());expected=metadata[r['sample_id']]['image_sha256']
   if key not in cache:cache[key]=sha(p)
   assert cache[key]==expected,(folder,split,r['sample_id'])
   rows.append({'folder':folder,'split':split,'sample_id':r['sample_id'],'image_sha256':cache[key]})
assert len(rows)==6130,len(rows)
result={'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':len(rows),'unique_image_paths':len(cache),'metadata_bindings_original':bindings,'scope':'Actual on-disk image bytes used by the grid run match the original frozen source hashes. This audit requires acquired source images and is distinct from CPU-only numerical reanalysis.','rows':rows}
(E/'input_image_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ['rows','metadata_bindings_original']},indent=2))
