import os
os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false';os.environ['PYTHONDONTWRITEBYTECODE']='1'
from pathlib import Path
import sys,time,json,hashlib,datetime
sys.dont_write_bytecode=True
import torch,numpy as np
from PIL import Image,ImageOps
from transformers import AutoProcessor,Qwen3VLForConditionalGeneration
E=Path(__file__).resolve().parent;R=E.parent
MODEL2=Path('D:/Codex Research/MedVQA_SCIE_Local_20261016/models/Qwen3-VL-2B-Instruct')
MODEL4=R/'models/Qwen3-VL-4B-Instruct'
GIB=1024**3
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def dump(p,x):
 p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');t.replace(p)
def image(p,edge=512):
 with Image.open(p) as im:im=ImageOps.exif_transpose(im).convert('RGB');im.thumbnail((edge,edge),Image.Resampling.LANCZOS);return im
def prompt(x,neutral=False):
 start='Answer the multiple-choice question.' if neutral else 'Answer the multiple-choice question using the image. The additional observations may be helpful or misleading.'
 labels='ABCD'[:len(x['options'])]
 return start+'\n'+x['question']+'\n'+'\n'.join(f'{a}: {s}' for a,s in zip(labels,x['options']))+'\nRespond with exactly one of '+', '.join(labels)+'.\nAnswer:'
class Scorer:
 def __init__(self,size):
  torch.set_num_threads(6);torch.set_num_interop_threads(2);torch.manual_seed(2026101801);np.random.seed(2026101801)
  path=MODEL2 if size=='2b' else MODEL4
  self.proc=AutoProcessor.from_pretrained(path,local_files_only=True)
  self.proc.image_processor.size={'shortest_edge':1024,'longest_edge':512**2}
  free=torch.cuda.mem_get_info()[0]/GIB
  needed=6.0 if size=='2b' else 10.0
  self.targeted_offload=size=='4b' and (free<10.0 or os.environ.get('WINDOW_FORCE_OFFLOAD')=='1')
  if self.targeted_offload:kw={'device_map':{'':'cpu'}}
  elif free>=needed:kw={'device_map':{'':'cuda'}}
  else:
   budget=max(2.5,min(4.0,free-3.0));kw={'device_map':'auto','max_memory':{0:int(budget*GIB),'cpu':24*GIB},'offload_folder':str(E/'offload')}
  self.model=Qwen3VLForConditionalGeneration.from_pretrained(path,local_files_only=True,dtype=torch.bfloat16,attn_implementation='sdpa',**kw).eval();self.model.requires_grad_(False)
  if self.targeted_offload:
   from accelerate import cpu_offload
   self.model.model.visual.to('cuda')
   for block in self.model.model.visual.blocks:cpu_offload(block,execution_device=torch.device('cuda'),offload_buffers=True,preload_module_classes=['Qwen3VLVisionBlock'])
   for name,child in self.model.model.language_model.named_children():
    if name!='embed_tokens':child.to('cuda')
   for module in [self.model.model.language_model.embed_tokens,self.model.lm_head]:
    module.register_forward_pre_hook(lambda mod,args:tuple(v.to('cpu') if torch.is_tensor(v) else v for v in args))
    module.register_forward_hook(lambda mod,args,out:out.to('cuda'))
   self.model.hf_device_map={'language_layers':'cuda','vision_blocks':'CPU storage, CUDA execution','vision_other':'cuda','tied_embedding_and_lm_head':'cpu'}
   torch.cuda.empty_cache()
  ids=[self.proc.tokenizer.encode(c,add_special_tokens=False) for c in 'ABCD'];assert all(len(x)==1 for x in ids)
  self.ids=[x[0] for x in ids]
  self.device=torch.device('cuda') if self.targeted_offload else next(self.model.parameters()).device
  self.meta={'model':str(path),'dtype':'bfloat16','device_map':{k:str(v) for k,v in self.model.hf_device_map.items()},'torch':torch.__version__,'transformers':__import__('transformers').__version__,'initial_free_gib':free,'at':now()}
 def inputs(self,images,text):
  ims=[] if images is None else images if isinstance(images,list) else [images]
  content=[{'type':'image','image':im} for im in ims]+[{'type':'text','text':text}]
  b=self.proc.apply_chat_template([{'role':'user','content':content}],tokenize=True,add_generation_prompt=True,return_dict=True,return_tensors='pt')
  g=b.get('image_grid_thw');n=b['input_ids'].shape[-1]
  assert n+1<=3072
  info={'context_tokens':int(n),'image_tokens':int(g.prod(-1).sum()//4) if g is not None else 0,'input_keys':list(b.keys())}
  if not ims:assert g is None and 'pixel_values' not in b
  return b.to(self.device),info
 @torch.inference_mode()
 def score(self,images,text,labels=4,official=False):
  b,info=self.inputs(images,text)
  if official:logits=self.model(**b,use_cache=False,logits_to_keep=1,return_dict=True).logits[0,-1].float()
  else:
   output=self.model.model(**b,use_cache=False,return_dict=True)
   logits=self.model.lm_head(output.last_hidden_state[:,-1,:])[0].float()
  lp=torch.log_softmax(logits,-1)[self.ids[:labels]];prob=torch.softmax(lp,-1).cpu().tolist()
  assert all(np.isfinite(prob)) and abs(sum(prob)-1)<1e-5
  result={'answer':'ABCD'[int(torch.argmax(lp))],'option_probs':prob,'option_log_probs':lp.cpu().tolist(),**info}
  if self.targeted_offload:
   del logits,lp,b
   if not official:del output
   torch.cuda.empty_cache()
  return result
 def validate(self,x):
  checks=[]
  for ims in [None,image(x['image_path'])]:
   a=self.score(ims,prompt(x),len(x['options']));b=self.score(ims,prompt(x),len(x['options']),True)
   err=max(abs(i-j) for i,j in zip(a['option_log_probs'],b['option_log_probs']));assert err<1e-4
   checks.append({'image_present':ims is not None,'max_logprob_error':err})
  return checks
