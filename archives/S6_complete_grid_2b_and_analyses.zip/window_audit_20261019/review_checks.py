"""Targeted reanalysis of earlier sealed records requested by the new critique."""
from pathlib import Path
import json,sys,collections,hashlib
E=Path(__file__).resolve().parent;R=E.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
def jl(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def boot(x,seed=2026101902):
 x=np.asarray(x,float);u,c=np.unique(x,return_counts=True);b=np.random.default_rng(seed).multinomial(len(x),c/len(x),20000)@u/len(x)
 return {'n':len(x),'estimate':float(x.mean()),'ci95':np.quantile(b,[.025,.975]).tolist()}
out={'status':'COMPLETE','analysis_role':'Post-outcome checks; exploratory unadjusted intervals.','PMC':{},'SLAKE':{}}
for folder,label in [('controlled_replication','Primary/2B'),('controlled_replication_4b','Primary/4B'),('curated_replication_2b','Curated/2B'),('curated_replication_4b','Curated/4B')]:
 base=R/folder/'main';rp=base/'references.jsonl';pp=base/'predictions'
 if not rp.exists():rp=R/'reproducibility_bundle/run_evidence'/(folder+'__main')/'references.jsonl';pp=R/'reproducibility_bundle/raw_predictions'/(folder+'__main')
 refs=jl(rp);rows=[json.loads((pp/(r['sample_id']+'.json')).read_text()) for r in refs]
 C={k:np.array([a['scores'][k]['answer']==b['reference'] for a,b in zip(rows,refs)],float) for k in rows[0]['scores']};B=C['E'];G=C['ROI_HIGH'];D=C['ROI_DUPLICATE'];controls=np.array([C['ROI_RANDOM_'+str(s)] for s in [1,7,42]]).T
 def correction(k):
  rescue=int(((1-B)*C[k]).sum());wf=sum(a['scores']['E']['answer']!=b['reference'] and a['scores'][k]['answer']!=a['scores']['E']['answer'] for a,b in zip(rows,refs));return {'rescues':rescue,'wrong_flips':wf,'rate':rescue/wf}
 c=[correction('ROI_RANDOM_'+str(s)) for s in [1,7,42]]
 out['PMC'][label]={'guided_correction':correction('ROI_HIGH'),'seed_controls':c,'pooled_control_correction':sum(a['rescues'] for a in c)/sum(a['wrong_flips'] for a in c),'mean_seed_correction':float(np.mean([a['rate'] for a in c])),'guided_minus_duplicate_oracle':boot(np.maximum(B,G)-np.maximum(B,D)),'mean_control_minus_duplicate_oracle':boot(np.maximum(B[:,None],controls).mean(1)-np.maximum(B,D))}
P=R/'additional_controls_20261018/positive_control';refs=jl(P/'main/references.jsonl');audit=json.loads((P/'control_anatomy_audit.json').read_text());meta={r['sample_id']:r for r in audit['rows']};groups=json.loads((P/'annotation_audit.json').read_text())['groups']
for model in ['2b','4b']:
 rows=[json.loads((P/model/'main'/(r['sample_id']+'.json')).read_text()) for r in refs];C={k:np.array([a['scores'][k]['answer']==b['reference'] for a,b in zip(rows,refs)],float) for k in rows[0]['scores']};v={}
 for setting,pref,base in [('native','N','E_NATIVE'),('degraded','D','E_DEGRADED')]:
  b=C[base];p=C[pref+'_POSITIVE'];c=np.array([C[pref+'_CONTROL_'+str(s)] for s in [1,7,42]]).T;effects=np.maximum(b,p)-np.maximum(b[:,None],c).mean(1)
  kept=[i for i,r in enumerate(refs) if r['answer_text']!='Liver'];byimage=collections.defaultdict(list)
  for i in kept:byimage[refs[i]['image_id']].append(float(effects[i]))
  ids=sorted(byimage);values=np.array([np.mean(byimage[i]) for i in ids]);result=boot(values);result.update(questions=len(kept),images=len(ids))
  labs=sorted({groups[str(i)] for i in ids});sums=np.array([sum(v for i,v in zip(ids,values) if groups[str(i)]==g) for g in labs]);ns=np.array([sum(groups[str(i)]==g for i in ids) for g in labs]);w=np.random.default_rng(2026101902).multinomial(len(labs),np.full(len(labs),1/len(labs)),20000);result['group_ci95']=np.quantile(w@sums/(w@ns),[.025,.975]).tolist();result['groups']=len(labs)
  affected=[]
  for i,r in enumerate(refs):
   seeds=meta[r['sample_id']]['eligible_seeds']
   if len(seeds)==3:continue
   all_values={str(s):int(b[i] or C[pref+'_CONTROL_'+str(s)][i]) for s in [1,7,42]};direct={str(s):int(C[pref+'_CONTROL_'+str(s)][i]) for s in [1,7,42]}
   delta=sum(all_values[s] for s in seeds)/len(seeds)-sum(all_values.values())/3
   assert abs(delta)<1e-12
   affected.append({'sample_id':r['sample_id'],'eligible_seeds':seeds,'control_correctness':direct,'baseline_or_control_correctness':all_values,'paired_oracle_control_change':delta})
  spleen=[i for i,r in enumerate(refs) if r['answer_text']=='Spleen'];pos_harm=[refs[i]['sample_id'] for i in range(len(refs)) if b[i] and not p[i]]
  v[setting]={'without_liver_oracle':result,'positive_harm_questions':len(pos_harm),'positive_harm_ids':pos_harm,'spleen_baseline_correct':int(b[spleen].sum()),'spleen_positive_correct':int(p[spleen].sum()),'spleen_questions':len(spleen),'same_class_exclusion_affected_rows':affected}
 out['SLAKE'][model.upper()]=v
(E/'review_checks.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({'PMC':out['PMC'],'SLAKE':{m:{s:{'without_liver':v['without_liver_oracle'],'positive_harm':v['positive_harm_questions'],'spleen_counts':[v['spleen_baseline_correct'],v['spleen_positive_correct']]} for s,v in settings.items()} for m,settings in out['SLAKE'].items()}},indent=2))
