"""Complete a fixed nine-window grid, reusing identical sealed predictions."""
from inference_common import *

COHORTS={'primary':('controlled_replication','controlled_replication_4b'),'curated':('curated_replication_2b','curated_replication_4b')}
PAIR='The first image is the global view. The second image is an additional view of the same figure; it may or may not contain useful detail.\n'

def reused(old):
 g=old['observations']['roi'];mapping={int(g['chosen']):'ROI_HIGH'}
 for seed,j in g['random_indices'].items():
  condition='ROI_RANDOM_'+seed
  if int(j) in mapping:
   a,b=old['scores'][mapping[int(j)]],old['scores'][condition]
   assert a['answer']==b['answer'] and max(abs(x-y) for x,y in zip(a['option_probs'],b['option_probs']))<1e-7
  else:mapping[int(j)]=condition
 return mapping

def main():
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--model',choices=['2b','4b'],required=True);args=parser.parse_args()
 p=json.loads((E/'protocol.json').read_text());ph=sha(E/'protocol.json')
 for rel,h in p['code_bindings'].items():assert sha(E/rel)==h
 O=E/args.model;O.mkdir(exist_ok=True)
 with (E/'gpu.lock').open('x') as f:json.dump({'pid':os.getpid(),'stage':'all_windows','at':now()},f)
 try:
  scorer=Scorer(args.model);dump(O/'runtime.json',scorer.meta)
  for split in ['pilot','main']:
   if split=='main':assert json.loads((O/'pilot_gate.json').read_text())['pass']
   files=[];repeats=[];new_count=0;reuse_count=0;done=0
   for cohort,folders in COHORTS.items():
    folder=folders[0 if args.model=='2b' else 1];xs=read(R/folder/split/'inputs.jsonl')
    assert sha(R/folder/split/'inputs.jsonl')==p['source_bindings'][folder+'/'+split+'/inputs.jsonl']
    original_seal=json.loads((R/folder/split/'prediction_seal.json').read_text())
    hashes={Path(f['path']).name:f['sha256'] for f in original_seal['files']}
    for i,x in enumerate(xs):
     target=O/split/cohort/(x['sample_id']+'.json');source=R/folder/split/'predictions'/(x['sample_id']+'.json')
     assert sha(source)==hashes[source.name]
     old=json.loads(source.read_text(encoding='utf-8'));mapping=reused(old)
     if target.exists():
      rec=json.loads(target.read_text(encoding='utf-8'));assert rec['protocol_sha256']==ph
     else:
      tick=time.perf_counter();base=image(x['image_path']);geom=old['observations']['roi'];size=tuple(geom['rendered_size'])
      with Image.open(x['image_path']) as im:full=ImageOps.exif_transpose(im).convert('RGB')
      scores={str(j):old['scores'][condition] for j,condition in mapping.items()};origin={str(j):condition for j,condition in mapping.items()}
      for j in range(9):
       if str(j) in scores:continue
       crop=full.crop(geom['boxes'][j]).resize(size,Image.Resampling.LANCZOS)
       scores[str(j)]=scorer.score([base,crop],PAIR+prompt(x));origin[str(j)]='new inference'
      assert len({s['image_tokens'] for s in scores.values()})==1
      technical=[]
      if split=='pilot' and i<2:
       for condition in ['E','ROI_HIGH']:
        ims=base if condition=='E' else [base,full.crop(geom['boxes'][geom['chosen']]).resize(size,Image.Resampling.LANCZOS)]
        text=prompt(x) if condition=='E' else PAIR+prompt(x)
        repeat=scorer.score(ims,text);official=scorer.score(ims,text,official=True)
        error=max(abs(a-b) for a,b in zip(repeat['option_probs'],old['scores'][condition]['option_probs']))
        official_error=max(abs(a-b) for a,b in zip(repeat['option_log_probs'],official['option_log_probs']))
        technical.append({'condition':condition,'answer_match':repeat['answer']==old['scores'][condition]['answer'],'max_probability_error':error,'official_logprob_error':official_error,'repeat':repeat})
      rec={'sample_id':x['sample_id'],'cohort':cohort,'split':split,'protocol_sha256':ph,'source_sha256':sha(source),'selected_window':geom['chosen'],'baseline':old['scores']['E'],'scores':scores,'origin':origin,'technical_repeats':technical,'at':now(),'wall_s':time.perf_counter()-tick}
      dump(target,rec)
     repeats.extend(rec['technical_repeats']);new_count+=sum(v=='new inference' for v in rec['origin'].values());reuse_count+=sum(v!='new inference' for v in rec['origin'].values());done+=1
     files.append({'path':target.relative_to(O).as_posix(),'sha256':sha(target)})
     if done%32==0 or i==len(xs)-1:
      dump(O/'progress.json',{'split':split,'cohort':cohort,'done':done,'total':192 if split=='pilot' else 2873,'new_predictions':new_count,'reused_predictions':reuse_count,'at':now()});print(args.model,split,cohort,done,flush=True)
   dump(O/(split+'_seal.json'),{'status':'SEALED_BEFORE_REFERENCE_SCORING','protocol_sha256':ph,'files':files,'new_grid_predictions':new_count,'reused_grid_predictions':reuse_count,'technical_repeat_predictions':len(repeats)*2,'at':now()})
   if split=='pilot':
    gate={'pass':all(v['answer_match'] and v['max_probability_error']<=.02 and v['official_logprob_error']<1e-4 for v in repeats),'checks':len(repeats),'max_probability_error':max(v['max_probability_error'] for v in repeats),'outcome_threshold':None,'at':now()}
    dump(O/'pilot_gate.json',gate);assert gate['pass'],gate
 finally:(E/'gpu.lock').unlink(missing_ok=True)

if __name__=='__main__':main()
