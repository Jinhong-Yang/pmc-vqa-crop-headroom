"""Independent checks from flat labels and ordinary case resampling."""
from pathlib import Path
import json,csv,collections,sys,hashlib,math,datetime
E=Path(__file__).resolve().parent;R=E.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
j=json.loads((E/'results.json').read_text());assert j['status']=='COMPLETE'
def close(a,b):assert abs(a-b)<1e-12,(a,b)
rows=list(csv.DictReader((E/'window_outcomes.csv').open(encoding='utf-8-sig')));receipt=[]
for label,stats in j['runs'].items():
 cohort,model=label.lower().split('/');rr=[r for r in rows if r['cohort']==cohort and r['model']==model];assert len(rr)==stats['n'];contrasts=[];gap=[];selected=[]
 for r in rr:
  baseline=int(r['baseline']);windows=[int(r['window_'+str(k)]) for k in range(9)];best=int(any(windows));u=sum(int(baseline or k) for k in windows)/9;g=windows[int(r['selected_window'])]
  contrasts.append(int(baseline or best)-u);gap.append(int(baseline or best)-int(baseline or g));selected.append(int(baseline or g)-u)
  order=sorted(range(9),key=lambda k:(-float(r['siglip_score_'+str(k)]),k));rank=next((k+1 for k,jj in enumerate(order) if windows[jj]),0);assert rank==int(r['first_correct_rank']) and order[0]==int(r['selected_window'])
 close(sum(contrasts)/len(rr),stats['best_minus_uniform_pair']['estimate']);close(sum(gap)/len(rr),stats['best_minus_selected_pair']['estimate']);close(sum(selected)/len(rr),stats['selected_minus_uniform_pair']['estimate']);assert min(contrasts)>=-1e-12 and min(gap)>=0
 for k in range(10):assert sum(int(r['baseline'])==0 and int(r['first_correct_rank'])==k for r in rr)==stats['first_correct_rank_on_baseline_errors'][str(k)]
 values=np.array(contrasts);rng=np.random.default_rng(2026101903);boot=np.concatenate([values[rng.integers(0,len(values),(100,len(values)))].mean(1) for _ in range(200)]);ci=np.quantile(boot,[.025,.975]);delta=float(max(abs(ci-np.array(stats['best_minus_uniform_pair']['ci95']))));assert delta<.0016,(label,delta)
 receipt.append({'run':label,'questions':len(rr),'all_three_oracle_contrasts':'PASS','independent_case_interval':ci.tolist(),'max_interval_deviation_pp':delta*100})
raw_new=raw_reused=0;scoring_checks={}
image_audit=json.loads((E/'input_image_audit.json').read_text());assert image_audit['status']=='PASS' and image_audit['records']==6130
image_hashes={(r['folder'],r['split'],r['sample_id']):r['image_sha256'] for r in image_audit['rows']};meta_cache={}
for model in ['2b','4b']:
 model_checks=[]
 for split in ['pilot','main']:
  O=E/model;seal=json.loads((O/(split+'_seal.json')).read_text());nc=rc=0
  for f in seal['files']:
   p=O/f['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'];rec=json.loads(p.read_text());assert set(rec['scores'])==set(map(str,range(9)));model_checks.extend(rec['technical_repeats'])
   folder=({'primary':'controlled_replication','curated':'curated_replication_2b'} if model=='2b' else {'primary':'controlled_replication_4b','curated':'curated_replication_4b'})[rec['cohort']]
   if (folder,split) not in meta_cache:
    mp=R/folder/split/'metadata.jsonl'
    if not mp.exists():mp=R/'reproducibility_bundle/run_evidence'/(folder+'__'+split)/'metadata.jsonl'
    meta_cache[(folder,split)]={a['sample_id']:a for a in [json.loads(s) for s in mp.read_text(encoding='utf-8').splitlines() if s]}
   assert image_hashes[(folder,split,rec['sample_id'])]==meta_cache[(folder,split)][rec['sample_id']]['image_sha256']
   source=R/folder/split/'predictions'/(rec['sample_id']+'.json')
   if not source.exists():source=R/'reproducibility_bundle/raw_predictions'/(folder+'__'+split)/(rec['sample_id']+'.json')
   assert hashlib.sha256(source.read_bytes()).hexdigest()==rec['source_sha256'];original=json.loads(source.read_text());assert rec['baseline']==original['scores']['E'];assert rec['selected_window']==original['observations']['roi']['chosen']
   assert len({a['image_tokens'] for a in rec['scores'].values()})==1
   for k,v in rec['scores'].items():
    assert len(v['option_probs'])==4 and all(math.isfinite(x) and 0<=x<=1 for x in v['option_probs']);assert abs(sum(v['option_probs'])-1)<1e-5;assert v['answer']=='ABCD'[max(range(4),key=lambda x:v['option_probs'][x])]
    if rec['origin'][k]!='new inference':assert v==original['scores'][rec['origin'][k]]
    nc+=rec['origin'][k]=='new inference';rc+=rec['origin'][k]!='new inference'
  assert nc==seal['new_grid_predictions'] and rc==seal['reused_grid_predictions'];raw_new+=nc;raw_reused+=rc
 assert len(model_checks)==8 and all(v['answer_match'] for v in model_checks)
 scoring_checks[model]={'comparisons':len(model_checks),'max_probability_error':max(v['max_probability_error'] for v in model_checks),'max_official_label_logprob_error':max(v['official_logprob_error'] for v in model_checks)}
 assert scoring_checks[model]['max_probability_error']<=.02 and scoring_checks[model]['max_official_label_logprob_error']<1e-4
# Verify the correction-rate fix independently from released original CSVs.
review=json.loads((E/'review_checks.json').read_text());pooled={}
for folder,label in [('controlled_replication','Primary/2B'),('controlled_replication_4b','Primary/4B'),('curated_replication_2b','Curated/2B'),('curated_replication_4b','Curated/4B')]:
 candidates=[R/'reproducibility_bundle/answer_records'/(folder+'__main.csv'),R/'plos_controls_draft_20261018/journal_payload/reproducibility_bundle/answer_records'/(folder+'__main.csv')];p=next(p for p in candidates if p.exists());records=collections.defaultdict(dict)
 for row in csv.DictReader(p.open(encoding='utf-8-sig')):records[row['sample_id']][row['condition']]=row
 rescue=flips=0
 for rec in records.values():
  base=rec['E'];wrong=base['answer']!=base['reference']
  for seed in [1,7,42]:
   c=rec['ROI_RANDOM_'+str(seed)];rescue+=wrong and c['answer']==c['reference'];flips+=wrong and c['answer']!=base['answer']
 close(rescue/flips,review['PMC'][label]['pooled_control_correction']);pooled[label]={'rescues':rescue,'changed_baseline_wrong':flips,'pooled_rate':rescue/flips}
flat=list(csv.DictReader((R/'additional_controls_20261018/question_level_results.csv').open(encoding='utf-8-sig')))
classes={v['sample_id']:v['answer_text'] for v in [json.loads(s) for s in (R/'additional_controls_20261018/positive_control/main/references.jsonl').read_text().splitlines()]};slake_checks=[]
for model in ['2b','4b']:
 for setting,pref,base in [('native','N','E_NATIVE'),('degraded','D','E_DEGRADED')]:
  rr=[r for r in flat if r['experiment']=='positive_control' and r['model']==model];byimage=collections.defaultdict(list);harm=0;affected={r['sample_id']:r for r in review['SLAKE'][model.upper()][setting]['same_class_exclusion_affected_rows']}
  for r in rr:
   b=r[base+'_answer']==r['reference'];p=r[pref+'_POSITIVE_answer']==r['reference'];c=[r[pref+'_CONTROL_'+str(z)+'_answer']==r['reference'] for z in [1,7,42]];harm+=b and not p
   if r['sample_id'] in affected:assert len(set(map(int,c)))==1
   if classes[r['sample_id']]!='Liver':byimage[r['image_id']].append(int(b or p)-sum(int(b or a) for a in c)/3)
  assert len(byimage)==40;v=np.array([sum(a)/len(a) for _,a in sorted(byimage.items())]);expected=review['SLAKE'][model.upper()][setting];close(float(v.mean()),expected['without_liver_oracle']['estimate']);assert harm==expected['positive_harm_questions']
  rng=np.random.default_rng(2026101904);boot=v[rng.integers(0,40,(20000,40))].mean(1);ci=np.quantile(boot,[.025,.975]);assert max(abs(ci-np.array(expected['without_liver_oracle']['ci95'])))<.006
  slake_checks.append({'model':model,'global':setting,'images':40,'independent_image_ci':ci.tolist(),'harm':harm,'affected_controls_identical':True})
result={'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_grid_predictions':raw_new,'reused_grid_predictions':raw_reused,'matrix_predictions':raw_new+raw_reused,'scoring_checks':scoring_checks,'image_audit_metadata_links':6130,'image_byte_audit':'Recorded PASS on acquired images; CPU release checking verifies its hash links against released metadata without obtaining image pixels.','window_checks':receipt,'independent_pooled_control_counts':pooled,'independent_SLAKE_checks':slake_checks,'scope':'All window records and source seals; independent flat-label contrasts and case-resampling interval checks. Pooled correction rates from original answer CSVs; non-liver effects, harm counts and affected control correctness independently checked from the additional-control CSV.'}
(E/'verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
