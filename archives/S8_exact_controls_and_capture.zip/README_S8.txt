Current post-outcome numerical sensitivity analysis, 19 October 2026
Extract S2-S8 together, in order, into one new directory.
S2-S7 remain byte-identical to the previous verified complete-grid release.
S8 adds all-eight non-selected controls, comparative rescue capture and current
figure code. It adds no model inference or independent replication.

python review_extension_20261019/analyze_extension.py
python review_extension_20261019/verify_extension.py
python current_figures/build_figures.py

The first script uses the complete-grid outcome CSV from S6. Python 3.11+,
NumPy are required for the new analyses; Matplotlib, Pillow and Arial fonts
are needed for figures. Earlier numerical and figure dependencies remain as
documented in S2-S7. Separate verification uses ordinary question resampling.
Current figures are written into current_figures/figures. Older figure code
in S6 remains historical provenance; use S8 for this revised manuscript.
All-eight and all-nine contrasts are algebraically linked, not independent.
Uniform counts are expectations. Capture denominators are baseline errors
with at least one correct window answer. All-window coverage uses baseline
and all nine stored top answers plus the reference; its max-minus-mean gap
is nonnegative by definition. It does not validate a label-free selector.
