"""Post-outcome reanalysis of the sealed complete grid; no new inference."""
from pathlib import Path
import json,csv,hashlib,sys
E=Path(__file__).resolve().parent;R=E.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
source=R/'window_audit_20261019/window_outcomes.csv'
rows=list(csv.DictReader(source.open(encoding='utf-8-sig')))
prior=json.loads((R/'window_audit_20261019/results.json').read_text())
out={'status':'COMPLETE','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Post-outcome exploratory numerical extension, not new inference or an independent replication.','bootstrap_draws':20000,'seed':2026101905,'runs':{}}
flat=[]
for cohort,model in [('primary','2b'),('primary','4b'),('curated','2b'),('curated','4b')]:
 a=[x for x in rows if x['cohort']==cohort and x['model']==model];n=len(a);label=cohort.title()+'/'+model.upper()
 b=np.array([int(x['baseline']) for x in a]);w=np.array([[int(x['window_'+str(j)]) for j in range(9)] for x in a]);k=w.sum(1);g=np.array([w[i,int(x['selected_window'])] for i,x in enumerate(a)])
 guided=np.maximum(b,g);control8=np.maximum(b,(k-g)/8);uniform=np.maximum(b,k/9);available=(1-b)*(k>0);rescued=(1-b)*g;random_rescued=(1-b)*k/9
 # Joint categorical multinomial resampling equals the paired question bootstrap.
 joint=np.column_stack([b,g,k]);states,counts=np.unique(joint,axis=0,return_counts=True);draws=np.random.default_rng(2026101905).multinomial(n,counts/n,20000)
 sb,sg,sk=states.T;sv=(1-sb)*(sk>0);sr=(1-sb)*sg;su=(1-sb)*sk/9
 def metric(value,state_value):
  simulated=draws@state_value/n
  return {'estimate':float(np.mean(value)),'ci95':np.quantile(simulated,[.025,.975]).tolist()}
 def ratio(value,den,state_value,state_den):
  d=draws@state_den;assert (d>0).all()
  return {'estimate':float(value.sum()/den.sum()),'ci95':np.quantile((draws@state_value)/d,[.025,.975]).tolist()}
 v={'n':n,'baseline_wrong':int((1-b).sum()),'available_rescues':int(available.sum()),'selected_rescues':int(rescued.sum()),'uniform_expected_rescues':float(random_rescued.sum()),'all8_pair_oracle':metric(control8,np.maximum(sb,(sk-sg)/8)),'selected_minus_all8_pair':metric(guided-control8,np.maximum(sb,sg)-np.maximum(sb,(sk-sg)/8)),'selected_capture':ratio(rescued,available,sr,sv),'uniform_capture':ratio(random_rescued,available,su,sv),'baseline_wrong_patterns':{'none_correct':int(((b==0)&(k==0)).sum()),'partly_correct_1_to_8':int(((b==0)&(k>0)&(k<9)).sum()),'all9_correct':int(((b==0)&(k==9)).sum())}}
 assert np.allclose(guided-control8,9/8*(guided-uniform))
 assert np.all((np.maximum(b,k>0)-uniform)>=0)
 assert v['available_rescues']==prior['runs'][label]['available_rescues']
 assert v['selected_rescues']==prior['runs'][label]['selected_rescues']
 out['runs'][label]=v
 for i,x in enumerate(a):flat.append({'cohort':cohort,'model':model,'sample_id':x['sample_id'],'baseline':int(b[i]),'selected_correct':int(g[i]),'correct_window_count':int(k[i]),'all8_pair_oracle':float(control8[i]),'selected_minus_all8_pair':float(guided[i]-control8[i]),'available_rescue':int(available[i]),'uniform_rescue_probability':float(random_rescued[i])})
(E/'extension_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
with (E/'extension_outcomes.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat)
print(json.dumps(out,indent=2))
