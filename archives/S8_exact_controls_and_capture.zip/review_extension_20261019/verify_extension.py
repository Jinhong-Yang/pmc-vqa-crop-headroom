"""Separate row-level calculations and ordinary case bootstrap."""
from pathlib import Path
import csv,json,sys,hashlib
from fractions import Fraction
E=Path(__file__).resolve().parent;R=E.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
source=R/'window_audit_20261019/window_outcomes.csv';rows=list(csv.DictReader(source.open(encoding='utf-8-sig')));j=json.loads((E/'extension_results.json').read_text());assert hashlib.sha256(source.read_bytes()).hexdigest()==j['source_sha256']
checks=[]
for label,v in j['runs'].items():
 cohort,model=label.lower().split('/');a=[x for x in rows if x['cohort']==cohort and x['model']==model];delta=[];control=[];available=[];selected=[];uniform=[]
 for row in a:
  b=int(row['baseline']);s=int(row['selected_window']);w=[int(row['window_'+str(k)]) for k in range(9)]
  oracle8=sum(Fraction(max(b,w[k]),8) for k in range(9) if k!=s);control.append(float(oracle8));delta.append(float(Fraction(max(b,w[s]))-oracle8));available.append((not b) and any(w));selected.append((not b) and w[s]);uniform.append(float(Fraction((not b)*sum(w),9)))
 assert abs(sum(delta)/len(a)-v['selected_minus_all8_pair']['estimate'])<1e-14
 assert abs(sum(control)/len(a)-v['all8_pair_oracle']['estimate'])<1e-14
 assert sum(available)==v['available_rescues'] and sum(selected)==v['selected_rescues']
 assert abs(sum(uniform)/sum(available)-v['uniform_capture']['estimate'])<1e-14
 assert abs(sum(selected)/sum(available)-v['selected_capture']['estimate'])<1e-14
 # Independent source spot checks complement the earlier full-matrix verification.
 for row in [a[0],a[-1]]:
  raw=json.loads((R/'window_audit_20261019'/model/'main'/cohort/(row['sample_id']+'.json')).read_text()) if (R/'window_audit_20261019'/model/'main').exists() else None
  if raw:
   assert int(row['baseline'])==(raw['baseline']['answer']==row['reference'])
   assert all(int(row['window_'+str(k)])==(raw['scores'][str(k)]['answer']==row['reference']) for k in range(9))
 rng=np.random.default_rng(2026101906);boot=[];sd=[];ud=[];n=len(a);d=np.array(delta);av=np.array(available);sr=np.array(selected);ur=np.array(uniform)
 for _ in range(100):
  index=rng.integers(0,n,size=(200,n));den=av[index].sum(1);assert (den>0).all();boot.extend(d[index].mean(1));sd.extend(sr[index].sum(1)/den);ud.extend(ur[index].sum(1)/den)
 ci=np.quantile(boot,[.025,.975]);assert max(abs(ci-np.array(v['selected_minus_all8_pair']['ci95'])))<.002
 assert max(abs(np.quantile(sd,[.025,.975])-np.array(v['selected_capture']['ci95'])))<.01
 assert max(abs(np.quantile(ud,[.025,.975])-np.array(v['uniform_capture']['ci95'])))<.01
 checks.append({'run':label,'all8_point_and_capture':'PASS','independent_ci95':ci.tolist(),'raw_source_spot_checks':2 if (R/'window_audit_20261019'/model/'main').exists() else 'Earlier full-matrix verification receipt applies; raw main records unavailable in this extraction.'})
(E/'extension_verification.json').write_text(json.dumps({'status':'PASS','source':'All 5746 rows independently recomputed; 8 raw records spot-checked when available. Earlier full-matrix checks retained.','case_bootstrap_seed':2026101906,'checks':checks},indent=2),encoding='utf-8');print('EXTENSION_VERIFICATION_PASS')
