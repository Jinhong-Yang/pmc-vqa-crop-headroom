Content-focused numerical update, 19 October 2026
Extract S2-S9 together, in order, into one fresh directory.
S2-S8 are byte-identical to the previous verified release. S9 adds no model
inference. It recalculates partial-window rescue capture and paired ratio
differences, exact random-order first-correct-rank expectations, all-nine-
correct overlap with duplicate presentation, retrieval-text token direction,
crop-only multiplicity and the equal native non-liver image-effect vectors.

python content_checks_20261019/analyze_content.py
python content_checks_20261019/verify_content.py

Python3.11+, NumPy and SciPy are required. Earlier dependency/version records
remain in S2-S8. Raw prediction source paths fall back to the released S3
layout. The analysis is CPU-only and does not need source images or models.
The first script writes content_results.json and content_outcomes.csv. The
second independently enumerates rank distributions and checks paired ratio
intervals using an ordinary case bootstrap with a separate seed.

Figures are unchanged from S8: python current_figures/build_figures.py
Use S8 figure code for the current manuscript. Old S6 figure code remains
historical provenance. S9 supersedes earlier prose concerning retrieval
token direction and standardises duplicate-oracle CIs at seed2026101902.
Historical output files remain intact rather than being overwritten.

Partial-window capture conditions on baseline errors with1<=K<=8; K=9 cases
are separate. All-available capture still usesK>0 and is retained. Both paired
capture differences are bootstrapped jointly with their denominators. The
one-third switching reference is arithmetic, not an empirically validated
null model; no causal grounding claim or equivalence is established.
