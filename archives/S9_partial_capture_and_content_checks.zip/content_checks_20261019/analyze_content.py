"""Post-outcome content checks using the frozen predictions; no model inference."""
from pathlib import Path
from math import comb
from fractions import Fraction
import json,csv,sys,hashlib,collections
E=Path(__file__).resolve().parent;R=E.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
from scipy.stats import ttest_1samp
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def jl(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def boot(x,seed=2026101902):
 x=np.asarray(x,float);u,c=np.unique(x,return_counts=True);z=np.random.default_rng(seed).multinomial(len(x),c/len(x),20000)@u/len(x)
 return {'estimate':float(x.mean()),'ci95':np.quantile(z,[.025,.975]).tolist()}
source=R/'window_audit_20261019/window_outcomes.csv';flat=list(csv.DictReader(source.open(encoding='utf-8-sig')))
old=json.loads((R/'additional_controls_20261018/review_diagnostics.json').read_text())
out={'status':'COMPLETE','role':'Post-outcome descriptive and paired sensitivity analysis of existing records. No model inference, new training or independent replication.','seed':2026101907,'draws':20000,'window_source_sha256':sha(source),'runs':{},'crop_selector_tests':[]};export=[]
mapping={'Primary/2B':'controlled_replication','Primary/4B':'controlled_replication_4b','Curated/2B':'curated_replication_2b','Curated/4B':'curated_replication_4b'}
for label,folder in mapping.items():
 cohort,model=label.lower().split('/');a=[x for x in flat if x['cohort']==cohort and x['model']==model];n=len(a);base=R/folder/'main/predictions'
 if not base.exists():base=R/'reproducibility_bundle/raw_predictions'/(folder+'__main')
 raw=[];dig=hashlib.sha256()
 for x in a:
  p=base/(x['sample_id']+'.json');blob=p.read_bytes();dig.update(x['sample_id'].encode()+hashlib.sha256(blob).digest());raw.append(json.loads(blob))
 b=np.array([int(x['baseline']) for x in a]);w=np.array([[int(x['window_'+str(j)]) for j in range(9)] for x in a]);k=w.sum(1);g=np.array([w[i,int(x['selected_window'])] for i,x in enumerate(a)]);gold=np.array(['ABCD'.index(x['reference']) for x in a]);du=np.array([p['scores']['ROI_DUPLICATE']['answer']==x['reference'] for p,x in zip(raw,a)],int)
 assert all(b[i]==(p['scores']['E']['answer']==a[i]['reference']) and g[i]==(p['scores']['ROI_HIGH']['answer']==a[i]['reference']) for i,p in enumerate(raw))
 partial=(b==0)&(k>0)&(k<9);available=(b==0)&(k>0);all9=(b==0)&(k==9)
 states,counts=np.unique(np.column_stack([b,g,k]),axis=0,return_counts=True);draw=np.random.default_rng(2026101907).multinomial(n,counts/n,20000);sb,sg,sk=states.T
 def capture(mask,smask):
  denominator=int(mask.sum());den=draw@smask;assert (den>0).all();sr=(draw@(smask*sg))/den;ur=(draw@(smask*sk/9))/den
  def q(value,z):return {'estimate':float(value),'ci95':np.quantile(z,[.025,.975]).tolist()}
  return {'denominator':denominator,'selected_rescues':int(g[mask].sum()),'uniform_expected_rescues':float((k[mask]/9).sum()),'selected':q(g[mask].mean(),sr),'uniform':q((k[mask]/9).mean(),ur),'paired_difference':q((g[mask]-k[mask]/9).mean(),sr-ur)}
 pc=capture(partial,(sb==0)&(sk>0)&(sk<9));ac=capture(available,(sb==0)&(sk>0))
 observed=[sum(int(x['first_correct_rank'])==j and int(x['baseline'])==0 for x in a) for j in range(10)];expected=[float(((b==0)&(k==0)).sum())]+[float(sum(Fraction(comb(9-r,int(kk)-1),comb(9,int(kk))) if 1<=kk<=10-r else 0 for kk in k[b==0])) for r in range(1,10)]
 assert abs(expected[1]-float((k[b==0]/9).sum()))<1e-10 and abs(sum(expected[1:])-available.sum())<1e-10
 tokens_g=np.array([p['observations']['R_IQG']['tokens'] for p in raw]);tokens_c=np.array([[p['observations']['R_SHUFFLE_'+str(s)]['tokens'] for s in [1,7,42]] for p in raw]);token_diff=tokens_g-tokens_c.mean(1)
 c=np.array([[p['scores']['ROI_RANDOM_'+str(s)]['answer']==x['reference'] for s in [1,7,42]] for p,x in zip(raw,a)],float)
 def correction(condition):
  changed=np.array([p['scores'][condition]['answer']!=p['scores']['E']['answer'] for p in raw]);correct=np.array([p['scores'][condition]['answer']==x['reference'] for p,x in zip(raw,a)]);den=int(((b==0)&changed).sum());num=int(((b==0)&correct).sum());return {'rescues':num,'wrong_flips':den,'rate':num/den}
 cr=[correction('ROI_RANDOM_'+str(s)) for s in [1,7,42]]
 out['runs'][label]={'n':n,'raw_records_digest':dig.hexdigest(),'partial_capture':pc,'all_available_capture':ac,'all9':{'questions':int(all9.sum()),'duplicate_shared_rescues':int(du[all9].sum()),'not_duplicate_rescues':int((1-du[all9]).sum()),'fraction_of_available':float(all9.sum()/available.sum())},'first_correct_rank':{'observed':observed,'random_permutation_expected':expected},'retrieval_tokens':{'guided_mean':float(tokens_g.mean()),'control_mean':float(tokens_c.mean()),'guided_minus_control_mean':float(token_diff.mean())},'guided_minus_duplicate_oracle':boot(np.maximum(b,g)-np.maximum(b,du)),'control_minus_duplicate_oracle':boot(np.maximum(b[:,None],c).mean(1)-np.maximum(b,du)),'correction':{'guided':correction('ROI_HIGH'),'pooled_control':{'rescues':sum(z['rescues'] for z in cr),'wrong_flips':sum(z['wrong_flips'] for z in cr),'rate':sum(z['rescues'] for z in cr)/sum(z['wrong_flips'] for z in cr)},'uniform_switch_reference':1/3}}
 probs={name:np.array([p['scores'][name]['option_probs'] for p in raw]) for name in ['E','ROI_HIGH','ROI_RANDOM_1','ROI_RANDOM_7','ROI_RANDOM_42']}
 def select(names,rule):
  z=np.stack([probs[name] for name in names],axis=1)
  if rule=='Avg':return z.mean(1).argmax(1)
  quality=z.max(2) if rule=='Conf' else (z*np.log(np.clip(z,1e-30,1))).sum(2);return z[np.arange(n),quality.argmax(1)].argmax(1)
 for rule in ['Conf','Entropy','Avg']:
  d=(select(['E','ROI_HIGH'],rule)==gold).astype(float)-np.array([(select(['E','ROI_RANDOM_'+str(s)],rule)==gold).astype(float) for s in [1,7,42]]).mean(0);p=float(ttest_1samp(d,0).pvalue);prior=next(z for z in old['runs'][label]['selector_tests'] if z['pool']=='Crop' and z['rule']==rule);assert abs(p-prior['p_t_reference'])<1e-12
  out['crop_selector_tests'].append({'run':label,'rule':rule,'estimate':float(d.mean()),'ci95':prior['ci95'],'p_t_reference':p})
 for i,x in enumerate(a):export.append({'cohort':cohort,'model':model,'sample_id':x['sample_id'],'baseline':int(b[i]),'selected_correct':int(g[i]),'K':int(k[i]),'partial_K':int(partial[i]),'all9_K':int(all9[i]),'duplicate_correct':int(du[i]),'uniform_rescue_probability':float((1-b[i])*k[i]/9),'first_correct_rank':int(x['first_correct_rank'])})
tests=out['crop_selector_tests'];order=np.argsort([x['p_t_reference'] for x in tests]);q=1.
for rank in range(len(tests)-1,-1,-1):i=int(order[rank]);q=min(q,tests[i]['p_t_reference']*len(tests)/(rank+1));tests[i]['q_bh_12']=q
out['crop_multiplicity']={'comparisons':len(tests),'q_below_05':sum(x['q_bh_12']<.05 for x in tests)}
rows=list(csv.DictReader((R/'additional_controls_20261018/question_level_results.csv').open(encoding='utf-8-sig')));refs=jl(R/'additional_controls_20261018/positive_control/main/references.jsonl');meta={z['sample_id']:z for z in refs};groups=json.loads((R/'additional_controls_20261018/positive_control/annotation_audit.json').read_text())['groups'];native={}
for model in ['2b','4b']:
 a=[x for x in rows if x['model']==model and x.get('E_NATIVE_answer')];assert len(a)==114;effects=collections.defaultdict(list);harm=0
 for x in a:
  b=int(x['E_NATIVE_answer']==x['reference']);p=int(x['N_POSITIVE_answer']==x['reference']);c=[int(x['N_CONTROL_'+str(s)+'_answer']==x['reference']) for s in [1,7,42]];harm+=int(b and not p)
  if meta[x['sample_id']]['answer_text']!='Liver':effects[x['image_id']].append(max(b,p)-sum(max(b,z) for z in c)/3)
 image_effects={i:float(np.mean(v)) for i,v in sorted(effects.items())};v=boot(list(image_effects.values()));v['all_class_direct_harm']=harm;v['image_effects']=image_effects;v['nonzero_images']={i:{'effect':d,'group':groups[str(i)],'group_image_count':sum(groups[str(other)]==groups[str(i)] for other in image_effects)} for i,d in image_effects.items() if abs(d)>1e-12};native[model.upper()]=v
out['native_non_liver_check']=native;out['native_image_effect_multisets_identical']=np.allclose(sorted(native['2B']['image_effects'].values()),sorted(native['4B']['image_effects'].values()))
(E/'content_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
with (E/'content_outcomes.csv').open('w',encoding='utf-8-sig',newline='') as f:z=csv.DictWriter(f,fieldnames=list(export[0]));z.writeheader();z.writerows(export)
print(json.dumps({'runs':{k:{z:v[z] for z in ['partial_capture','all9','retrieval_tokens']} for k,v in out['runs'].items()},'native':{k:{z:v[z] for z in ['estimate','ci95','all_class_direct_harm','nonzero_images']} for k,v in native.items()},'native_multisets_equal':out['native_image_effect_multisets_identical'],'crop_multiplicity':out['crop_multiplicity']},indent=2))
