from pathlib import Path
from fractions import Fraction
from itertools import combinations
import csv,json,sys,hashlib,collections
E=Path(__file__).resolve().parent;R=E.parent;sys.path.insert(0,str(R/'dependencies'))
import numpy as np
j=json.loads((E/'content_results.json').read_text());source=R/'window_audit_20261019/window_outcomes.csv';assert hashlib.sha256(source.read_bytes()).hexdigest()==j['window_source_sha256'];rows=list(csv.DictReader(source.open(encoding='utf-8-sig')));outrows=list(csv.DictReader((E/'content_outcomes.csv').open(encoding='utf-8-sig')));assert len(rows)==len(outrows)==5746
key=lambda x:(x['cohort'],x['model'],x['sample_id'])
original={key(x):x for x in rows};assert len(original)==len(rows) and set(original)=={key(x) for x in outrows}
for b in outrows:
 a=original[key(b)]
 assert a['sample_id']==b['sample_id'] and a['model']==b['model'];assert sum(int(a['window_'+str(i)]) for i in range(9))==int(b['K']);assert int(a['window_'+a['selected_window']])==int(b['selected_correct'])
permutation={}
for k in range(1,10):
 c=collections.Counter(min(s) for s in combinations(range(1,10),k));den=sum(c.values());permutation[k]=[Fraction(c[r],den) for r in range(1,10)]
checks=[];folders={'Primary/2B':'controlled_replication','Primary/4B':'controlled_replication_4b','Curated/2B':'curated_replication_2b','Curated/4B':'curated_replication_4b'}
for label,v in j['runs'].items():
 cohort,model=label.lower().split('/');a=[x for x in outrows if x['cohort']==cohort and x['model']==model];b=np.array([int(x['baseline']) for x in a]);k=np.array([int(x['K']) for x in a]);g=np.array([int(x['selected_correct']) for x in a]);d=np.array([int(x['duplicate_correct']) for x in a]);mask=(b==0)&(k>0)&(k<9);av=(b==0)&(k>0);full=(b==0)&(k==9);p=v['partial_capture'];assert int(mask.sum())==p['denominator'];assert int(g[mask].sum())==p['selected_rescues'];assert int(d[full].sum())==v['all9']['duplicate_shared_rescues']
 assert abs(float(sum(Fraction(int(x),9) for x in k[mask]))-p['uniform_expected_rescues'])<1e-12
 expected=[float(((b==0)&(k==0)).sum())]+[float(sum(permutation[int(kk)][r-1] for kk in k[b==0] if kk>0)) for r in range(1,10)];assert np.allclose(expected,v['first_correct_rank']['random_permutation_expected'])
 rng=np.random.default_rng(2026101908);partial=[];available=[]
 for _ in range(100):
  ix=rng.integers(0,len(a),(200,len(a)));delta=g[ix]-k[ix]/9;pm=mask[ix];am=av[ix];assert(pm.sum(1)>0).all();partial.extend((delta*pm).sum(1)/pm.sum(1));available.extend((delta*am).sum(1)/am.sum(1))
 ci=np.quantile(partial,[.025,.975]);assert max(abs(ci-np.array(p['paired_difference']['ci95'])))<.012
 ci2=np.quantile(available,[.025,.975]);assert max(abs(ci2-np.array(v['all_available_capture']['paired_difference']['ci95'])))<.012
 base=R/folders[label]/'main/predictions'
 if not base.exists():base=R/'reproducibility_bundle/raw_predictions'/(folders[label]+'__main')
 total=Fraction(0);dig=hashlib.sha256()
 for x in a:
  z=base/(x['sample_id']+'.json');blob=z.read_bytes();dig.update(x['sample_id'].encode()+hashlib.sha256(blob).digest());raw=json.loads(blob);obs=raw['observations'];total+=Fraction(obs['R_IQG']['tokens'])-sum(Fraction(obs['R_SHUFFLE_'+str(s)]['tokens'],3) for s in [1,7,42])
 assert dig.hexdigest()==v['raw_records_digest'];assert abs(float(total/len(a))-v['retrieval_tokens']['guided_minus_control_mean'])<1e-12
 checks.append({'run':label,'partial_points_and_paired_ci':'PASS','enumerated_random_rank_expectations':'PASS','retrieval_tokens_independent_fraction_mean':float(total/len(a)),'paired_case_bootstrap_ci95':ci.tolist()})
tests=j['crop_selector_tests'];ps=[z['p_t_reference'] for z in tests];order=np.argsort(ps)
for rank,i in enumerate(order):assert abs(tests[int(i)]['q_bh_12']-min(1.,min(12*ps[int(order[h])]/(h+1) for h in range(rank,12))))<1e-12
for model in ['2B','4B']:
 v=j['native_non_liver_check'][model];values=list(v['image_effects'].values());assert len(values)==40 and sum(abs(z)>1e-12 for z in values)==1;assert np.isclose(sorted(values)[0],-1/3) and np.isclose(sum(values)/40,-1/120);assert np.allclose(v['ci95'],[-.025,0])
assert j['native_non_liver_check']['2B']['all_class_direct_harm']==8 and j['native_non_liver_check']['4B']['all_class_direct_harm']==3
(E/'content_verification.json').write_text(json.dumps({'status':'PASS','scope':'All5746 exported rows linked to the sealed matrix; all raw records digested and retrieval-token means independently recomputed. Random-rank distributions independently enumerated. Separate ordinary paired case bootstrap validates ratio-difference intervals.','independent_seed':2026101908,'draws':20000,'checks':checks,'SLAKE_equal_native_effects':'Each image-effect vector has39zeros and one -1/3, on different images. Direct harm is a separate endpoint.','crop_BH12':'PASS'},indent=2),encoding='utf-8');print('CONTENT_VERIFICATION_PASS')
